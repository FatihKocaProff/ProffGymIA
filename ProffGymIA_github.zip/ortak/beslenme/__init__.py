"""FitAI (ProffGymIA) ve Kepçe'nin ortak beslenme kodu.

- food_text: internetsiz Türk mutfağı besin tablosu ve yazılan öğünün ayrıştırılması
- food_ai:   yemek fotoğrafı / yazılan öğün için yapay zeka (Gemini, Claude, demo)

Bir hatayı burada düzeltmek iki uygulamayı da düzeltir. ProffGymIA bu klasörü
pyproject.toml ile paket olarak kurar (requirements.txt: -e ../../ortak);
Kepçe hâlâ app/__init__.py içinde sys.path'e ekler.
"""
