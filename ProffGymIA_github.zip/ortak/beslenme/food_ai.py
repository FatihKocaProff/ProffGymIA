"""Yemek fotoğrafından besin değeri çıkarma.

Fotoğraf seçilen yapay zeka modeline gönderilir; model tabaktaki yiyecekleri,
tahmini porsiyonları ve makroları JSON olarak döndürür. Çıktı burada doğrulanır
ve toplamlar yeniden hesaplanır (modelin toplama hatası yapma ihtimaline karşı).

Desteklenen sağlayıcılar: gemini, claude, demo (internetsiz sunum).

Yazılı öğün ("2 yumurta, 1 dilim ekmek") için analyze_text kullanılır: anahtar varsa
model hesaplar, yoksa ya da model yanıt vermezse yerel besin tablosu (food_text) devreye girer.
"""
from __future__ import annotations

import base64
import hashlib
import json
import re

from types import SimpleNamespace

config = SimpleNamespace(
    AI_PROVIDER="", GEMINI_API_KEY="", ANTHROPIC_API_KEY="",
    GEMINI_MODEL="gemini-3.6-flash", CLAUDE_MODEL="claude-haiku-5-5", AI_TIMEOUT_SECONDS=45.0,
)


def configure(settings) -> None:
    """Uygulamanın config modülünü (veya aynı alanlara sahip bir nesneyi) bağlar."""
    global config
    config = settings


class FoodAIError(Exception):
    """Analiz yapılamadığında kullanıcıya gösterilecek açıklamayla fırlatılır."""


PROMPT = """Sen bir spor diyetisyenisin. Fotoğraftaki yemeği analiz et.
Tabaktaki her yiyeceği ayrı ayrı tanı, porsiyonunu gram olarak tahmin et ve besin değerlerini hesapla.
Türk mutfağını dikkate al (ör. bulgur pilavı, mercimek çorbası, lahmacun).
Fotoğrafta yiyecek yoksa "items" listesini boş bırak ve "note" alanında açıkla.

YALNIZCA şu JSON biçiminde yanıt ver, başka metin ekleme:
{
  "items": [
    {"name": "Izgara tavuk göğsü", "portion_g": 150, "calories": 248, "protein_g": 46.5, "carbs_g": 0, "fat_g": 5.4}
  ],
  "fiber_g": 4.0,
  "vitamins": ["B6", "B12", "C"],
  "confidence": "orta",
  "note": "Porsiyonlar fotoğraftan tahmin edildi."
}
"confidence" değeri "yüksek", "orta" veya "düşük" olmalı. Yiyecek adları Türkçe olsun."""

TEXT_PROMPT = """Sen bir spor diyetisyenisin. Kullanıcı bir öğünde ne yediğini yazdı:
\"\"\"{text}\"\"\"
Yazılan her yiyeceği ayrı ayrı ele al. Miktar yazılmışsa (ör. "2 yumurta", "150 g tavuk", "1 kase çorba")
onu kullan; yazılmamışsa standart bir Türk porsiyonu varsay ve "note" alanında belirt.
Türk mutfağını dikkate al. Yiyecek olmayan bir metinse "items" listesini boş bırak.

YALNIZCA şu JSON biçiminde yanıt ver, başka metin ekleme:
{{
  "items": [
    {{"name": "Haşlanmış yumurta (2 adet)", "portion_g": 100, "calories": 143, "protein_g": 12.6, "carbs_g": 0.7, "fat_g": 9.5}}
  ],
  "fiber_g": 0.0,
  "vitamins": ["B12", "D"],
  "confidence": "yüksek",
  "note": ""
}}
"confidence" değeri "yüksek", "orta" veya "düşük" olmalı. Yiyecek adları Türkçe olsun."""

LOCAL_PROVIDER = "yerel"
LOCAL_MODEL = "FitAI besin tablosu"


def _num(value, default: float = 0.0) -> float:
    try:
        n = float(value)
    except (TypeError, ValueError):
        return default
    return max(n, 0.0) if n == n else default


def extract_json(text: str) -> dict:
    """Model bazen JSON'u ```json ... ``` içine koyar veya önüne açıklama ekler."""
    text = (text or "").strip()
    fence = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.DOTALL)
    if fence:
        text = fence.group(1)
    else:
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end > start:
            text = text[start : end + 1]
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise FoodAIError("Yapay zeka yanıtı okunamadı. Fotoğrafı tekrar dene.") from exc
    if not isinstance(data, dict):
        raise FoodAIError("Yapay zeka beklenmeyen bir yanıt verdi.")
    return data


def normalize(data: dict) -> dict:
    """Ham model çıktısını güvenli, tutarlı bir yapıya çevirir ve toplamları hesaplar."""
    items = []
    for raw in data.get("items") or []:
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("name") or "").strip()[:80]
        if not name:
            continue
        items.append(
            {
                "name": name,
                "portion_g": round(_num(raw.get("portion_g")), 0),
                "calories": round(_num(raw.get("calories")), 0),
                "protein_g": round(_num(raw.get("protein_g")), 1),
                "carbs_g": round(_num(raw.get("carbs_g")), 1),
                "fat_g": round(_num(raw.get("fat_g")), 1),
            }
        )

    totals = {k: round(sum(i[k] for i in items), 1) for k in ("calories", "protein_g", "carbs_g", "fat_g")}
    totals["calories"] = round(totals["calories"])

    macro_kcal = totals["protein_g"] * 4 + totals["carbs_g"] * 4 + totals["fat_g"] * 9
    consistent = totals["calories"] == 0 or abs(macro_kcal - totals["calories"]) <= max(60, totals["calories"] * 0.2)

    vitamins = [str(v).strip()[:20] for v in (data.get("vitamins") or []) if str(v).strip()][:10]
    confidence = str(data.get("confidence") or "orta").lower()
    if confidence not in {"yüksek", "orta", "düşük"}:
        confidence = "orta"

    return {
        "items": items,
        "totals": totals,
        "fiber_g": round(_num(data.get("fiber_g")), 1),
        "vitamins": vitamins,
        "confidence": confidence,
        "consistent": consistent,
        "note": str(data.get("note") or "").strip()[:300],
    }


def describe(result: dict) -> str:
    """Öğün açıklaması için kısa metin: 'Izgara tavuk, bulgur pilavı'."""
    names = [i["name"] for i in result["items"]]
    return ", ".join(names)[:200] if names else "Fotoğraflı öğün"


def active_provider() -> str:
    p = config.AI_PROVIDER
    if p in {"gemini", "claude", "demo"}:
        return p
    if config.GEMINI_API_KEY:
        return "gemini"
    if config.ANTHROPIC_API_KEY:
        return "claude"
    return "demo"


def analyze_food(image: bytes, mime_type: str) -> dict:
    provider = active_provider()
    if provider == "gemini":
        raw, model = _gemini(image, mime_type), config.GEMINI_MODEL
    elif provider == "claude":
        raw, model = _claude(image, mime_type), config.CLAUDE_MODEL
    else:
        return _demo(image)
    result = normalize(extract_json(raw))
    result.update(provider=provider, model=model)
    return result


def _post(url: str, headers: dict, payload: dict) -> dict:
    import httpx

    try:
        resp = httpx.post(url, headers=headers, json=payload, timeout=config.AI_TIMEOUT_SECONDS)
    except httpx.HTTPError as exc:
        raise FoodAIError("Yapay zeka servisine ulaşılamadı. İnternet bağlantısını kontrol et.") from exc
    if resp.status_code in (401, 403):
        raise FoodAIError("API anahtarı geçersiz. .env dosyasındaki anahtarı kontrol et.")
    if resp.status_code == 429:
        raise FoodAIError("Yapay zeka kotası doldu. Biraz sonra tekrar dene.")
    if resp.status_code >= 400:
        detail = resp.text[:200]
        raise FoodAIError(f"Yapay zeka servisi hata verdi ({resp.status_code}): {detail}")
    return resp.json()


def _gemini(image: bytes, mime_type: str) -> str:
    return _gemini_parts([
        {"inline_data": {"mime_type": mime_type, "data": base64.b64encode(image).decode()}},
        {"text": PROMPT},
    ])


def _gemini_parts(parts: list[dict]) -> str:
    if not config.GEMINI_API_KEY:
        raise FoodAIError("GEMINI_API_KEY tanımlı değil. .env dosyasına ekle.")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{config.GEMINI_MODEL}:generateContent"
    payload = {
        "contents": [{"parts": parts}],
        "generationConfig": {"responseMimeType": "application/json", "temperature": 0.2},
    }
    data = _post(url, {"x-goog-api-key": config.GEMINI_API_KEY}, payload)
    try:
        parts = data["candidates"][0]["content"]["parts"]
        return "".join(p.get("text", "") for p in parts)
    except (KeyError, IndexError, TypeError) as exc:
        reason = (data.get("promptFeedback") or {}).get("blockReason")
        raise FoodAIError(f"Gemini yanıt üretmedi{f' ({reason})' if reason else ''}.") from exc


def _claude(image: bytes, mime_type: str) -> str:
    return _claude_content([
        {"type": "image", "source": {"type": "base64", "media_type": mime_type, "data": base64.b64encode(image).decode()}},
        {"type": "text", "text": PROMPT},
    ])


def _claude_content(content: list[dict]) -> str:
    if not config.ANTHROPIC_API_KEY:
        raise FoodAIError("ANTHROPIC_API_KEY tanımlı değil. .env dosyasına ekle.")
    payload = {
        "model": config.CLAUDE_MODEL,
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": content}],
    }
    headers = {"x-api-key": config.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01"}
    data = _post("https://api.anthropic.com/v1/messages", headers, payload)
    return "".join(block.get("text", "") for block in data.get("content", []) if block.get("type") == "text")


def _local_result(text: str, extra_note: str = "") -> dict:
    from .food_text import analyze_text_local

    local = analyze_text_local(text)
    result = normalize(local)
    note = " ".join(n for n in (extra_note, result["note"]) if n)
    result.update(note=note[:300], provider=LOCAL_PROVIDER, model=LOCAL_MODEL, unmatched=local["unmatched"])
    return result


def analyze_text(text: str, quick: bool = False) -> dict:
    """Yazılan öğünün kalorisini ve makrolarını hesaplar.

    quick=True: yazarken anlık önizleme içindir, her zaman yerel tablo kullanılır (hızlı, ücretsiz).
    Yapay zeka anahtarı yoksa veya model ulaşılamazsa yine yerel tabloya düşer; bu fonksiyon hata fırlatmaz.
    """
    text = (text or "").strip()[:500]
    provider = active_provider()
    if quick or provider == "demo" or not text:
        return _local_result(text)
    prompt = TEXT_PROMPT.format(text=text.replace('"""', "'"))
    try:
        if provider == "gemini":
            raw, model = _gemini_parts([{"text": prompt}]), config.GEMINI_MODEL
        else:
            raw, model = _claude_content([{"type": "text", "text": prompt}]), config.CLAUDE_MODEL
        result = normalize(extract_json(raw))
    except FoodAIError as exc:
        return _local_result(text, f"Yapay zekaya ulaşılamadı ({exc}); yerel besin tablosuyla hesaplandı.")
    if not result["items"]:
        local = _local_result(text)
        if local["items"]:
            return local
    result.update(provider=provider, model=model, unmatched=[])
    return result


DEMO_PLATES = [
    {"items": [{"name": "Izgara tavuk göğsü", "portion_g": 150, "calories": 248, "protein_g": 46.5, "carbs_g": 0, "fat_g": 5.4},
               {"name": "Bulgur pilavı", "portion_g": 180, "calories": 252, "protein_g": 6.8, "carbs_g": 50.4, "fat_g": 3.2},
               {"name": "Çoban salata", "portion_g": 120, "calories": 70, "protein_g": 1.4, "carbs_g": 6.5, "fat_g": 4.6}],
     "fiber_g": 9.5, "vitamins": ["B3", "B6", "C", "A"]},
    {"items": [{"name": "Mercimek çorbası", "portion_g": 300, "calories": 195, "protein_g": 11.7, "carbs_g": 29.4, "fat_g": 3.6},
               {"name": "Tam buğday ekmeği", "portion_g": 50, "calories": 124, "protein_g": 4.9, "carbs_g": 21.0, "fat_g": 1.7}],
     "fiber_g": 10.2, "vitamins": ["B1", "B9", "Demir"]},
    {"items": [{"name": "Yulaf ezmesi", "portion_g": 60, "calories": 233, "protein_g": 8.1, "carbs_g": 39.8, "fat_g": 4.1},
               {"name": "Muz", "portion_g": 110, "calories": 98, "protein_g": 1.2, "carbs_g": 25.1, "fat_g": 0.4},
               {"name": "Fıstık ezmesi", "portion_g": 16, "calories": 94, "protein_g": 4.0, "carbs_g": 3.2, "fat_g": 8.0}],
     "fiber_g": 8.1, "vitamins": ["B6", "E", "Magnezyum"]},
]


def _demo(image: bytes) -> dict:
    """Gerçek analiz yapmaz: aynı fotoğraf hep aynı örnek tabağı döndürür. Sunumda internet yoksa kullan."""
    index = int(hashlib.sha256(image).hexdigest(), 16) % len(DEMO_PLATES)
    result = normalize({**DEMO_PLATES[index], "confidence": "orta",
                        "note": "Demo modu: gerçek analiz için .env dosyasına GEMINI_API_KEY ekle."})
    result.update(provider="demo", model="demo")
    return result
