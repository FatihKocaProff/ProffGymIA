"""Yazılan öğün metninden besin değeri hesaplama (internetsiz, yerel besin tablosu).

Örnek: "2 yumurta, 1 dilim ekmek, 30 g beyaz peynir ve 1 bardak çay"
  -> her yiyecek ayrı ayrı tanınır, miktar ve birim okunur, gram hesaplanır,
     100 g başına değerlerden kalori ve makrolar bulunur.

Yapay zeka anahtarı varsa food_ai.analyze_text önce modele sorar; anahtar yoksa
veya model yanıt vermezse bu modül kullanılır. Değerler TürKomp / USDA ortalamalarına
yakın, yuvarlanmış yaklaşık değerlerdir.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Food:
    name: str
    aliases: tuple[str, ...]
    kcal: float
    protein: float
    carbs: float
    fat: float
    fiber: float = 0.0
    portion: float = 100.0
    units: dict = field(default_factory=dict)


def F(name, aliases, kcal, p, c, f, fiber=0.0, portion=100.0, **units):
    return Food(name, tuple(aliases), kcal, p, c, f, fiber, portion, units)


FOODS: list[Food] = [
    F("Tavuk göğsü", ["tavuk göğsü", "tavuk göğüs", "tavuk eti", "ızgara tavuk", "haşlanmış tavuk", "tavuk", "piliç"], 165, 31, 0, 3.6, portion=150, adet=150),
    F("Tavuk but", ["tavuk but", "but", "baget"], 180, 25, 0, 8.5, portion=150, adet=110),
    F("Tavuk şiş", ["tavuk şiş", "tavuk kebap"], 165, 25, 2, 6.5, portion=200, adet=100),
    F("Tavuk sote", ["tavuk sote", "tavuk haşlama"], 130, 15, 4, 6, portion=250),
    F("Tavuk döner", ["tavuk döner"], 190, 22, 3, 10, portion=150),
    F("Et döner", ["et döner", "döner"], 250, 18, 4, 18, portion=150),
    F("Dürüm", ["dürüm", "tavuk dürüm", "et dürüm", "döner dürüm"], 210, 12, 22, 8, portion=300, adet=300),
    F("Izgara köfte", ["köfte", "ızgara köfte", "kasap köfte", "inegöl köfte"], 250, 17, 6, 18, portion=150, adet=30),
    F("Kıyma", ["kıyma"], 250, 26, 0, 17, portion=100),
    F("Izgara kırmızı et", ["dana eti", "kırmızı et", "biftek", "bonfile", "antrikot", "dana", "et", "eti"], 220, 27, 0, 12, portion=150),
    F("Kuzu eti", ["kuzu eti", "kuzu pirzola", "pirzola", "kuzu"], 250, 25, 0, 17, portion=150, adet=60),
    F("Adana kebap", ["adana kebap", "urfa kebap", "adana", "kebap", "şiş kebap"], 280, 17, 3, 22, portion=200, adet=100),
    F("İskender", ["iskender", "iskender kebap"], 200, 12, 10, 12.5, portion=350),
    F("Hindi göğsü", ["hindi göğsü", "hindi eti", "hindi"], 135, 30, 0, 1.5, portion=150),
    F("Hindi füme", ["hindi füme", "hindi jambon", "jambon"], 110, 18, 3, 3, portion=30, dilim=15),
    F("Ton balığı", ["ton balığı", "ton"], 130, 27, 0, 2.5, portion=80, kutu=120),
    F("Somon", ["somon"], 206, 22, 0, 12, portion=150),
    F("Izgara balık", ["balık", "levrek", "çupra", "alabalık", "palamut", "uskumru"], 125, 23, 0, 3.5, portion=150),
    F("Hamsi tava", ["hamsi", "hamsi tava"], 240, 18, 8, 15, portion=150),
    F("Karides", ["karides"], 99, 24, 0.2, 0.3, portion=100),
    F("Yumurta", ["yumurta", "haşlanmış yumurta", "rafadan", "sahanda yumurta", "yumurta beyazı"], 143, 12.6, 0.7, 9.5, portion=50, adet=50),
    F("Omlet", ["omlet"], 155, 11, 1.5, 12, portion=120),
    F("Menemen", ["menemen"], 110, 6, 5, 8, portion=250),
    F("Sucuk", ["sucuk"], 450, 20, 2, 40, portion=40, dilim=8),
    F("Sosis", ["sosis"], 290, 11, 3, 26, portion=80, adet=40),
    F("Pastırma", ["pastırma"], 250, 30, 1, 13, portion=30, dilim=8),
    F("Salam", ["salam"], 300, 13, 2, 26, portion=30, dilim=10),
    F("Süt", ["süt", "sütü", "sütlü", "tam yağlı süt", "yarım yağlı süt", "laktozsuz süt"], 61, 3.2, 4.7, 3.3, portion=200),
    F("Yoğurt", ["yoğurt", "yogurt"], 61, 3.5, 4.7, 3.3, portion=150, kase=200, yemek_kasigi=20),
    F("Süzme yoğurt", ["süzme yoğurt", "yunan yoğurdu", "greek yoğurt"], 97, 9, 4, 5, portion=150, kase=200),
    F("Ayran", ["ayran"], 36, 1.7, 2.5, 1.9, portion=200, adet=200, kutu=200),
    F("Kefir", ["kefir"], 55, 3.3, 4.5, 2.5, portion=200),
    F("Beyaz peynir", ["beyaz peynir", "peynir", "ezine", "tulum peyniri", "tulum"], 264, 16, 1.5, 21, portion=30, dilim=30),
    F("Kaşar peyniri", ["kaşar peyniri", "kaşar", "eski kaşar", "çeçil", "dil peyniri", "çedar", "cheddar"], 380, 26, 1.5, 30, portion=30, dilim=20),
    F("Lor peyniri", ["lor peyniri", "lor", "çökelek", "light lor"], 100, 13, 3, 4, portion=50, yemek_kasigi=20),
    F("Labne", ["labne", "krem peynir"], 230, 6, 4, 21, portion=30, yemek_kasigi=20),
    F("Tereyağı", ["tereyağı", "tereyağ", "margarin"], 717, 0.9, 0.1, 81, portion=10, yemek_kasigi=13, tatli_kasigi=7, cay_kasigi=4),
    F("Ekmek", ["ekmek", "beyaz ekmek", "somun", "francala", "baget ekmek"], 265, 9, 49, 3.2, 2.7, portion=50, dilim=25, adet=250),
    F("Tam buğday ekmeği", ["tam buğday ekmeği", "tam buğday", "kepekli ekmek", "esmer ekmek"], 247, 13, 41, 3.4, 7, portion=50, dilim=25, adet=250),
    F("Çavdar ekmeği", ["çavdar ekmeği", "çavdar"], 259, 8.5, 48, 3.3, 5.8, portion=50, dilim=25, adet=250),
    F("Lavaş", ["lavaş", "tortilla", "yufka"], 275, 9, 55, 1.5, 2, portion=65, adet=65),
    F("Simit", ["simit", "gevrek"], 310, 10, 55, 6, 3, portion=100, adet=100),
    F("Poğaça", ["poğaça"], 360, 8, 42, 18, 1.5, portion=70, adet=70),
    F("Açma", ["açma"], 380, 7, 45, 19, 1.5, portion=80, adet=80),
    F("Börek", ["börek", "su böreği", "peynirli börek", "kol böreği", "sigara böreği", "ıspanaklı börek"], 280, 10, 25, 16, 1.5, portion=150, adet=40, dilim=120),
    F("Gözleme", ["gözleme"], 250, 9, 32, 10, 2, portion=200, adet=200),
    F("Pide", ["pide", "kıymalı pide", "kaşarlı pide", "kuşbaşılı pide"], 250, 11, 30, 9, 2, portion=300, adet=300, dilim=75),
    F("Lahmacun", ["lahmacun"], 220, 9.5, 30, 7, 2, portion=120, adet=120),
    F("Pizza", ["pizza"], 266, 11, 33, 10, 2.3, portion=200, dilim=100),
    F("Hamburger", ["hamburger", "burger", "cheeseburger"], 250, 13, 24, 11, 1.5, portion=220, adet=220),
    F("Tost", ["tost", "kaşarlı tost", "karışık tost", "ayvalık tostu"], 300, 13, 30, 14, 1.5, portion=120, adet=120),
    F("Sandviç", ["sandviç", "sandvic"], 250, 11, 28, 10, 2, portion=200, adet=200),
    F("Makarna", ["makarna", "spagetti", "erişte", "penne", "fettuccine"], 158, 5.8, 31, 0.9, 1.8, portion=200),
    F("Pirinç pilavı", ["pirinç pilavı", "pilav", "pilavı", "pirinç"], 165, 3, 30, 3.8, 0.4, portion=180),
    F("Bulgur pilavı", ["bulgur pilavı", "bulgur"], 140, 3.8, 26, 2.5, 4.5, portion=180),
    F("Kuskus", ["kuskus"], 112, 3.8, 23, 0.2, 1.4, portion=180),
    F("Mantı", ["mantı"], 180, 8, 25, 6, 1.5, portion=250),
    F("Yulaf ezmesi", ["yulaf ezmesi", "yulaf", "oats"], 389, 13.5, 66, 7, 10.6, portion=50, su_bardagi=90, bardak=90, kase=60, yemek_kasigi=10),
    F("Granola", ["granola", "müsli", "musli"], 450, 10, 64, 17, 7, portion=50, kase=60),
    F("Mısır gevreği", ["mısır gevreği", "corn flakes", "kahvaltılık gevrek"], 380, 7, 84, 1, 3, portion=30, kase=40),
    F("Haşlanmış patates", ["haşlanmış patates", "fırın patates", "patates püresi", "patates"], 87, 1.9, 20, 0.1, 1.8, portion=150, adet=150),
    F("Patates kızartması", ["patates kızartması", "kızartma patates", "cips patates", "kızarmış patates"], 312, 3.4, 41, 15, 3.8, portion=120),
    F("Kumpir", ["kumpir"], 180, 5, 20, 9, 2, portion=450, adet=450),
    F("Pankek", ["pankek", "pancake", "krep"], 227, 6.4, 28, 10, 1, portion=80, adet=40),
    F("Mercimek çorbası", ["mercimek çorbası", "kırmızı mercimek çorbası"], 65, 3.9, 9.8, 1.2, 1.6, portion=300, kase=300),
    F("Ezogelin çorbası", ["ezogelin", "ezogelin çorbası"], 60, 3, 9, 1.5, 1.5, portion=300, kase=300),
    F("Tavuk suyu çorba", ["tavuk suyu çorba", "tavuk çorbası", "tavuk suyu", "şehriye çorbası"], 45, 3, 5, 1.5, 0.3, portion=300, kase=300),
    F("Domates çorbası", ["domates çorbası"], 50, 1.5, 7, 2, 1, portion=300, kase=300),
    F("Yayla çorbası", ["yayla çorbası"], 55, 2.5, 7, 2, 0.3, portion=300, kase=300),
    F("Çorba", ["çorba", "işkembe çorbası", "tarhana çorbası", "sebze çorbası"], 55, 2.5, 7.5, 1.8, 1, portion=300, kase=300),
    F("Kuru fasulye", ["kuru fasulye", "fasulye pilaki", "fasulye", "barbunya"], 111, 6, 14, 3.5, 5, portion=250),
    F("Nohut yemeği", ["nohut yemeği", "etli nohut"], 120, 6, 15, 4, 5, portion=250),
    F("Haşlanmış nohut", ["nohut", "haşlanmış nohut", "humus"], 164, 8.9, 27, 2.6, 7.6, portion=100),
    F("Haşlanmış mercimek", ["yeşil mercimek", "mercimek", "mercimek salatası"], 116, 9, 20, 0.4, 7.9, portion=150),
    F("Zeytinyağlı sebze yemeği", ["taze fasulye", "türlü", "sebze yemeği", "bamya", "pırasa", "kabak yemeği", "bezelye"], 70, 1.8, 7, 4, 3, portion=200),
    F("Ispanak yemeği", ["ıspanak", "ıspanak yemeği"], 60, 3, 5, 3, 2.5, portion=200),
    F("Karnıyarık", ["karnıyarık", "musakka", "imam bayıldı"], 130, 5, 7, 9, 2.5, portion=250, adet=250),
    F("Yaprak sarma", ["yaprak sarma", "sarma", "dolma", "zeytinyağlı dolma"], 150, 2.5, 20, 7, 2, portion=150, adet=25),
    F("Etli biber dolması", ["biber dolması", "etli dolma", "kabak dolması"], 110, 5, 10, 5.5, 1.5, portion=240, adet=120),
    F("Çiğ köfte", ["çiğ köfte"], 160, 5, 30, 2.5, 4, portion=150, adet=30),
    F("Çiğ köfte dürüm", ["çiğ köfte dürüm"], 180, 5, 32, 3.5, 4, portion=300, adet=300),
    F("Tavuk nugget", ["nugget", "tavuk nugget", "schnitzel", "şinitzel"], 296, 15, 16, 19, 1, portion=120, adet=18),
    F("Zeytinyağlı salata", ["salata", "çoban salata", "mevsim salata", "yeşil salata", "gavurdağı"], 58, 1.2, 5.4, 3.8, 1.8, portion=150),
    F("Domates", ["domates", "çeri domates"], 18, 0.9, 3.9, 0.2, 1.2, portion=120, adet=120),
    F("Salatalık", ["salatalık", "hıyar"], 15, 0.7, 3.6, 0.1, 0.5, portion=150, adet=150),
    F("Biber", ["biber", "yeşil biber", "közlenmiş biber"], 20, 0.9, 4.6, 0.2, 1.7, portion=60, adet=30),
    F("Yeşillik", ["marul", "roka", "maydanoz", "yeşillik", "dereotu", "nane"], 15, 1.4, 2.9, 0.2, 1.5, portion=50),
    F("Havuç", ["havuç"], 41, 0.9, 10, 0.2, 2.8, portion=70, adet=70),
    F("Brokoli", ["brokoli", "karnabahar", "brüksel lahanası"], 35, 2.4, 7, 0.4, 3.3, portion=150),
    F("Mantar", ["mantar"], 22, 3.1, 3.3, 0.3, 1, portion=100),
    F("Zeytin", ["zeytin", "siyah zeytin", "yeşil zeytin"], 190, 1.5, 5, 18, 3.3, portion=30, adet=4),
    F("Muz", ["muz", "muzlu"], 89, 1.1, 22.8, 0.3, 2.6, portion=120, adet=120),
    F("Elma", ["elma", "yeşil elma"], 52, 0.3, 14, 0.2, 2.4, portion=180, adet=180),
    F("Portakal", ["portakal"], 47, 0.9, 12, 0.1, 2.4, portion=150, adet=150),
    F("Mandalina", ["mandalina"], 53, 0.8, 13.3, 0.3, 1.8, portion=80, adet=80),
    F("Armut", ["armut"], 57, 0.4, 15, 0.1, 3.1, portion=170, adet=170),
    F("Çilek", ["çilek"], 32, 0.7, 7.7, 0.3, 2, portion=150, adet=12),
    F("Üzüm", ["üzüm"], 69, 0.7, 18, 0.2, 0.9, portion=150, salkim=150, avuc=80),
    F("Karpuz", ["karpuz"], 30, 0.6, 7.6, 0.2, 0.4, portion=300, dilim=300),
    F("Kavun", ["kavun"], 34, 0.8, 8.2, 0.2, 0.9, portion=200, dilim=200),
    F("Kayısı", ["kayısı"], 48, 1.4, 11, 0.4, 2, portion=105, adet=35),
    F("Şeftali", ["şeftali", "nektarin"], 39, 0.9, 9.5, 0.3, 1.5, portion=150, adet=150),
    F("Kiraz", ["kiraz", "vişne"], 63, 1.1, 16, 0.2, 2.1, portion=150, adet=8, avuc=80),
    F("Hurma", ["hurma"], 282, 2.5, 75, 0.4, 8, portion=30, adet=10),
    F("Kuru kayısı", ["kuru kayısı"], 241, 3.4, 63, 0.5, 7.3, portion=30, adet=8),
    F("Kuru üzüm", ["kuru üzüm"], 299, 3, 79, 0.5, 3.7, portion=30, yemek_kasigi=10),
    F("İncir", ["incir", "kuru incir"], 249, 3.3, 64, 0.9, 9.8, portion=40, adet=20),
    F("Avokado", ["avokado"], 160, 2, 8.5, 14.7, 6.7, portion=150, adet=150),
    F("Ceviz", ["ceviz", "ceviz içi"], 654, 15, 14, 65, 6.7, portion=30, adet=5),
    F("Badem", ["badem"], 579, 21, 22, 50, 12.5, portion=30, adet=1.2),
    F("Fındık", ["fındık"], 628, 15, 17, 61, 9.7, portion=30, adet=1.5),
    F("Yer fıstığı", ["yer fıstığı", "fıstık", "antep fıstığı", "kaju", "kuruyemiş"], 567, 26, 16, 49, 8.5, portion=30, adet=1),
    F("Fıstık ezmesi", ["fıstık ezmesi", "badem ezmesi"], 588, 25, 20, 50, 6, portion=16, yemek_kasigi=16, tatli_kasigi=8, cay_kasigi=5),
    F("Zeytinyağı / sıvı yağ", ["zeytinyağı", "zeytin yağı", "sıvı yağ", "ayçiçek yağı", "yağ"], 884, 0, 0, 100, portion=10, yemek_kasigi=13, tatli_kasigi=5, cay_kasigi=2),
    F("Bal", ["bal", "balı"], 304, 0.3, 82, 0, portion=20, yemek_kasigi=21, tatli_kasigi=10, cay_kasigi=7),
    F("Reçel", ["reçel", "marmelat"], 250, 0.4, 65, 0.1, 1, portion=20, yemek_kasigi=20, tatli_kasigi=10, cay_kasigi=6),
    F("Tahin", ["tahin"], 595, 17, 21, 54, 9, portion=15, yemek_kasigi=15, tatli_kasigi=7),
    F("Pekmez", ["pekmez", "tahin pekmez"], 290, 0, 74, 0, portion=20, yemek_kasigi=20, tatli_kasigi=10),
    F("Çikolatalı krema", ["nutella", "çikolatalı krema", "kakaolu fındık kreması"], 539, 6, 57, 31, 3.4, portion=20, yemek_kasigi=20, tatli_kasigi=10),
    F("Şeker", ["şeker", "toz şeker", "küp şeker", "şekerli"], 387, 0, 100, 0, portion=5, adet=3, yemek_kasigi=12, tatli_kasigi=6, cay_kasigi=4),
    F("Çay", ["çay", "çayı", "yeşil çay", "bitki çayı", "ıhlamur", "adaçayı"], 1, 0, 0.2, 0, portion=100, bardak=100),
    F("Sade Türk kahvesi", ["türk kahvesi"], 6, 0.2, 0.8, 0.2, portion=70),
    F("Sade kahve", ["kahve", "filtre kahve", "americano", "espresso", "neskafe", "nescafe"], 2, 0.3, 0, 0, portion=200),
    F("Latte", ["latte", "sütlü kahve", "cappuccino", "kapuçino", "flat white"], 54, 3.3, 4.6, 2.5, portion=300, adet=300),
    F("Kola", ["kola", "cola", "gazoz", "fanta", "sprite", "gazlı içecek", "ice tea", "soğuk çay"], 42, 0, 10.6, 0, portion=330, kutu=330, adet=330),
    F("Şekersiz kola", ["kola zero", "zero", "light kola", "diet kola", "cola zero"], 0, 0, 0, 0, portion=330, kutu=330, adet=330),
    F("Meyve suyu", ["meyve suyu", "vişne suyu", "şeftali suyu", "elma suyu"], 46, 0.5, 11, 0.1, portion=200, kutu=200),
    F("Portakal suyu", ["portakal suyu", "taze sıkma"], 45, 0.7, 10.4, 0.2, portion=200),
    F("Protein tozu", ["protein tozu", "whey", "protein shake", "protein", "kazein"], 400, 80, 8, 6, portion=30, olcek=30, adet=30),
    F("Bira", ["bira"], 43, 0.5, 3.6, 0, portion=500, kutu=500, sise=500),
    F("Şarap", ["şarap"], 83, 0.1, 2.6, 0, portion=150, kadeh=150),
    F("Su", ["su", "maden suyu", "soda"], 0, 0, 0, 0, portion=200),
    F("Baklava", ["baklava", "kadayıf", "şöbiyet"], 430, 6, 50, 23, 2, portion=105, adet=35, dilim=35),
    F("Künefe", ["künefe"], 330, 6, 40, 16, 1, portion=150),
    F("Sütlaç", ["sütlaç", "muhallebi", "kazandibi", "puding", "tavuk göğsü tatlısı"], 130, 3.5, 22, 3, 0.2, portion=200, kase=200),
    F("Kek", ["kek", "keki", "muffin", "browni", "brownie"], 380, 5.5, 52, 17, 1.5, portion=60, dilim=60, adet=60),
    F("Yaş pasta", ["pasta", "yaş pasta", "cheesecake", "tiramisu"], 350, 5, 45, 17, 1, portion=120, dilim=120),
    F("Kurabiye", ["kurabiye"], 480, 6, 62, 23, 2, portion=40, adet=20),
    F("Bisküvi", ["bisküvi", "kraker", "gofret"], 450, 7, 70, 16, 2.5, portion=40, adet=8, paket=80),
    F("Sütlü çikolata", ["çikolata", "sütlü çikolata", "çikolatalı gofret"], 535, 7.6, 59, 30, 3.4, portion=40, adet=40, kare=6),
    F("Bitter çikolata", ["bitter çikolata", "bitter"], 600, 7.8, 46, 43, 11, portion=30, adet=40, kare=6),
    F("Dondurma", ["dondurma"], 207, 3.5, 24, 11, 0.7, portion=100, top=50, adet=70),
    F("Cips", ["cips", "patates cipsi", "mısır cipsi"], 536, 7, 53, 35, 4.4, portion=40, paket=40),
    F("Lokum", ["lokum"], 380, 0.2, 94, 0.5, portion=30, adet=15),
    F("Helva", ["helva", "tahin helvası", "irmik helvası"], 520, 12, 55, 30, 3, portion=50, dilim=50),
    F("Patlamış mısır", ["patlamış mısır", "popcorn"], 387, 13, 78, 4.5, 15, portion=30),
]

GENERIC_UNITS = {
    "su_bardagi": 200, "bardak": 200, "cay_bardagi": 100, "fincan": 70, "kupa": 250,
    "kase": 250, "tabak": None, "porsiyon": None, "kepce": 150,
    "yemek_kasigi": 15, "tatli_kasigi": 7, "cay_kasigi": 3,
    "avuc": 30, "dilim": 30, "kutu": 250, "paket": 50, "sise": 500,
    "olcek": 30, "top": 50, "kadeh": 150, "kare": 6, "salkim": 150,
}

UNIT_LABELS = {
    "su_bardagi": "su bardağı", "bardak": "bardak", "cay_bardagi": "çay bardağı", "fincan": "fincan", "kupa": "kupa",
    "kase": "kase", "tabak": "tabak", "porsiyon": "porsiyon", "kepce": "kepçe",
    "yemek_kasigi": "yemek kaşığı", "tatli_kasigi": "tatlı kaşığı", "cay_kasigi": "çay kaşığı",
    "avuc": "avuç", "dilim": "dilim", "kutu": "kutu", "paket": "paket", "sise": "şişe",
    "olcek": "ölçek", "top": "top", "kadeh": "kadeh", "kare": "kare", "salkim": "salkım", "adet": "adet",
}

UNIT_WORDS: list[tuple[tuple[str, ...], str]] = [
    (("su", "bardagi"), "su_bardagi"), (("su", "bardak"), "su_bardagi"),
    (("cay", "bardagi"), "cay_bardagi"), (("cay", "bardak"), "cay_bardagi"),
    (("yemek", "kasigi"), "yemek_kasigi"), (("yemek", "kasik"), "yemek_kasigi"),
    (("tatli", "kasigi"), "tatli_kasigi"), (("tatli", "kasik"), "tatli_kasigi"),
    (("cay", "kasigi"), "cay_kasigi"), (("cay", "kasik"), "cay_kasigi"),
    (("bardak",), "bardak"), (("bardagi",), "bardak"), (("fincan",), "fincan"), (("kupa",), "kupa"),
    (("kase",), "kase"), (("kasesi",), "kase"), (("canak",), "kase"), (("kepce",), "kepce"),
    (("tabak",), "tabak"), (("tabagi",), "tabak"), (("porsiyon",), "porsiyon"), (("porsiyonu",), "porsiyon"),
    (("kasik",), "yemek_kasigi"), (("kasigi",), "yemek_kasigi"), (("avuc",), "avuc"), (("avucu",), "avuc"),
    (("dilim",), "dilim"), (("dilimi",), "dilim"), (("kutu",), "kutu"), (("kutusu",), "kutu"),
    (("paket",), "paket"), (("paketi",), "paket"), (("sise",), "sise"), (("sisesi",), "sise"),
    (("olcek",), "olcek"), (("olcegi",), "olcek"), (("top",), "top"), (("topu",), "top"),
    (("kadeh",), "kadeh"), (("kare",), "kare"), (("salkim",), "salkim"),
    (("adet",), "adet"), (("tane",), "adet"), (("tanesi",), "adet"),
]

MASS_UNITS = {"g": 1, "gr": 1, "gram": 1, "grams": 1, "kg": 1000, "kilo": 1000, "ml": 1, "cl": 10, "lt": 1000, "l": 1000, "litre": 1000}

NUMBER_WORDS = {"bir": 1, "iki": 2, "uc": 3, "dort": 4, "bes": 5, "alti": 6, "yedi": 7, "sekiz": 8, "dokuz": 9, "on": 10,
                "yarim": 0.5, "ceyrek": 0.25}

_FOLD = str.maketrans({"ç": "c", "ğ": "g", "ı": "i", "ö": "o", "ş": "s", "ü": "u", "â": "a", "î": "i", "û": "u", "é": "e"})


def fold(text: str) -> str:
    """Türkçe küçük harfe çevirip karakterleri sadeleştirir: 'Çorbası' -> 'corbasi'."""
    text = (text or "").replace("İ", "i").replace("I", "ı").lower()
    return text.translate(_FOLD)


STOP_TOKENS = {"salamura", "kolay", "kolaylik", "pastane", "elmas", "biraz"}


def _word_matches(alias_word: str, token: str) -> bool:
    """Ek almış kelimeleri de tanır: tavuk~tavuğu, ekmek~ekmekle, pilav~pilavı, kebap~kebabı.

    Olumsuz ekleri (şekersiz, yağsız) eşleştirmez.
    """
    if token == alias_word:
        return True
    if len(alias_word) < 4 or token in STOP_TOKENS:
        return False
    if token.startswith(alias_word) and len(token) - len(alias_word) <= 4:
        return not token[len(alias_word):].startswith(("siz", "suz"))
    last = alias_word[-1]
    soft = {"k": "g", "p": "b", "t": "d", "c": "c"}.get(last)
    stem = alias_word[:-1]
    return (bool(soft) and token.startswith(stem + soft) and len(token) - len(alias_word) <= 4
            and not token[len(alias_word):].startswith(("siz", "suz")))


_ALIASES: list[tuple[tuple[str, ...], Food]] = sorted(
    ((tuple(fold(a).split()), food) for food in FOODS for a in (*food.aliases, *(() if "(" in food.name else (food.name,)))),
    key=lambda x: (-len(x[0]), -sum(len(w) for w in x[0])),
)

_TOKEN_RE = re.compile(r"\d+(?:[.,]\d+)?(?:/\d+)?|[a-z]+")
_SPLIT_RE = re.compile(r"[;\n+&]|(?<!\d),|,(?!\d)|\bve\b|\bile\b|\bayrica\b|\byaninda\b|\barti\b")


def _match_at(tokens: list[str], i: int) -> tuple[int, Food] | None:
    best = None
    for words, food in _ALIASES:
        n = len(words)
        if i + n > len(tokens):
            continue
        if all(_word_matches(w, tokens[i + k]) for k, w in enumerate(words)):
            exact = all(tokens[i + k] == w for k, w in enumerate(words))
            score = (n, exact, sum(len(w) for w in words))
            if best is None or score > best[0]:
                best = (score, n, food)
    return (best[1], best[2]) if best else None


def _to_number(tok: str) -> float | None:
    if "/" in tok:
        a, b = tok.split("/", 1)
        try:
            return float(a.replace(",", ".")) / float(b)
        except (ValueError, ZeroDivisionError):
            return None
    try:
        return float(tok.replace(",", "."))
    except ValueError:
        return NUMBER_WORDS.get(tok)


LIQUID_UNITS = {"ml", "cl", "lt", "l", "litre"}


def _parse_quantity(tokens: list[str]) -> tuple[float | None, str | None, float | None, bool]:
    """Miktar parçalarından (sayı, birim, kütle_gram, sıvı_mı) çıkarır.

    '2' -> (2, None, None) · '1 kase' -> (1, 'kase', None) · '200 g' -> (200, None, 200)
    'yarim' -> (0.5, ...) · 'bir bucuk dilim' -> (1.5, 'dilim', None)
    """
    number = None
    unit = None
    mass = None
    liquid = False
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        m = re.fullmatch(r"(\d+(?:[.,]\d+)?)(kg|gr|g|ml|cl|lt|l)", tok)
        if m:
            mass = float(m.group(1).replace(",", ".")) * MASS_UNITS[m.group(2)]
            liquid = m.group(2) in LIQUID_UNITS
            i += 1
            continue
        num = _to_number(tok)
        if num is not None and (tok[0].isdigit() or tok in NUMBER_WORDS):
            if tok == "yarim" and number is not None:
                number += 0.5
            else:
                number = num if number is None else number
            i += 1
            continue
        if tok == "bucuk" and number is not None:
            number += 0.5
            i += 1
            continue
        if tok in MASS_UNITS and number is not None:
            mass = number * MASS_UNITS[tok]
            liquid = tok in LIQUID_UNITS
            i += 1
            continue
        matched = False
        for words, key in UNIT_WORDS:
            n = len(words)
            if tuple(tokens[i : i + n]) == words:
                unit = key
                i += n
                matched = True
                break
        if not matched:
            i += 1
    return number, unit, mass, liquid


def _fmt(n: float) -> str:
    """0.5 -> 'yarım', 1.5 -> '1,5', 2.0 -> '2'."""
    if n == 0.5:
        return "yarım"
    if n == 0.25:
        return "çeyrek"
    return f"{n:g}".replace(".", ",")


def _grams_for(food: Food, number: float | None, unit: str | None, mass: float | None,
               liquid: bool = False) -> tuple[float, str, bool]:
    """(gram, okunabilir miktar, varsayılan_porsiyon_mu)."""
    if mass is not None:
        return mass, f"{_fmt(mass)} {'ml' if liquid else 'g'}", False
    n = number if number is not None else 1
    if unit:
        if unit == "adet":
            per = food.units.get("adet", food.portion)
        elif unit in food.units:
            per = food.units[unit]
        elif unit in ("porsiyon", "tabak"):
            per = food.portion
        elif unit == "kase" and food.portion >= 150:
            per = food.portion
        else:
            per = GENERIC_UNITS.get(unit) or food.portion
        return n * per, f"{_fmt(n)} {UNIT_LABELS.get(unit, unit)}", False
    if number is not None:
        if "adet" in food.units:
            return n * food.units["adet"], _fmt(n) if n in (0.5, 0.25) else f"{_fmt(n)} adet", False
        if n >= 20:
            return n, f"{_fmt(n)} g", False
        return n * food.portion, f"{_fmt(n)} porsiyon", False
    label = "1 adet" if "adet" in food.units and food.units["adet"] == food.portion else "1 porsiyon"
    return food.portion, label, True


def _item(food: Food, grams: float, qty_text: str) -> dict:
    k = grams / 100.0
    return {
        "name": f"{food.name} ({qty_text})",
        "portion_g": round(grams),
        "calories": round(food.kcal * k),
        "protein_g": round(food.protein * k, 1),
        "carbs_g": round(food.carbs * k, 1),
        "fat_g": round(food.fat * k, 1),
        "_fiber": food.fiber * k,
    }


def _unit_at(tokens: list[str], i: int) -> int:
    """i konumunda bir birim ifadesi ('çay bardağı', 'dilim') başlıyorsa uzunluğunu döner."""
    for words, _key in UNIT_WORDS:
        n = len(words)
        if tuple(tokens[i : i + n]) == words:
            return n
    return 0


def _segments(text: str) -> list[tuple[str, str]]:
    """Metni virgül, 've', 'ile', '+' vb. yerlerden böler: [(sadeleştirilmiş, orijinal küçük harf), ...]."""
    lower = (text or "").replace("İ", "i").replace("I", "ı").lower()
    folded = lower.translate(_FOLD)
    if len(folded) != len(lower):
        lower = folded
    out, pos = [], 0
    for m in _SPLIT_RE.finditer(folded):
        out.append((folded[pos : m.start()], lower[pos : m.start()]))
        pos = m.end()
    out.append((folded[pos:], lower[pos:]))
    return [(f.strip(), o.strip()) for f, o in out if f.strip()]


def analyze_text_local(text: str) -> dict:
    """Metni yerel besin tablosuyla analiz eder. Çıktı food_ai.normalize ile aynı yapıdadır."""
    items: list[dict] = []
    unmatched: list[str] = []
    defaulted = False

    for seg, original in _segments(text):
        tokens = _TOKEN_RE.findall(seg)
        if not tokens:
            continue
        matches: list[tuple[int, int, Food]] = []
        i = 0
        while i < len(tokens):
            unit_len = _unit_at(tokens, i)
            if unit_len:
                i += unit_len
                continue
            hit = _match_at(tokens, i)
            if hit:
                n, food = hit
                matches.append((i, i + n, food))
                i += n
            else:
                i += 1
        if not matches:
            words = [w for w in re.findall(r"[^\W\d_]+", original) if fold(w) not in NUMBER_WORDS and fold(w) not in MASS_UNITS]
            if words:
                unmatched.append(" ".join(words)[:40])
            continue
        for idx, (start, end, food) in enumerate(matches):
            prev_end = matches[idx - 1][1] if idx else 0
            number, unit, mass, liquid = _parse_quantity(tokens[prev_end:start])
            if number is None and unit is None and mass is None and idx == len(matches) - 1:
                number, unit, mass, liquid = _parse_quantity(tokens[end:])
            grams, qty_text, was_default = _grams_for(food, number, unit, mass, liquid)
            defaulted = defaulted or was_default
            items.append(_item(food, grams, qty_text))

    fiber = sum(i.pop("_fiber") for i in items)
    if not items:
        confidence = "düşük"
    elif unmatched:
        confidence = "düşük"
    elif defaulted:
        confidence = "orta"
    else:
        confidence = "yüksek"

    notes = []
    if unmatched:
        notes.append("Tanınmayan: " + ", ".join(unmatched) + ". Bunların değerini elle ekleyebilirsin.")
    if defaulted:
        notes.append("Miktar yazılmayanlar için 1 porsiyon varsayıldı; daha doğru sonuç için miktar yaz (ör. 2 yumurta, 150 g tavuk).")
    if not items and not unmatched:
        notes.append("Ne yediğini yaz: ör. 2 yumurta, 1 dilim ekmek, 1 bardak çay.")

    return {
        "items": items,
        "fiber_g": round(fiber, 1),
        "vitamins": [],
        "confidence": confidence,
        "note": " ".join(notes),
        "unmatched": unmatched,
    }
