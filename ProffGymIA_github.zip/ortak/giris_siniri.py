"""Kaba kuvvet (şifre deneme) koruması: aynı IP + e-posta için çok sayıda hatalı girişte kısa süre kilitler.

Bellekte tutulur (tek sunucu süreci için yeterli). Başarılı giriş sayacı sıfırlar.
"""
import threading
import time

MAX_FAILURES = 5
WINDOW_SECONDS = 15 * 60
LOCK_SECONDS = 5 * 60

_lock = threading.Lock()
_failures: dict[str, list[float]] = {}
_locked_until: dict[str, float] = {}


def _key(ip: str | None, email: str) -> str:
    return f"{ip or '?'}|{email.strip().lower()}"


def retry_after(ip: str | None, email: str) -> int:
    """Kilitliyse kalan saniye, değilse 0."""
    with _lock:
        until = _locked_until.get(_key(ip, email), 0)
    return max(0, int(until - time.monotonic() + 0.999))


def record_failure(ip: str | None, email: str) -> None:
    now = time.monotonic()
    k = _key(ip, email)
    with _lock:
        recent = [t for t in _failures.get(k, []) if now - t < WINDOW_SECONDS]
        recent.append(now)
        if len(recent) >= MAX_FAILURES:
            _locked_until[k] = now + LOCK_SECONDS
            recent = []
        _failures[k] = recent
        if len(_failures) > 10_000:
            _failures.clear()


def record_success(ip: str | None, email: str) -> None:
    k = _key(ip, email)
    with _lock:
        _failures.pop(k, None)
        _locked_until.pop(k, None)


def reset() -> None:
    """Testler için."""
    with _lock:
        _failures.clear()
        _locked_until.clear()
