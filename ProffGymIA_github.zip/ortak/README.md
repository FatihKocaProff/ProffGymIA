# ortak

ProffGymIA ve Kepçe'nin paylaştığı kod: `beslenme/` (yemek fotoğrafı ve yazılan öğün analizi) ve
`giris_siniri.py` (hatalı giriş denemesi sınırı). `app/services/food_ai.py` ve `food_text.py`
yalnızca buradaki modüllere yönlendirir.

## Nasıl kurulur

`pyproject.toml` sayesinde normal bir Python paketidir (`proffgym-ortak`).

- **ProffGymIA:** `backend/requirements.txt` içindeki `-e ../../ortak` satırı bu klasörü düzenlenebilir
  paket olarak kurar. `baslat.bat` bunu kendisi yapar; elle kurmak için backend klasöründe
  `.venv\Scripts\python -m pip install -r requirements.txt`.
- **Kepçe:** henüz eski yöntemle çalışıyor (`app/__init__.py` bu klasörü Python yoluna ekler).

Bu klasörü projelerin yanından taşıma: `ProffGymIA/` ve `Kepce/` ile aynı üst klasörde durmalı.
GitHub'a yüklerken de bu üst klasörü (ProffGymIA + ortak + Kepce) tek depo olarak yükle; yalnızca
`ProffGymIA/` klasörünü yüklersen ortak kod eksik kalır.
