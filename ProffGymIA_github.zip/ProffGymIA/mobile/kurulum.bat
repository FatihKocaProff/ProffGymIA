@echo off
cd /d "%~dp0"
python kurulum.py
pause
