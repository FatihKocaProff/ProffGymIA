# FitAI mobil (Flutter)

## İlk kurulum (bir kez)

1. Flutter 3.38 veya üstünü kur: https://docs.flutter.dev/get-started/install (Android Studio ile birlikte)
2. Bu klasörde:

```
python kurulum.py
```

Bu komut `android/` ve `ios/` klasörlerini oluşturur, kamera/bildirim izinlerini ve Gradle ayarlarını yapar, paketleri indirir.

## Çalıştırma

Telefonu USB ile bağla (Geliştirici seçenekleri → USB hata ayıklama açık) veya emülatör aç:

```
flutter run
```

Önce bilgisayarda `backend/baslat.bat` açık olmalı. Giriş ekranında **Sunucu adresi**:
- Emülatör: `http://10.0.2.2:8000`
- Gerçek telefon: `baslat.bat` penceresinde yazan `http://192.168.x.x:8000` (aynı Wi-Fi)

Form analizi ve kamera için gerçek telefon önerilir (emülatör kamerası vücut algılamada zayıftır).

## Ekranlar

| Sekme | İçerik |
|---|---|
| Ana sayfa | Kalan gün halkası, 60 sn'de yenilenen QR, su takibi, takviyeler ("Aldım"), metabolizma, bugünkü antrenman |
| Beslenme | Kilo grafiği ve tartı girişi, günlük makrolar, **Tabağı çek** (yapay zeka analizi), öğün listesi |
| Antrenman | PT'nin 14 günlük programı, "Tamamladım" |
| Form | Squat / biceps curl / omuz press; canlı kamera, iskelet, tekrar sayacı, sesli Türkçe uyarı |
| Ben | Profil (BMR için), takviyeler ve hatırlatma saatleri, salon paketleri, çıkış |

## Sorun giderme

- **Derleme hatası (Gradle / minSdk / desugaring):** `python kurulum.py` tekrar çalıştır; hata sürerse çıktıyı olduğu gibi paylaş.
- **"Sunucuya ulaşılamadı":** telefon ve bilgisayar aynı Wi-Fi'da mı, Windows güvenlik duvarı Python'a izin veriyor mu?
- **Sesli uyarı İngilizce aksanlı veya yok:** telefonun Ayarlar → Metin okuma (TTS) → Türkçe ses paketini indir.
