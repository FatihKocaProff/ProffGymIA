"""FitAI mobil uygulaması için tek seferlik kurulum.

Ne yapar?
  1. `flutter create` ile android/ ve ios/ klasörlerini oluşturur (lib/ altındaki kodlara dokunmaz)
  2. Kamera, bildirim ve yerel ağ (http) izinlerini AndroidManifest.xml'e ekler
  3. Paketlerin istediği Gradle ayarlarını yapar (minSdk 24, Java 17, desugaring)
  4. iOS için kamera/fotoğraf izin metinlerini ve iOS 15.5 hedefini ayarlar
  5. `flutter pub get` çalıştırır

Kullanım:  python kurulum.py      (mobile klasörünün içinde)
Tekrar çalıştırmak zararsızdır; zaten yapılmış adımları atlar.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MIN_AGP = (8, 11, 1)
GRADLE_FOR_AGP = "8.14.3"


def say(msg: str) -> None:
    print(f"  • {msg}")


def run(cmd: list[str]) -> None:
    print(f"\n$ {' '.join(cmd)}")
    exe = shutil.which(cmd[0])
    if not exe:
        sys.exit(f"'{cmd[0]}' bulunamadı. Flutter'ı kurup PATH'e ekle: https://docs.flutter.dev/get-started/install")
    result = subprocess.run([exe, *cmd[1:]], cwd=ROOT)
    if result.returncode != 0:
        sys.exit(f"Komut başarısız oldu: {' '.join(cmd)}")


def patch_manifest() -> None:
    path = ROOT / "android/app/src/main/AndroidManifest.xml"
    s = path.read_text(encoding="utf-8")
    if "FITAI_PATCHED" in s:
        return say("AndroidManifest zaten ayarlı")
    perms = "\n".join(
        f'    <uses-permission android:name="android.permission.{p}"/>'
        for p in ("INTERNET", "CAMERA", "POST_NOTIFICATIONS", "RECEIVE_BOOT_COMPLETED", "VIBRATE")
    )
    s = re.sub(r"(<manifest[^>]*>)", r"\1\n    <!-- FITAI_PATCHED -->\n" + perms.replace("\\", "\\\\"), s, count=1)
    s = s.replace("<application", '<application\n        android:usesCleartextTraffic="true"', 1)
    receivers = """
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
    </application>"""
    s = s.replace("</application>", receivers, 1)
    tts_query = """        <intent>
            <action android:name="android.intent.action.TTS_SERVICE" />
        </intent>
    </queries>"""
    if "<queries>" in s:
        s = s.replace("</queries>", tts_query, 1)
    else:
        s = s.replace("</manifest>", "    <queries>\n" + tts_query + "\n</manifest>", 1)
    s = s.replace('android:label="fitai"', 'android:label="FitAI"')
    path.write_text(s, encoding="utf-8")
    say("AndroidManifest: kamera, bildirim ve http izinleri eklendi")


def patch_app_gradle() -> None:
    kts = ROOT / "android/app/build.gradle.kts"
    groovy = ROOT / "android/app/build.gradle"
    path = kts if kts.exists() else groovy
    s = path.read_text(encoding="utf-8")
    if "FITAI_PATCHED" in s:
        return say(f"{path.name} zaten ayarlı")
    is_kts = path.suffix == ".kts"

    s, n = re.subn(r"minSdk(Version)?\s*=?\s*flutter\.minSdkVersion", "minSdk = 24" if is_kts else "minSdkVersion 24", s)
    if not n:
        s = re.sub(r"(defaultConfig\s*\{)", r"\1\n        minSdk = 24" if is_kts else r"\1\n        minSdkVersion 24", s, count=1)

    s = s.replace("VERSION_11", "VERSION_17").replace("VERSION_1_8", "VERSION_17").replace("JVM_11", "JVM_17")
    s = re.sub(r"jvmTarget\s*=\s*['\"]1[18]['\"]", "jvmTarget = '17'", s)

    desugar_flag = "isCoreLibraryDesugaringEnabled = true" if is_kts else "coreLibraryDesugaringEnabled true"
    if "compileOptions" in s:
        s = re.sub(r"(compileOptions\s*\{)", r"\1\n        " + desugar_flag, s, count=1)
    else:
        s = re.sub(r"(android\s*\{)", r"\1\n    compileOptions {\n        " + desugar_flag + "\n    }", s, count=1)
    dep = 'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")' if is_kts else \
        "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'"
    s += f"\n// FITAI_PATCHED\ndependencies {{\n    {dep}\n}}\n"
    path.write_text(s, encoding="utf-8")
    say(f"{path.name}: minSdk 24, Java 17, desugaring")


def _version_tuple(v: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", v)[:3])


def patch_agp_and_gradle() -> None:
    for name in ("settings.gradle.kts", "settings.gradle"):
        path = ROOT / "android" / name
        if not path.exists():
            continue
        s = path.read_text(encoding="utf-8")
        m = re.search(r'id\s*\(?\s*["\']com\.android\.application["\']\s*\)?\s*version\s*["\']([\d.]+)["\']', s)
        if m and _version_tuple(m.group(1)) < MIN_AGP:
            new = ".".join(map(str, MIN_AGP))
            s = s.replace(m.group(0), m.group(0).replace(m.group(1), new))
            path.write_text(s, encoding="utf-8")
            say(f"Android Gradle Plugin {m.group(1)} → {new}")
        break
    wrapper = ROOT / "android/gradle/wrapper/gradle-wrapper.properties"
    if wrapper.exists():
        s = wrapper.read_text(encoding="utf-8")
        m = re.search(r"gradle-([\d.]+)-(all|bin)\.zip", s)
        if m and _version_tuple(m.group(1)) < (8, 13):
            s = s.replace(m.group(0), f"gradle-{GRADLE_FOR_AGP}-{m.group(2)}.zip")
            wrapper.write_text(s, encoding="utf-8")
            say(f"Gradle {m.group(1)} → {GRADLE_FOR_AGP}")


def patch_ios() -> None:
    plist = ROOT / "ios/Runner/Info.plist"
    if plist.exists():
        s = plist.read_text(encoding="utf-8")
        if "NSCameraUsageDescription" not in s:
            keys = """	<key>NSCameraUsageDescription</key>
	<string>Form analizi ve yemek fotoğrafı için kamera kullanılır.</string>
	<key>NSPhotoLibraryUsageDescription</key>
	<string>Galeriden yemek fotoğrafı seçmek için.</string>
	<key>NSLocalNetworkUsageDescription</key>
	<string>Bilgisayardaki FitAI sunucusuna bağlanmak için.</string>
	<key>NSAppTransportSecurity</key>
	<dict>
		<key>NSAllowsArbitraryLoads</key>
		<true/>
	</dict>
</dict>
</plist>"""
            s = re.sub(r"</dict>\s*</plist>\s*$", keys, s)
            plist.write_text(s, encoding="utf-8")
            say("iOS Info.plist: kamera, fotoğraf ve yerel ağ izinleri")
    podfile = ROOT / "ios/Podfile"
    if podfile.exists():
        s = podfile.read_text(encoding="utf-8")
        s2 = re.sub(r"#?\s*platform :ios, '[\d.]+'", "platform :ios, '15.5'", s, count=1)
        if s2 != s:
            podfile.write_text(s2, encoding="utf-8")
            say("iOS hedefi 15.5 (ML Kit gereği)")


def main() -> None:
    print("FitAI mobil kurulum\n")
    if not (ROOT / "android").exists() or not (ROOT / "ios").exists():
        run(["flutter", "create", "--org", "com.fitai", "--project-name", "fitai", "--platforms", "android,ios", "."])
    test_file = ROOT / "test/widget_test.dart"
    if test_file.exists() and "MyApp" in test_file.read_text(encoding="utf-8"):
        test_file.unlink()
        say("Şablon test dosyası kaldırıldı")
    patch_manifest()
    patch_app_gradle()
    patch_agp_and_gradle()
    patch_ios()
    run(["flutter", "pub", "get"])
    print("\nKurulum tamam. Telefonu USB ile bağla (veya emülatörü aç) ve çalıştır:\n\n    flutter run\n")


if __name__ == "__main__":
    main()
