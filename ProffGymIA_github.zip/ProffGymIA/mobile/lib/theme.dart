import 'package:flutter/material.dart';

class FitColors {
  static const bg = Color(0xFFE3E4DF);
  static const surface = Color(0xFFF6F6F2);
  static const surface2 = Color(0xFFECEDE7);
  static const ink = Color(0xFF1D2025);
  static const ink2 = Color(0xFF565B62);
  static const line = Color(0xFFC9CBC4);
  static const blue = Color(0xFF1F5FAE);
  static const red = Color(0xFFC4303A);
  static const yellow = Color(0xFFC99A0E);
  static const yellowInk = Color(0xFF7D5C00);
  static const green = Color(0xFF2A8551);
  static const blueSoft = Color(0xFFDBE6F4);
  static const redSoft = Color(0xFFF6DCDD);
  static const yellowSoft = Color(0xFFF5EBC9);
  static const greenSoft = Color(0xFFD8ECDF);
}

ThemeData buildTheme() {
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: FitColors.blue,
      primary: FitColors.blue,
      error: FitColors.red,
      surface: FitColors.surface,
    ),
    scaffoldBackgroundColor: FitColors.bg,
  );
  return base.copyWith(
    appBarTheme: const AppBarTheme(
      backgroundColor: FitColors.bg,
      foregroundColor: FitColors.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: FitColors.ink, letterSpacing: -0.5),
    ),
    cardTheme: CardThemeData(
      color: FitColors.surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: const BorderSide(color: FitColors.line),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: FitColors.blue,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        textStyle: const TextStyle(fontWeight: FontWeight.w700),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: FitColors.ink,
        side: const BorderSide(color: FitColors.line),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        textStyle: const TextStyle(fontWeight: FontWeight.w600),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: FitColors.surface,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: const BorderSide(color: FitColors.line)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: const BorderSide(color: FitColors.line)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: const BorderSide(color: FitColors.blue, width: 2)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: FitColors.ink,
      indicatorColor: Colors.white.withValues(alpha: 0.12),
      labelTextStyle: WidgetStateProperty.resolveWith(
        (s) => TextStyle(color: s.contains(WidgetState.selected) ? Colors.white : const Color(0xFFB9BCB6), fontSize: 12, fontWeight: FontWeight.w600),
      ),
      iconTheme: WidgetStateProperty.resolveWith(
        (s) => IconThemeData(color: s.contains(WidgetState.selected) ? Colors.white : const Color(0xFFB9BCB6)),
      ),
    ),
  );
}

const numStyle = TextStyle(fontSize: 30, fontWeight: FontWeight.w800, height: 1.0, letterSpacing: -0.5, color: FitColors.ink);
const mutedStyle = TextStyle(color: FitColors.ink2, fontSize: 13);
const h2Style = TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: FitColors.ink);
