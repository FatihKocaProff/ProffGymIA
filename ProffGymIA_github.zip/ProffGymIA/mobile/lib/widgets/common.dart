import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const weekdays = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];
const mealLabels = {'breakfast': 'Kahvaltı', 'lunch': 'Öğle', 'dinner': 'Akşam', 'snack': 'Ara öğün'};
const goalLabels = {'lose': 'Kilo vermek', 'maintain': 'Kiloyu korumak', 'gain': 'Kilo almak'};
const activityLabels = {
  'sedentary': 'Hareketsiz',
  'light': 'Haftada 1–3 gün',
  'moderate': 'Haftada 3–5 gün',
  'active': 'Haftada 6–7 gün',
  'very_active': 'Çok aktif',
};

String fmtDate(String iso, {bool weekday = false}) {
  final d = DateTime.parse(iso);
  return '${weekday ? '${weekdays[d.weekday - 1]}, ' : ''}${d.day} ${months[d.month - 1]}';
}

String fmtNum(num? n, [int digits = 1]) {
  if (n == null) return '—';
  var s = n.toStringAsFixed(digits);
  if (digits > 0 && s.endsWith('.${'0' * digits}')) s = s.substring(0, s.length - digits - 1);
  return s.replaceAll('.', ',');
}

String todayIso() {
  final n = DateTime.now();
  return '${n.year}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
}

void showSnack(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(message),
    backgroundColor: error ? FitColors.red : FitColors.ink,
    behavior: SnackBarBehavior.floating,
  ));
}

class Panel extends StatelessWidget {
  const Panel({super.key, this.title, this.trailing, required this.child, this.padding = const EdgeInsets.all(16)});
  final String? title;
  final Widget? trailing;
  final Widget child;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: padding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (title != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(children: [Expanded(child: Text(title!, style: h2Style)), if (trailing != null) trailing!]),
              ),
            child,
          ],
        ),
      ),
    );
  }
}

class UserAvatar extends StatelessWidget {
  const UserAvatar({super.key, required this.name, this.photoUrl, this.size = 44});
  final String name;
  final String? photoUrl;
  final double size;

  static String _trUpper(String c) => c == 'i' ? 'İ' : (c == 'ı' ? 'I' : c.toUpperCase());

  String get _initials {
    final s = name.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).take(2).map((w) => _trUpper(w[0])).join();
    return s.isEmpty ? '?' : s;
  }

  @override
  Widget build(BuildContext context) {
    final fallback = Center(
      child: Text(_initials, style: TextStyle(fontSize: size * 0.36, fontWeight: FontWeight.w700, color: FitColors.ink2)),
    );
    return ClipOval(
      child: Container(
        width: size,
        height: size,
        color: FitColors.surface2,
        child: photoUrl == null
            ? fallback
            : Image.network(photoUrl!, width: size, height: size, fit: BoxFit.cover, errorBuilder: (_, _, _) => fallback),
      ),
    );
  }
}

class Chip2 extends StatelessWidget {
  const Chip2(this.text, {super.key, this.color = 'blue'});
  final String text;
  final String color;

  @override
  Widget build(BuildContext context) {
    final (bg, fg) = switch (color) {
      'green' => (FitColors.greenSoft, FitColors.green),
      'yellow' => (FitColors.yellowSoft, FitColors.yellowInk),
      'red' => (FitColors.redSoft, FitColors.red),
      _ => (FitColors.blueSoft, FitColors.blue),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 7, height: 7, decoration: BoxDecoration(color: fg, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(text, style: TextStyle(color: fg, fontWeight: FontWeight.w700, fontSize: 12)),
      ]),
    );
  }
}

String statusColor(int days, bool active) => !active ? 'red' : (days <= 7 ? 'yellow' : 'green');

Color colorOf(String name) => switch (name) {
      'green' => FitColors.green,
      'yellow' => FitColors.yellow,
      'red' => FitColors.red,
      _ => FitColors.blue,
    };

class PlateRing extends StatelessWidget {
  const PlateRing({super.key, required this.days, required this.active, this.size = 150});
  final int days;
  final bool active;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: active ? math.min(days / 30, 1.0) : 0),
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeOutCubic,
        builder: (context, frac, _) => CustomPaint(
          painter: _RingPainter(frac, colorOf(statusColor(days, active))),
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('$days', style: numStyle.copyWith(fontSize: size * 0.3)),
              Text('gün kaldı', style: mutedStyle.copyWith(fontSize: size * 0.08)),
            ]),
          ),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  _RingPainter(this.frac, this.color);
  final double frac;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = size.width * 0.11;
    final rect = Rect.fromLTWH(stroke / 2, stroke / 2, size.width - stroke, size.height - stroke);
    final track = Paint()
      ..color = FitColors.surface2
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;
    canvas.drawArc(rect, 0, math.pi * 2, false, track);
    final value = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke;
    canvas.drawArc(rect, -math.pi / 2, math.pi * 2 * frac, false, value);
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => old.frac != frac || old.color != color;
}

class MacroBar extends StatelessWidget {
  const MacroBar({super.key, required this.label, required this.value, this.target, required this.unit});
  final String label;
  final double value;
  final num? target;
  final String unit;

  @override
  Widget build(BuildContext context) {
    final t = target?.toDouble();
    final pct = (t == null || t == 0) ? 0.0 : (value / t).clamp(0.0, 1.0);
    final over = t != null && value > t * 1.05;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Text(label),
          const Spacer(),
          Text('${fmtNum(value)}${t != null ? ' / ${t.round()}' : ''} $unit', style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: pct,
            minHeight: 10,
            backgroundColor: FitColors.surface2,
            color: over ? FitColors.red : FitColors.blue,
          ),
        ),
      ]),
    );
  }
}

class Figure extends StatelessWidget {
  const Figure(this.value, this.unit, this.caption, {super.key});
  final String value;
  final String unit;
  final String caption;

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text.rich(TextSpan(children: [
        TextSpan(text: value, style: numStyle.copyWith(fontSize: 24)),
        TextSpan(text: ' $unit', style: mutedStyle),
      ])),
      Text(caption, style: mutedStyle),
    ]);
  }
}

class AsyncBody<T> extends StatelessWidget {
  const AsyncBody({super.key, required this.future, required this.builder, required this.onRetry});
  final Future<T>? future;
  final Widget Function(BuildContext, T) builder;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<T>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('${snap.error}', textAlign: TextAlign.center),
                const SizedBox(height: 12),
                FilledButton(onPressed: onRetry, child: const Text('Tekrar dene')),
              ]),
            ),
          );
        }
        return builder(context, snap.data as T);
      },
    );
  }
}
