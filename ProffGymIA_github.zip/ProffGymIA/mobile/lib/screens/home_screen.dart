import 'dart:async';

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.openTab});
  final void Function(int index) openTab;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final api = Api.instance;
  Future<Map<String, dynamic>>? _future;
  String? _qr;
  DateTime _qrExpires = DateTime.now();
  int _qrLifetime = 60;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _future = _load();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<Map<String, dynamic>> _load() async {
    final results = await Future.wait([
      api.get('/memberships/status'),
      api.get('/water'),
      api.get('/workouts'),
      api.get('/supplements'),
      api.get('/users/me/metabolism').catchError((_) => null),
    ]);
    final status = Map<String, dynamic>.from(results[0]);
    if (status['active'] == true) await _refreshQr();
    return {
      'status': status,
      'water': results[1],
      'workouts': results[2],
      'supplements': results[3],
      'metabolism': results[4],
    };
  }

  bool _qrBusy = false;

  Future<void> _refreshQr() async {
    if (_qrBusy) return;
    _qrBusy = true;
    try {
      final t = await api.get('/checkin/qr-token');
      if (!mounted) return;
      setState(() {
        _qr = t['token'] as String;
        _qrLifetime = t['expires_in'] as int;
        _qrExpires = DateTime.now().add(Duration(seconds: _qrLifetime));
      });
    } catch (_) {
    } finally {
      _qrBusy = false;
    }
  }

  void _tick() {
    if (!mounted || _qr == null) return;
    final left = _qrExpires.difference(DateTime.now()).inSeconds;
    if (left < 8) _refreshQr();
    setState(() {});
  }

  void _reload() => setState(() => _future = _load());

  Future<void> _addWater(int ml) async {
    try {
      await api.post('/water', {'amount_ml': ml});
      _reload();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final first = (api.me?['full_name'] as String? ?? '').split(' ').first;
    final now = DateTime.now();
    return Scaffold(
      appBar: AppBar(
        title: Text('Merhaba $first'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: () => widget.openTab(4),
              child: UserAvatar(
                name: api.me?['full_name'] as String? ?? '',
                photoUrl: api.me?['photo_path'] != null ? api.photoUrl(api.me!['photo_path'] as String) : null,
                size: 36,
              ),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: AsyncBody<Map<String, dynamic>>(
          future: _future,
          onRetry: _reload,
          builder: (context, d) {
            final status = d['status'] as Map;
            final water = d['water'] as Map;
            final metab = d['metabolism'] as Map?;
            final workouts = d['workouts'] as List;
            final supplements = d['supplements'] as List;
            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              children: [
                Text('${weekdays[now.weekday - 1]}, ${now.day} ${months[now.month - 1]}', style: mutedStyle),
                const SizedBox(height: 16),
                _gateCard(status),
                const SizedBox(height: 16),
                _waterCard(water),
                const SizedBox(height: 16),
                if (supplements.isNotEmpty) ...[_supplementCard(supplements), const SizedBox(height: 16)],
                _metabolismCard(metab),
                const SizedBox(height: 16),
                Panel(
                  title: 'Bugünkü antrenman',
                  trailing: TextButton(onPressed: () => widget.openTab(2), child: const Text('Tümü')),
                  child: workouts.isEmpty
                      ? const Text('Bugün için antrenman planlanmamış.', style: mutedStyle)
                      : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (final w in workouts) ...[
                              Text(w['title'], style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                              const SizedBox(height: 4),
                              Text((w['exercises'] as List).map((e) => '${e['name']} ${e['sets']}×${e['reps']}').join(' · '), style: mutedStyle),
                              const SizedBox(height: 8),
                            ],
                          ],
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _gateCard(Map status) {
    final active = status['active'] == true;
    final days = status['remaining_days'] as int;
    final left = _qrExpires.difference(DateTime.now()).inMilliseconds / 1000;
    return Panel(
      title: 'Salon girişi',
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          PlateRing(days: days, active: active, size: 120),
          const SizedBox(width: 16),
          Expanded(
            child: active && _qr != null
                ? Column(children: [
                    Container(
                      color: Colors.white,
                      padding: const EdgeInsets.all(8),
                      child: QrImageView(data: _qr!, version: QrVersions.auto, size: 150),
                    ),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: (left / _qrLifetime).clamp(0.0, 1.0),
                        minHeight: 4,
                        color: FitColors.green,
                        backgroundColor: FitColors.surface2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text('Turnikeye okut · kod her dakika yenilenir', style: mutedStyle, textAlign: TextAlign.center),
                  ])
                : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(active ? 'QR hazırlanıyor…' : 'Üyeliğin sona erdi', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    const SizedBox(height: 6),
                    Text(active ? '' : 'Turnikeden geçmek için resepsiyondan paketini yenile.', style: mutedStyle),
                    if (!active) TextButton(onPressed: () => widget.openTab(4), child: const Text('Paketleri gör')),
                  ]),
          ),
        ],
      ),
    );
  }

  Widget _waterCard(Map water) {
    final total = (water['total_ml'] as num).toDouble();
    final target = (water['target_ml'] as num?)?.toDouble();
    return Panel(
      title: 'Bugün içtiğin su',
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text.rich(TextSpan(children: [
          TextSpan(text: fmtNum(total / 1000, 2), style: numStyle),
          TextSpan(text: target != null ? '  / ${fmtNum(target / 1000, 2)} L' : ' L', style: mutedStyle),
        ])),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: target == null ? 0 : (total / target).clamp(0.0, 1.0),
            minHeight: 14,
            color: FitColors.blue,
            backgroundColor: FitColors.surface2,
          ),
        ),
        const SizedBox(height: 12),
        Row(children: [
          for (final ml in [200, 330, 500]) ...[
            Expanded(child: OutlinedButton(onPressed: () => _addWater(ml), child: Text('+$ml ml'))),
            if (ml != 500) const SizedBox(width: 8),
          ],
        ]),
      ]),
    );
  }

  Widget _supplementCard(List supplements) {
    return Panel(
      title: 'Takviyeler',
      trailing: TextButton(onPressed: () => widget.openTab(4), child: const Text('Düzenle')),
      child: Column(children: [
        for (final s in supplements)
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(
              '${(s['reminder_times'] as List).join(', ')}${s['dose'] != null ? ' · ${s['dose']}' : ''}\n'
              'Bugün ${s['taken_today']} kez · kutuda ${s['servings_left']} servis',
              style: TextStyle(color: s['low_stock'] == true ? FitColors.yellowInk : FitColors.ink2),
            ),
            isThreeLine: true,
            trailing: FilledButton(
              onPressed: () async {
                try {
                  await api.post('/supplements/${s['id']}/take');
                  _reload();
                } on ApiException catch (e) {
                  if (mounted) showSnack(context, e.message, error: true);
                }
              },
              child: const Text('Aldım'),
            ),
          ),
      ]),
    );
  }

  Widget _metabolismCard(Map? m) {
    if (m == null) {
      return Panel(
        title: 'Metabolizman',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Hesaplama için profilinde cinsiyet, doğum tarihi ve boy, ayrıca en az bir kilo kaydı gerekiyor.', style: mutedStyle),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: [
            FilledButton(onPressed: () => widget.openTab(4), child: const Text('Profilini tamamla')),
            OutlinedButton(onPressed: () => widget.openTab(1), child: const Text('Kilo gir')),
          ]),
        ]),
      );
    }
    return Panel(
      title: 'Metabolizman',
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 1.6,
          children: [
            Figure('${m['bmr']}', 'kcal', 'BMR'),
            Figure('${m['tdee']}', 'kcal', 'Günlük harcama'),
            Figure('${m['target_calories']}', 'kcal', 'Hedef kalori'),
            Figure('${m['protein_g']}', 'g', 'Protein'),
            Figure('${m['carbs_g']}', 'g', 'Karbonhidrat'),
            Figure('${m['fat_g']}', 'g', 'Yağ'),
          ],
        ),
        Text('BMI ${fmtNum(m['bmi'])} · ${m['bmi_category']}   ·   Su hedefi ${fmtNum((m['water_ml'] as num) / 1000, 2)} L', style: mutedStyle),
        const SizedBox(height: 4),
        const Text('BMR Mifflin-St Jeor formülüyle, günlük harcama aktivite seviyene göre hesaplandı.', style: mutedStyle),
      ]),
    );
  }
}
