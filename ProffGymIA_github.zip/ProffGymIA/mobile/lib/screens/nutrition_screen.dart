import 'dart:async';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class NutritionScreen extends StatefulWidget {
  const NutritionScreen({super.key});

  @override
  State<NutritionScreen> createState() => _NutritionScreenState();
}

class _NutritionScreenState extends State<NutritionScreen> {
  final api = Api.instance;
  Future<Map<String, dynamic>>? _future;
  bool _analyzing = false;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final r = await Future.wait([api.get('/weights', {'days': 30}), api.get('/meals/summary'), api.get('/meals')]);
    return {'weights': r[0], 'summary': r[1], 'meals': r[2]};
  }

  void _reload() => setState(() => _future = _load());

  String _mealGuess() {
    final h = DateTime.now().hour;
    if (h < 11) return 'breakfast';
    if (h < 15) return 'lunch';
    if (h >= 18 && h < 22) return 'dinner';
    return 'snack';
  }

  Future<void> _photo(ImageSource source) async {
    final picked = await ImagePicker().pickImage(source: source, maxWidth: 1600, imageQuality: 85);
    if (picked == null) return;
    setState(() => _analyzing = true);
    try {
      final bytes = await picked.readAsBytes();
      final meal = await api.uploadMealPhoto(bytes, picked.name.isEmpty ? 'tabak.jpg' : picked.name, _mealGuess());
      if (!mounted) return;
      _reload();
      await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (_) => MealResultSheet(meal: meal, onChanged: _reload),
      );
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _analyzing = false);
    }
  }

  Future<void> _logWeight(double? current) async {
    final ctrl = TextEditingController(text: current != null ? current.toString() : '');
    final value = await showDialog<double>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Bugünkü tartı'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(suffixText: 'kg'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, double.tryParse(ctrl.text.replaceAll(',', '.'))), child: const Text('Kaydet')),
        ],
      ),
    );
    if (value == null) return;
    try {
      await api.post('/weights', {'weight_kg': value});
      if (mounted) showSnack(context, 'Kilo kaydedildi');
      _reload();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Beslenme')),
      floatingActionButton: _analyzing
          ? const FloatingActionButton.extended(onPressed: null, icon: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)), label: Text('Analiz ediliyor…'))
          : FloatingActionButton.extended(
              onPressed: () => _photo(ImageSource.camera),
              icon: const Icon(Icons.photo_camera),
              label: const Text('Tabağı çek'),
            ),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: AsyncBody<Map<String, dynamic>>(
          future: _future,
          onRetry: _reload,
          builder: (context, d) {
            final weights = d['weights'] as List;
            final s = d['summary'] as Map;
            final meals = d['meals'] as List;
            final last = weights.isNotEmpty ? (weights.last['weight_kg'] as num).toDouble() : null;
            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
              children: [
                Panel(
                  title: 'Kilo',
                  trailing: FilledButton(onPressed: () => _logWeight(last), child: const Text('Tartıl')),
                  child: _WeightChart(weights: weights),
                ),
                const SizedBox(height: 16),
                Panel(
                  title: 'Bugünkü makrolar',
                  trailing: Text('${s['meal_count']} öğün', style: mutedStyle),
                  child: Column(children: [
                    MacroBar(label: 'Kalori', value: (s['calories'] as num).toDouble(), target: s['target_calories'], unit: 'kcal'),
                    MacroBar(label: 'Protein', value: (s['protein_g'] as num).toDouble(), target: s['target_protein_g'], unit: 'g'),
                    MacroBar(label: 'Karbonhidrat', value: (s['carbs_g'] as num).toDouble(), target: s['target_carbs_g'], unit: 'g'),
                    MacroBar(label: 'Yağ', value: (s['fat_g'] as num).toDouble(), target: s['target_fat_g'], unit: 'g'),
                    if (s['target_calories'] == null)
                      const Text('Hedefler için profil ve kilo bilgisi gerekiyor.', style: mutedStyle),
                  ]),
                ),
                const SizedBox(height: 16),
                Panel(
                  title: 'Bugün yediklerin',
                  trailing: PopupMenuButton<String>(
                    icon: const Icon(Icons.add),
                    onSelected: (v) => v == 'gallery'
                        ? _photo(ImageSource.gallery)
                        : showModalBottomSheet(
                            context: context,
                            isScrollControlled: true,
                            showDragHandle: true,
                            builder: (_) => MealFormSheet(initialType: _mealGuess(), onSaved: _reload),
                          ),
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'gallery', child: Text('Galeriden fotoğraf')),
                      PopupMenuItem(value: 'manual', child: Text('Yazarak ekle (kalori otomatik)')),
                    ],
                  ),
                  child: meals.isEmpty
                      ? const Text('Bugün öğün girilmedi. Tabağının fotoğrafını çek ya da + ile ne yediğini yaz; kalori kendiliğinden hesaplanır.', style: mutedStyle)
                      : Column(children: [
                          for (final m in meals)
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: m['photo_path'] != null
                                  ? ClipRRect(
                                      borderRadius: BorderRadius.circular(6),
                                      child: Image.network(api.photoUrl(m['photo_path']), width: 52, height: 52, fit: BoxFit.cover,
                                          errorBuilder: (_, _, _) => const Icon(Icons.image_not_supported)),
                                    )
                                  : const CircleAvatar(backgroundColor: FitColors.surface2, child: Icon(Icons.restaurant, color: FitColors.ink2)),
                              title: Text('${mealLabels[m['meal_type']]}${m['source'] == 'ai' ? ' · AI' : (m['source'] == 'auto' ? ' · otomatik' : (m['source'] == 'diary' ? ' · defter' : ''))}',
                                  style: const TextStyle(fontWeight: FontWeight.w700)),
                              subtitle: Text('${m['description'] ?? ''}\nP ${fmtNum(m['protein_g'])} · K ${fmtNum(m['carbs_g'])} · Y ${fmtNum(m['fat_g'])} g'),
                              isThreeLine: true,
                              trailing: Text('${(m['calories'] as num).round()} kcal', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                              onTap: () => showModalBottomSheet(
                                context: context,
                                isScrollControlled: true,
                                showDragHandle: true,
                                builder: (_) => MealResultSheet(meal: Map<String, dynamic>.from(m), onChanged: _reload),
                              ),
                            ),
                        ]),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _WeightChart extends StatelessWidget {
  const _WeightChart({required this.weights});
  final List weights;

  @override
  Widget build(BuildContext context) {
    if (weights.length < 2) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 12),
        child: Text('Grafik için en az iki gün tartı kaydı gerekiyor.', style: mutedStyle),
      );
    }
    final first = DateTime.parse(weights.first['log_date']);
    final spots = [
      for (final w in weights)
        FlSpot(DateTime.parse(w['log_date']).difference(first).inDays.toDouble(), (w['weight_kg'] as num).toDouble()),
    ];
    final ys = spots.map((s) => s.y);
    final minY = ys.reduce((a, b) => a < b ? a : b), maxY = ys.reduce((a, b) => a > b ? a : b);
    final pad = ((maxY - minY) * 0.2).clamp(0.5, 5.0);
    final delta = spots.last.y - spots.first.y;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(
        height: 180,
        child: LineChart(LineChartData(
          minY: (minY - pad).floorToDouble(),
          maxY: (maxY + pad).ceilToDouble(),
          gridData: const FlGridData(show: true, drawVerticalLine: false),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 34,
                getTitlesWidget: (v, meta) => Text(v.toStringAsFixed(0), style: mutedStyle.copyWith(fontSize: 11)),
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 22,
                interval: (spots.last.x / 3).clamp(1, 1000).toDouble(),
                getTitlesWidget: (v, meta) {
                  final d = first.add(Duration(days: v.round()));
                  return Text('${d.day} ${months[d.month - 1].substring(0, 3)}', style: mutedStyle.copyWith(fontSize: 11));
                },
              ),
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              color: FitColors.blue,
              barWidth: 2.5,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(show: true, color: FitColors.blue.withValues(alpha: 0.08)),
            ),
          ],
        )),
      ),
      const SizedBox(height: 6),
      Text.rich(TextSpan(style: mutedStyle, children: [
        TextSpan(text: '${weights.length} kayıtta değişim: '),
        TextSpan(
          text: '${delta > 0 ? '+' : ''}${fmtNum(delta)} kg',
          style: TextStyle(fontWeight: FontWeight.w700, color: delta < 0 ? FitColors.green : FitColors.blue),
        ),
        TextSpan(text: '   ·   son: ${fmtNum(spots.last.y)} kg'),
      ])),
    ]);
  }
}

class MealResultSheet extends StatelessWidget {
  const MealResultSheet({super.key, required this.meal, required this.onChanged});
  final Map<String, dynamic> meal;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    final ai = meal['ai_detail'] as Map?;
    final items = (ai?['items'] as List?) ?? [];
    final error = ai?['error'] as String?;
    final confidence = ai?['confidence'] as String?;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          if (meal['photo_path'] != null)
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(Api.instance.photoUrl(meal['photo_path']), height: 160, fit: BoxFit.cover,
                  errorBuilder: (_, _, _) => const SizedBox.shrink()),
            ),
          const SizedBox(height: 12),
          Row(children: [
            Text('${(meal['calories'] as num).round()}', style: numStyle.copyWith(fontSize: 40)),
            const Text(' kcal', style: mutedStyle),
            const Spacer(),
            if (confidence != null)
              Chip2('güven: $confidence', color: confidence == 'yüksek' ? 'green' : (confidence == 'düşük' ? 'red' : 'yellow')),
          ]),
          Text('Protein ${fmtNum(meal['protein_g'])} g · Karbonhidrat ${fmtNum(meal['carbs_g'])} g · Yağ ${fmtNum(meal['fat_g'])} g'),
          const SizedBox(height: 12),
          if (error != null) Text('Yapay zeka analizi yapılamadı: $error', style: const TextStyle(color: FitColors.red)),
          for (final i in items)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(children: [
                Expanded(child: Text('${i['name']}  ·  ${fmtNum(i['portion_g'], 0)} g')),
                Text('${(i['calories'] as num).round()} kcal', style: const TextStyle(fontWeight: FontWeight.w600)),
              ]),
            ),
          if ((ai?['vitamins'] as List?)?.isNotEmpty == true) ...[
            const SizedBox(height: 8),
            Text('Öne çıkan vitamin/mineraller: ${(ai!['vitamins'] as List).join(', ')}', style: mutedStyle),
          ],
          if ((ai?['note'] as String?)?.isNotEmpty == true) Text(ai!['note'], style: mutedStyle),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () async {
                  try {
                    await Api.instance.delete('/meals/${meal['id']}');
                    onChanged();
                    if (context.mounted) Navigator.pop(context);
                  } on ApiException catch (e) {
                    if (context.mounted) showSnack(context, e.message, error: true);
                  }
                },
                child: const Text('Sil'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton(
                onPressed: () {
                  final nav = Navigator.of(context);
                  nav.pop();
                  showModalBottomSheet(
                    context: nav.context,
                    isScrollControlled: true,
                    showDragHandle: true,
                    builder: (_) => MealFormSheet(existing: meal, onSaved: onChanged),
                  );
                },
                child: const Text('Değerleri düzelt'),
              ),
            ),
          ]),
        ]),
      ),
    );
  }
}

class MealFormSheet extends StatefulWidget {
  const MealFormSheet({super.key, this.existing, this.initialType = 'snack', required this.onSaved});
  final Map<String, dynamic>? existing;
  final String initialType;
  final VoidCallback onSaved;

  @override
  State<MealFormSheet> createState() => _MealFormSheetState();
}

class _MealFormSheetState extends State<MealFormSheet> {
  late String _type = widget.existing?['meal_type'] ?? widget.initialType;
  late final _desc = TextEditingController(text: widget.existing?['description'] ?? '');
  late final _kcal = TextEditingController(text: _v('calories'));
  late final _p = TextEditingController(text: _v('protein_g'));
  late final _c = TextEditingController(text: _v('carbs_g'));
  late final _f = TextEditingController(text: _v('fat_g'));
  bool _busy = false;
  bool _calculating = false;
  bool _filling = false;
  Map<String, dynamic>? _analysis;
  Timer? _debounce;
  int _seq = 0;

  String _v(String k) => widget.existing == null ? '' : fmtNum(widget.existing![k]).replaceAll(',', '.');
  double _d(TextEditingController c) => double.tryParse(c.text.replaceAll(',', '.')) ?? 0;

  @override
  void initState() {
    super.initState();
    for (final c in [_kcal, _p, _c, _f]) {
      c.addListener(() {
        if (!_filling && _analysis != null) setState(() => _analysis = null);
      });
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    for (final c in [_desc, _kcal, _p, _c, _f]) {
      c.dispose();
    }
    super.dispose();
  }

  void _onDescChanged(String _) {
    if (widget.existing != null) return;
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 600), () => _calculate(quick: true));
  }

  Future<void> _calculate({bool quick = false}) async {
    final text = _desc.text.trim();
    final mine = ++_seq;
    if (text.length < 2) {
      if (!quick && mounted) showSnack(context, 'Önce ne yediğini yaz: ör. 2 yumurta, 1 dilim ekmek', error: true);
      return;
    }
    setState(() => _calculating = true);
    try {
      final r = await Api.instance.analyzeMealText(text, quick: quick);
      if (!mounted || mine != _seq) return;
      final t = r['totals'] as Map;
      _filling = true;
      _kcal.text = '${(t['calories'] as num).round()}';
      _p.text = fmtNum(t['protein_g']).replaceAll(',', '.');
      _c.text = fmtNum(t['carbs_g']).replaceAll(',', '.');
      _f.text = fmtNum(t['fat_g']).replaceAll(',', '.');
      _filling = false;
      setState(() => _analysis = r);
    } on ApiException catch (e) {
      if (mounted && !quick) showSnack(context, e.message, error: true);
    } finally {
      if (mounted && mine == _seq) setState(() => _calculating = false);
    }
  }

  Future<void> _save() async {
    final desc = _desc.text.trim();
    final kcalText = _kcal.text.trim();
    if (kcalText.isEmpty && desc.isEmpty) {
      showSnack(context, 'Ne yediğini yaz ya da kaloriyi gir.', error: true);
      return;
    }
    setState(() => _busy = true);
    final body = <String, dynamic>{
      'meal_type': _type,
      'description': desc.isEmpty ? null : desc,
      'calories': kcalText.isEmpty ? null : _d(_kcal),
      'protein_g': _d(_p),
      'carbs_g': _d(_c),
      'fat_g': _d(_f),
    };
    if (body['calories'] != null && _analysis != null) body['analysis'] = _analysis;
    try {
      if (widget.existing != null) {
        body['meal_date'] = widget.existing!['meal_date'];
        await Api.instance.patch('/meals/${widget.existing!['id']}', body);
      } else {
        await Api.instance.post('/meals', body);
      }
      widget.onSaved();
      if (mounted) Navigator.pop(context);
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _num(TextEditingController c, String label, {String? hint}) => Expanded(
        child: TextField(
          controller: c,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: label, hintText: hint),
        ),
      );

  Widget _breakdown(Map<String, dynamic> r) {
    final items = (r['items'] as List?) ?? [];
    final unmatched = ((r['unmatched'] as List?) ?? []).cast<String>();
    final provider = switch (r['provider']) {
      'gemini' => 'Yapay zeka (Gemini)',
      'claude' => 'Yapay zeka (Claude)',
      _ => 'FitAI besin tablosu',
    };
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: FitColors.surface2, borderRadius: BorderRadius.circular(8)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        for (final i in items)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(children: [
              Expanded(child: Text('${i['name']}')),
              Text('${(i['calories'] as num).round()} kcal', style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
          ),
        if (unmatched.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text('Tanınmayan: ${unmatched.join(', ')}. Bunların değerini elle ekleyebilirsin.',
                style: const TextStyle(color: FitColors.yellowInk, fontWeight: FontWeight.w600)),
          ),
        if (items.isEmpty && unmatched.isEmpty)
          const Text('Yazdığını tanıyamadım. Miktarla birlikte yaz: ör. 2 yumurta, 150 g tavuk.', style: mutedStyle),
        const SizedBox(height: 4),
        Text('Kaynak: $provider${r['confidence'] != null ? ' · güven ${r['confidence']}' : ''}', style: mutedStyle.copyWith(fontSize: 12)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(widget.existing != null ? 'Öğünü düzelt' : 'Öğün ekle', style: h2Style),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _type,
            decoration: const InputDecoration(labelText: 'Öğün'),
            items: [for (final e in mealLabels.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
            onChanged: (v) => setState(() => _type = v ?? _type),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _desc,
            minLines: 1,
            maxLines: 3,
            maxLength: 500,
            textCapitalization: TextCapitalization.sentences,
            onChanged: _onDescChanged,
            decoration: InputDecoration(
              labelText: 'Ne yedin?',
              hintText: 'Örn. 2 yumurta, 1 dilim ekmek, 1 bardak çay',
              helperText: widget.existing == null ? 'Yazdıkça kalori ve makrolar kendiliğinden hesaplanır.' : null,
              suffixIcon: _calculating
                  ? const Padding(padding: EdgeInsets.all(14), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)))
                  : IconButton(icon: const Icon(Icons.calculate_outlined), tooltip: 'Kaloriyi hesapla', onPressed: () => _calculate()),
            ),
          ),
          if (_analysis != null) ...[const SizedBox(height: 8), _breakdown(_analysis!)],
          const SizedBox(height: 12),
          Row(children: [_num(_kcal, 'Kalori', hint: 'otomatik'), const SizedBox(width: 8), _num(_p, 'Protein g')]),
          const SizedBox(height: 12),
          Row(children: [_num(_c, 'Karb. g'), const SizedBox(width: 8), _num(_f, 'Yağ g')]),
          const SizedBox(height: 16),
          FilledButton(onPressed: _busy ? null : _save, child: const Text('Kaydet')),
        ]),
      ),
    );
  }
}
