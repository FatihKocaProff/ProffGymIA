import 'package:flutter/material.dart';

import '../api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class WorkoutScreen extends StatefulWidget {
  const WorkoutScreen({super.key});

  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> {
  Future<dynamic>? _future;

  @override
  void initState() {
    super.initState();
    _future = Api.instance.get('/workouts', {'days': 14});
  }

  void _reload() => setState(() => _future = Api.instance.get('/workouts', {'days': 14}));

  Future<void> _toggle(Map w) async {
    try {
      await Api.instance.patch('/workouts/${w['id']}/complete', {}, {'completed': '${!(w['completed'] as bool)}'});
      _reload();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Antrenmanım')),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: AsyncBody<dynamic>(
          future: _future,
          onRetry: _reload,
          builder: (context, data) {
            final list = data as List;
            if (list.isEmpty) {
              return ListView(padding: const EdgeInsets.all(16), children: const [
                Text('Henüz programın yok. PT\'in antrenman tanımladığında burada görünecek.', style: mutedStyle),
              ]);
            }
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              itemCount: list.length,
              separatorBuilder: (_, _) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final w = list[i] as Map;
                final done = w['completed'] == true;
                return Panel(
                  title: w['title'],
                  trailing: Chip2(done ? 'Tamamlandı' : 'Planlandı', color: done ? 'green' : 'blue'),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Text(fmtDate(w['workout_date'], weekday: true), style: mutedStyle),
                    if (w['notes'] != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(w['notes'])),
                    const SizedBox(height: 8),
                    for (final e in w['exercises'] as List)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Row(children: [
                          Expanded(child: Text(e['name'], style: const TextStyle(fontWeight: FontWeight.w600))),
                          Text('${e['sets']} × ${e['reps']}', style: const TextStyle(fontWeight: FontWeight.w800)),
                          SizedBox(
                            width: 76,
                            child: Text(e['weight_kg'] != null ? '${fmtNum(e['weight_kg'])} kg' : '—',
                                textAlign: TextAlign.right, style: const TextStyle(color: FitColors.ink2)),
                          ),
                        ]),
                      ),
                    const SizedBox(height: 8),
                    done
                        ? OutlinedButton(onPressed: () => _toggle(w), child: const Text('Geri al'))
                        : FilledButton(onPressed: () => _toggle(w), child: const Text('Tamamladım')),
                  ]),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
