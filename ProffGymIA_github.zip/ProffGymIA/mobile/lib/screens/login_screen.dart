import 'package:flutter/material.dart';

import '../api.dart';
import '../theme.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onLoggedIn});
  final VoidCallback onLoggedIn;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _server = TextEditingController(text: Api.instance.baseUrl);
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _register = false;
  bool _busy = false;
  String? _error;

  Future<void> _submit() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      if (_register) {
        await Api.instance.register(_server.text, _name.text, _email.text, _password.text);
      }
      final me = await Api.instance.login(_server.text, _email.text, _password.text);
      if (me['role'] != 'member') {
        await Api.instance.logout();
        throw ApiException('Bu uygulama üyeler içindir. Yönetici ve PT masaüstü paneli kullanır.');
      }
      widget.onLoggedIn();
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FitColors.ink,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 24),
            Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              for (final (c, h) in [(FitColors.red, 64.0), (FitColors.blue, 58.0), (const Color(0xFFD9A514), 50.0), (FitColors.green, 42.0)])
                Container(width: 12, height: h, margin: const EdgeInsets.only(right: 4), decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(3))),
              const SizedBox(width: 12),
              const Text('FitAI', style: TextStyle(color: Colors.white, fontSize: 56, fontWeight: FontWeight.w900, height: 0.9, letterSpacing: -1.5)),
            ]),
            const SizedBox(height: 12),
            const Text('Üyeliğin, beslenmen ve antrenmanın tek yerde.', style: TextStyle(color: Color(0xFFB9BCB6), fontSize: 16)),
            const SizedBox(height: 32),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Text(_register ? 'Üye ol' : 'Giriş yap', style: h2Style.copyWith(fontSize: 24)),
                  const SizedBox(height: 16),
                  if (_register) ...[
                    TextField(controller: _name, decoration: const InputDecoration(labelText: 'Ad soyad'), textCapitalization: TextCapitalization.words),
                    const SizedBox(height: 12),
                  ],
                  TextField(controller: _email, decoration: const InputDecoration(labelText: 'E-posta'), keyboardType: TextInputType.emailAddress, autocorrect: false),
                  const SizedBox(height: 12),
                  TextField(controller: _password, decoration: const InputDecoration(labelText: 'Şifre'), obscureText: true, onSubmitted: (_) => _submit()),
                  const SizedBox(height: 12),
                  ExpansionTile(
                    tilePadding: EdgeInsets.zero,
                    title: const Text('Sunucu adresi', style: mutedStyle),
                    subtitle: Text(_server.text, style: mutedStyle.copyWith(fontSize: 12)),
                    children: [
                      TextField(controller: _server, decoration: const InputDecoration(labelText: 'http://bilgisayar-ip:8000'), onChanged: (_) => setState(() {})),
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: Text('Emülatör: http://10.0.2.2:8000 · Gerçek telefon: backend penceresinde yazan IP (aynı Wi-Fi).', style: mutedStyle),
                      ),
                    ],
                  ),
                  if (_error != null)
                    Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: const TextStyle(color: FitColors.red))),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: _busy
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : Text(_register ? 'Üye ol' : 'Giriş yap'),
                  ),
                  TextButton(
                    onPressed: () => setState(() => _register = !_register),
                    child: Text(_register ? 'Hesabım var, giriş yap' : 'Hesabın yok mu? Üye ol'),
                  ),
                  if (!_register)
                    TextButton(
                      onPressed: () {
                        _email.text = 'ayse@fitai.com';
                        _password.text = 'uye1234';
                        _submit();
                      },
                      child: const Text('Örnek hesapla dene (Ayşe)'),
                    ),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            Text('Üye olduktan sonra salonda paketini aldırdığında turnike QR kodun aktifleşir.',
                style: mutedStyle.copyWith(color: const Color(0xFFB9BCB6))),
          ],
        ),
      ),
    );
  }
}
