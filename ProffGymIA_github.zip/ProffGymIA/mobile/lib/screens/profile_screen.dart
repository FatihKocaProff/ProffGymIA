import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../api.dart';
import '../services/notifications.dart';
import '../theme.dart';
import '../widgets/common.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, required this.onLogout});
  final VoidCallback onLogout;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final api = Api.instance;
  Future<Map<String, dynamic>>? _future;
  bool _uploading = false;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final r = await Future.wait([api.get('/users/me'), api.get('/supplements'), api.get('/packages')]);
    api.me = Map<String, dynamic>.from(r[0]);
    await Reminders.instance.scheduleAll(r[1] as List).catchError((_) {});
    return {'me': r[0], 'supplements': r[1], 'packages': r[2]};
  }

  void _reload() => setState(() => _future = _load());

  Future<void> _photoOptions(Map me) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.photo_camera), title: const Text('Fotoğraf çek'), onTap: () => Navigator.pop(ctx, 'camera')),
          ListTile(leading: const Icon(Icons.photo_library), title: const Text('Galeriden seç'), onTap: () => Navigator.pop(ctx, 'gallery')),
          if (me['photo_path'] != null)
            ListTile(
              leading: const Icon(Icons.delete_outline, color: FitColors.red),
              title: const Text('Fotoğrafı kaldır'),
              onTap: () => Navigator.pop(ctx, 'remove'),
            ),
        ]),
      ),
    );
    if (choice == null) return;
    try {
      if (choice == 'remove') {
        await api.deleteProfilePhoto();
      } else {
        final picked = await ImagePicker().pickImage(
          source: choice == 'camera' ? ImageSource.camera : ImageSource.gallery,
          preferredCameraDevice: CameraDevice.front,
          maxWidth: 1200,
          imageQuality: 88,
        );
        if (picked == null) return;
        setState(() => _uploading = true);
        await api.uploadProfilePhoto(await picked.readAsBytes(), picked.name.isEmpty ? 'profil.jpg' : picked.name);
      }
      if (mounted) showSnack(context, choice == 'remove' ? 'Profil fotoğrafı kaldırıldı' : 'Profil fotoğrafı kaydedildi');
      _reload();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ben')),
      body: AsyncBody<Map<String, dynamic>>(
        future: _future,
        onRetry: _reload,
        builder: (context, d) {
          final me = d['me'] as Map;
          final supplements = d['supplements'] as List;
          final packages = d['packages'] as List;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            children: [
              Panel(
                title: me['full_name'],
                trailing: IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () async {
                    final saved = await showModalBottomSheet<bool>(
                      context: context,
                      isScrollControlled: true,
                      showDragHandle: true,
                      builder: (_) => ProfileForm(me: Map<String, dynamic>.from(me)),
                    );
                    if (saved == true) _reload();
                  },
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    GestureDetector(
                      onTap: _uploading ? null : () => _photoOptions(me),
                      child: Stack(children: [
                        UserAvatar(
                          name: me['full_name'] ?? '',
                          photoUrl: me['photo_path'] != null ? api.photoUrl(me['photo_path']) : null,
                          size: 76,
                        ),
                        if (_uploading)
                          const Positioned.fill(child: Center(child: CircularProgressIndicator(strokeWidth: 2.5))),
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            decoration: const BoxDecoration(color: FitColors.blue, shape: BoxShape.circle),
                            child: const Icon(Icons.photo_camera, size: 15, color: Colors.white),
                          ),
                        ),
                      ]),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(me['email'], style: mutedStyle),
                        TextButton(
                          style: TextButton.styleFrom(padding: EdgeInsets.zero, alignment: Alignment.centerLeft),
                          onPressed: _uploading ? null : () => _photoOptions(me),
                          child: Text(me['photo_path'] == null ? 'Profil fotoğrafı ekle' : 'Fotoğrafı değiştir'),
                        ),
                      ]),
                    ),
                  ]),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    Chip2(goalLabels[me['goal']] ?? ''),
                    if (me['height_cm'] != null) Chip2('${fmtNum(me['height_cm'], 0)} cm'),
                    Chip2(activityLabels[me['activity_level']] ?? ''),
                  ]),
                  if (me['gender'] == null || me['birth_date'] == null || me['height_cm'] == null)
                    const Padding(
                      padding: EdgeInsets.only(top: 10),
                      child: Text('Metabolizma hesabı için cinsiyet, doğum tarihi ve boyunu gir.', style: TextStyle(color: FitColors.yellowInk)),
                    ),
                ]),
              ),
              const SizedBox(height: 16),
              Panel(
                title: 'Takviyelerim',
                trailing: IconButton(icon: const Icon(Icons.add), onPressed: () => _editSupplement(null)),
                child: supplements.isEmpty
                    ? const Text('Protein tozu, kreatin gibi takviyelerini ekle; saatinde hatırlatalım ve kutuda kalanı takip edelim.', style: mutedStyle)
                    : Column(children: [
                        for (final s in supplements)
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text(s['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text('${(s['reminder_times'] as List).isEmpty ? 'Hatırlatma yok' : (s['reminder_times'] as List).join(', ')}'
                                '${s['dose'] != null ? ' · ${s['dose']}' : ''}'),
                            trailing: Chip2('${s['servings_left']} servis', color: s['low_stock'] == true ? 'yellow' : 'green'),
                            onTap: () => _editSupplement(Map<String, dynamic>.from(s)),
                          ),
                      ]),
              ),
              const SizedBox(height: 16),
              Panel(
                title: 'Salon paketleri',
                child: Column(children: [
                  for (final p in packages)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(p['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${p['duration_days']} gün${p['description'] != null ? ' · ${p['description']}' : ''}'),
                      trailing: Text('${fmtNum(p['price'], 0)} ₺', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    ),
                  const Text('Paket satın almak için resepsiyona uğra.', style: mutedStyle),
                ]),
              ),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: () async {
                  await api.logout();
                  widget.onLogout();
                },
                child: const Text('Çıkış yap'),
              ),
              const SizedBox(height: 8),
              Text('Sunucu: ${api.baseUrl}', style: mutedStyle, textAlign: TextAlign.center),
            ],
          );
        },
      ),
    );
  }

  Future<void> _editSupplement(Map<String, dynamic>? s) async {
    final changed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => SupplementForm(existing: s),
    );
    if (changed == true) {
      await Reminders.instance.requestPermission();
      _reload();
    }
  }
}

class ProfileForm extends StatefulWidget {
  const ProfileForm({super.key, required this.me});
  final Map<String, dynamic> me;

  @override
  State<ProfileForm> createState() => _ProfileFormState();
}

class _ProfileFormState extends State<ProfileForm> {
  late final _name = TextEditingController(text: widget.me['full_name']);
  late final _height = TextEditingController(text: widget.me['height_cm'] != null ? fmtNum(widget.me['height_cm'], 0) : '');
  late String? _gender = widget.me['gender'];
  late String _activity = widget.me['activity_level'] ?? 'sedentary';
  late String _goal = widget.me['goal'] ?? 'maintain';
  late DateTime? _birth = widget.me['birth_date'] != null ? DateTime.parse(widget.me['birth_date']) : null;
  bool _busy = false;

  Future<void> _save() async {
    setState(() => _busy = true);
    final body = <String, dynamic>{'full_name': _name.text.trim(), 'activity_level': _activity, 'goal': _goal};
    if (_gender != null) body['gender'] = _gender;
    final h = double.tryParse(_height.text.replaceAll(',', '.'));
    if (h != null) body['height_cm'] = h;
    if (_birth != null) {
      body['birth_date'] = '${_birth!.year}-${_birth!.month.toString().padLeft(2, '0')}-${_birth!.day.toString().padLeft(2, '0')}';
    }
    try {
      await Api.instance.patch('/users/me', body);
      if (mounted) Navigator.pop(context, true);
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Profilim', style: h2Style),
        const SizedBox(height: 12),
        TextField(controller: _name, decoration: const InputDecoration(labelText: 'Ad soyad')),
        const SizedBox(height: 12),
        SegmentedButton<String>(
          segments: const [ButtonSegment(value: 'female', label: Text('Kadın')), ButtonSegment(value: 'male', label: Text('Erkek'))],
          selected: {if (_gender != null) _gender!},
          emptySelectionAllowed: true,
          onSelectionChanged: (v) => setState(() => _gender = v.isEmpty ? null : v.first),
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: _birth ?? DateTime(2000, 1, 1),
                  firstDate: DateTime(1930),
                  lastDate: DateTime.now(),
                  helpText: 'Doğum tarihi',
                );
                if (picked != null) setState(() => _birth = picked);
              },
              child: Text(_birth == null ? 'Doğum tarihi seç' : '${_birth!.day}.${_birth!.month}.${_birth!.year}'),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: _height, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Boy', suffixText: 'cm'))),
        ]),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          initialValue: _activity,
          decoration: const InputDecoration(labelText: 'Haftalık aktivite'),
          items: [for (final e in activityLabels.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
          onChanged: (v) => setState(() => _activity = v ?? _activity),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          initialValue: _goal,
          decoration: const InputDecoration(labelText: 'Hedefin'),
          items: [for (final e in goalLabels.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
          onChanged: (v) => setState(() => _goal = v ?? _goal),
        ),
        const SizedBox(height: 16),
        FilledButton(onPressed: _busy ? null : _save, child: const Text('Profili kaydet')),
      ]),
    );
  }
}

class SupplementForm extends StatefulWidget {
  const SupplementForm({super.key, this.existing});
  final Map<String, dynamic>? existing;

  @override
  State<SupplementForm> createState() => _SupplementFormState();
}

class _SupplementFormState extends State<SupplementForm> {
  late final _name = TextEditingController(text: widget.existing?['name'] ?? '');
  late final _dose = TextEditingController(text: widget.existing?['dose'] ?? '');
  late final _servings = TextEditingController(text: '${widget.existing?['servings_left'] ?? 30}');
  late final List<String> _times = [...((widget.existing?['reminder_times'] as List?) ?? ['09:00']).cast<String>()];
  bool _busy = false;

  Future<void> _addTime() async {
    final t = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 9, minute: 0));
    if (t == null) return;
    final s = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
    if (!_times.contains(s)) setState(() => _times..add(s)..sort());
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    final body = {
      'name': _name.text.trim(),
      'dose': _dose.text.trim().isEmpty ? null : _dose.text.trim(),
      'reminder_times': _times,
      'servings_left': int.tryParse(_servings.text) ?? 0,
    };
    try {
      if (widget.existing == null) {
        await Api.instance.post('/supplements', body);
      } else {
        await Api.instance.patch('/supplements/${widget.existing!['id']}', body);
      }
      if (mounted) Navigator.pop(context, true);
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete() async {
    try {
      await Api.instance.delete('/supplements/${widget.existing!['id']}');
      if (mounted) Navigator.pop(context, true);
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(widget.existing == null ? 'Takviye ekle' : 'Takviyeyi düzenle', style: h2Style),
        const SizedBox(height: 12),
        TextField(controller: _name, decoration: const InputDecoration(labelText: 'Ad (ör. Kreatin)')),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: TextField(controller: _dose, decoration: const InputDecoration(labelText: 'Doz (ör. 5 g)'))),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: _servings, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Kutuda kalan servis'))),
        ]),
        const SizedBox(height: 12),
        const Text('Hatırlatma saatleri', style: mutedStyle),
        Wrap(spacing: 8, children: [
          for (final t in _times) InputChip(label: Text(t), onDeleted: () => setState(() => _times.remove(t))),
          ActionChip(avatar: const Icon(Icons.add, size: 18), label: const Text('Saat ekle'), onPressed: _addTime),
        ]),
        const SizedBox(height: 16),
        Row(children: [
          if (widget.existing != null) ...[
            Expanded(child: OutlinedButton(onPressed: _delete, child: const Text('Sil'))),
            const SizedBox(width: 8),
          ],
          Expanded(child: FilledButton(onPressed: _busy ? null : _save, child: const Text('Kaydet'))),
        ]),
      ]),
    );
  }
}
