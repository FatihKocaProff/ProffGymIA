import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

import '../api.dart';
import '../form/form_logic.dart' as fl;
import '../theme.dart';
import '../widgets/common.dart';

class FormScreen extends StatefulWidget {
  const FormScreen({super.key});

  @override
  State<FormScreen> createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
  Future<dynamic>? _history;

  @override
  void initState() {
    super.initState();
    _history = Api.instance.get('/form-sessions', {'days': 30});
  }

  void _reload() => setState(() => _history = Api.instance.get('/form-sessions', {'days': 30}));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Form analizi')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        children: [
          const Text('Kamera eklem açılarını ölçer, tekrarlarını sayar ve formun bozulduğunda sesli uyarır. '
              'Görüntü telefonda işlenir, internete gönderilmez.', style: mutedStyle),
          const SizedBox(height: 16),
          for (final e in fl.exerciseTitles.entries) ...[
            Card(
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                title: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                subtitle: Text(fl.createAnalyzer(e.key).cameraTip),
                trailing: const Icon(Icons.play_circle_fill, color: FitColors.blue, size: 36),
                onTap: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => FormCameraScreen(exercise: e.key)));
                  _reload();
                },
              ),
            ),
            const SizedBox(height: 10),
          ],
          const SizedBox(height: 8),
          Panel(
            title: 'Son setlerin',
            child: FutureBuilder<dynamic>(
              future: _history,
              builder: (context, snap) {
                if (!snap.hasData) return const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()));
                final list = snap.data as List;
                if (list.isEmpty) return const Text('Henüz set yok. Bir hareket seçip başla.', style: mutedStyle);
                return Column(children: [
                  for (final s in list.take(10))
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('${fl.exerciseTitles[s['exercise']] ?? s['exercise']} · ${s['good_reps']}/${s['reps']} doğru'),
                      subtitle: Text('${fmtDate(s['created_at'])}${(s['issues'] as Map?)?.isNotEmpty == true ? ' · ${(s['issues'] as Map).keys.first}' : ''}'),
                      trailing: Chip2('%${(s['score'] as num).round()}',
                          color: (s['score'] as num) >= 80 ? 'green' : ((s['score'] as num) >= 60 ? 'yellow' : 'red')),
                    ),
                ]);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class FormCameraScreen extends StatefulWidget {
  const FormCameraScreen({super.key, required this.exercise});
  final String exercise;

  @override
  State<FormCameraScreen> createState() => _FormCameraScreenState();
}

class _FormCameraScreenState extends State<FormCameraScreen> {
  CameraController? _controller;
  CameraDescription? _camera;
  final _detector = PoseDetector(options: PoseDetectorOptions(mode: PoseDetectionMode.stream));
  final _tts = FlutterTts();
  final Map<String, DateTime> _lastSpoken = {};
  late fl.ExerciseAnalyzer _analyzer = fl.createAnalyzer(widget.exercise);
  final _started = DateTime.now();
  bool _busy = false;
  String? _error;
  fl.Feedback? _fb;
  Pose? _pose;
  Size? _imageSize;
  String? _flash;
  final List<String> _log = [];

  static const _orientations = {
    DeviceOrientation.portraitUp: 0,
    DeviceOrientation.landscapeLeft: 90,
    DeviceOrientation.portraitDown: 180,
    DeviceOrientation.landscapeRight: 270,
  };

  @override
  void initState() {
    super.initState();
    _start();
    _tts.setLanguage('tr-TR');
    _tts.setSpeechRate(0.5);
  }

  Future<void> _start() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) throw CameraException('none', 'Kamera bulunamadı');
      _camera = cameras.firstWhere((c) => c.lensDirection == CameraLensDirection.front, orElse: () => cameras.first);
      final controller = CameraController(
        _camera!,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: Platform.isAndroid ? ImageFormatGroup.nv21 : ImageFormatGroup.bgra8888,
      );
      await controller.initialize();
      await controller.startImageStream(_process);
      if (!mounted) return;
      setState(() => _controller = controller);
    } on CameraException catch (e) {
      setState(() => _error = 'Kamera açılamadı: ${e.description ?? e.code}. Ayarlardan kamera iznini kontrol et.');
    }
  }

  @override
  void dispose() {
    final c = _controller;
    _controller = null;
    if (c != null) {
      if (c.value.isStreamingImages) c.stopImageStream().catchError((_) {});
      c.dispose();
    }
    _detector.close();
    _tts.stop();
    super.dispose();
  }

  InputImage? _toInputImage(CameraImage image) {
    final camera = _camera!;
    final sensor = camera.sensorOrientation;
    InputImageRotation? rotation;
    if (Platform.isIOS) {
      rotation = InputImageRotationValue.fromRawValue(sensor);
    } else {
      var comp = _orientations[_controller?.value.deviceOrientation ?? DeviceOrientation.portraitUp];
      if (comp == null) return null;
      comp = camera.lensDirection == CameraLensDirection.front ? (sensor + comp) % 360 : (sensor - comp + 360) % 360;
      rotation = InputImageRotationValue.fromRawValue(comp);
    }
    if (rotation == null) return null;
    final format = InputImageFormatValue.fromRawValue(image.format.raw);
    if (format == null ||
        (Platform.isAndroid && format != InputImageFormat.nv21) ||
        (Platform.isIOS && format != InputImageFormat.bgra8888)) {
      return null;
    }
    if (image.planes.length != 1) return null;
    final plane = image.planes.first;
    final rotated = rotation == InputImageRotation.rotation90deg || rotation == InputImageRotation.rotation270deg;
    _imageSize = rotated ? Size(image.height.toDouble(), image.width.toDouble()) : Size(image.width.toDouble(), image.height.toDouble());
    return InputImage.fromBytes(
      bytes: plane.bytes,
      metadata: InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: rotation,
        format: format,
        bytesPerRow: plane.bytesPerRow,
      ),
    );
  }

  Future<void> _process(CameraImage image) async {
    if (_busy || !mounted) return;
    _busy = true;
    try {
      final input = _toInputImage(image);
      if (input == null) return;
      final poses = await _detector.processImage(input);
      if (!mounted) return;
      if (poses.isEmpty) {
        _speak(fl.cueVisibility);
        setState(() => _pose = null);
        return;
      }
      final pose = poses.first;
      final lm = <int, fl.P>{
        for (final entry in pose.landmarks.entries) entry.key.index: fl.P(entry.value.x, entry.value.y, entry.value.likelihood),
      };
      final fb = _analyzer.update(lm);
      _speak(fb.cue);
      if (fb.repDone != null) {
        _flash = fb.repDone;
        _log.insert(0, 'Tekrar ${fb.reps}: ${fb.repDone == 'good' ? 'doğru' : fb.repIssues.join(', ')}');
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) setState(() => _flash = null);
        });
      }
      setState(() {
        _pose = pose;
        _fb = fb;
      });
    } catch (_) {
    } finally {
      _busy = false;
    }
  }

  void _speak(String? cue) {
    if (cue == null) return;
    final now = DateTime.now();
    final last = _lastSpoken[cue];
    if (last != null && now.difference(last).inSeconds < 4) return;
    _lastSpoken[cue] = now;
    _tts.speak(cue);
  }

  Future<void> _finish() async {
    final a = _analyzer;
    if (a.reps == 0) {
      Navigator.pop(context);
      return;
    }
    try {
      final saved = await Api.instance.post('/form-sessions', {
        'exercise': a.name,
        'reps': a.reps,
        'good_reps': a.goodReps,
        'duration_seconds': DateTime.now().difference(_started).inSeconds,
        'issues': a.issues,
        'source': 'mobile',
      });
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Form skoru %${(saved['score'] as num).round()}'),
          content: Text('${a.reps} tekrar, ${a.goodReps} doğru.\n\n'
              '${a.issues.isEmpty ? 'Hiç uyarı yok, harika!' : a.issues.entries.map((e) => '• ${e.key}: ${e.value}').join('\n')}\n\n'
              'Sonuç PT\'ine ve aylık karnene eklendi.'),
          actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Tamam'))],
        ),
      );
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message, error: true);
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final c = _controller;
    final fb = _fb;
    final cueColor = fb?.cue == fl.cueGood ? FitColors.green : FitColors.red;
    return Scaffold(
      backgroundColor: FitColors.ink,
      appBar: AppBar(
        backgroundColor: FitColors.ink,
        foregroundColor: Colors.white,
        title: Text(_analyzer.title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'Sıfırla',
            onPressed: () => setState(() {
              _analyzer = fl.createAnalyzer(widget.exercise);
              _fb = null;
              _log.clear();
            }),
            icon: const Icon(Icons.restart_alt),
          ),
        ],
      ),
      body: _error != null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, style: const TextStyle(color: Colors.white))))
          : c == null
              ? const Center(child: CircularProgressIndicator())
              : Column(children: [
                  Expanded(
                    child: Center(
                      child: AspectRatio(
                        aspectRatio: 1 / c.value.aspectRatio,
                        child: Stack(fit: StackFit.expand, children: [
                          CameraPreview(c),
                          CustomPaint(
                            painter: _SkeletonPainter(
                              pose: _pose,
                              imageSize: _imageSize,
                              mirror: _camera?.lensDirection == CameraLensDirection.front && Platform.isAndroid,
                              color: _flash == 'good' ? FitColors.green : (_flash == 'bad' ? FitColors.red : Colors.white),
                            ),
                          ),
                          Positioned(
                            left: 12,
                            top: 12,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                              decoration: BoxDecoration(color: FitColors.ink.withValues(alpha: 0.8), borderRadius: BorderRadius.circular(8)),
                              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                                Text('${fb?.reps ?? 0}', style: numStyle.copyWith(color: Colors.white, fontSize: 48)),
                                const SizedBox(width: 10),
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 6),
                                  child: Text('doğru ${fb?.goodReps ?? 0}', style: const TextStyle(color: Color(0xFF7ED3A0), fontWeight: FontWeight.w700)),
                                ),
                              ]),
                            ),
                          ),
                          if (fb?.angle != null)
                            Positioned(
                              right: 12,
                              top: 12,
                              child: Text('${fb!.angle!.round()}°', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                            ),
                        ]),
                      ),
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    color: FitColors.ink,
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Text(fb?.cue ?? _analyzer.cameraTip,
                          style: TextStyle(color: fb?.cue != null ? cueColor : const Color(0xFFB9BCB6), fontSize: 18, fontWeight: FontWeight.w700)),
                      if (_log.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(_log.first, style: const TextStyle(color: Color(0xFFB9BCB6))),
                      ],
                      const SizedBox(height: 12),
                      FilledButton(onPressed: _finish, child: const Text('Seti bitir ve kaydet')),
                    ]),
                  ),
                ]),
    );
  }
}

class _SkeletonPainter extends CustomPainter {
  _SkeletonPainter({required this.pose, required this.imageSize, required this.mirror, required this.color});
  final Pose? pose;
  final Size? imageSize;
  final bool mirror;
  final Color color;

  static const bones = [
    [PoseLandmarkType.leftShoulder, PoseLandmarkType.rightShoulder],
    [PoseLandmarkType.leftShoulder, PoseLandmarkType.leftElbow],
    [PoseLandmarkType.leftElbow, PoseLandmarkType.leftWrist],
    [PoseLandmarkType.rightShoulder, PoseLandmarkType.rightElbow],
    [PoseLandmarkType.rightElbow, PoseLandmarkType.rightWrist],
    [PoseLandmarkType.leftShoulder, PoseLandmarkType.leftHip],
    [PoseLandmarkType.rightShoulder, PoseLandmarkType.rightHip],
    [PoseLandmarkType.leftHip, PoseLandmarkType.rightHip],
    [PoseLandmarkType.leftHip, PoseLandmarkType.leftKnee],
    [PoseLandmarkType.leftKnee, PoseLandmarkType.leftAnkle],
    [PoseLandmarkType.rightHip, PoseLandmarkType.rightKnee],
    [PoseLandmarkType.rightKnee, PoseLandmarkType.rightAnkle],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final p = pose, img = imageSize;
    if (p == null || img == null) return;
    final sx = size.width / img.width, sy = size.height / img.height;
    Offset pt(PoseLandmark l) => Offset(mirror ? size.width - l.x * sx : l.x * sx, l.y * sy);
    final line = Paint()
      ..color = color
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    for (final b in bones) {
      final a = p.landmarks[b[0]], c = p.landmarks[b[1]];
      if (a == null || c == null || a.likelihood < 0.5 || c.likelihood < 0.5) continue;
      canvas.drawLine(pt(a), pt(c), line);
    }
    final dot = Paint()..color = FitColors.blue;
    for (final l in p.landmarks.values) {
      if (l.type.index >= 11 && l.likelihood >= 0.5) canvas.drawCircle(pt(l), 5, dot);
    }
  }

  @override
  bool shouldRepaint(covariant _SkeletonPainter old) => true;
}
