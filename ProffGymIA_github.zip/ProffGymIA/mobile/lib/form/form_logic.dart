import 'dart:math' as math;

class P {
  const P(this.x, this.y, [this.vis = 1.0]);
  final double x;
  final double y;
  final double vis;
}

typedef Landmarks = Map<int, P>;

const lShoulder = 11, rShoulder = 12, lElbow = 13, rElbow = 14, lWrist = 15, rWrist = 16;
const lHip = 23, rHip = 24, lKnee = 25, rKnee = 26, lAnkle = 27, rAnkle = 28;

const sides = <Map<String, int>>[
  {'shoulder': lShoulder, 'elbow': lElbow, 'wrist': lWrist, 'hip': lHip, 'knee': lKnee, 'ankle': lAnkle},
  {'shoulder': rShoulder, 'elbow': rElbow, 'wrist': rWrist, 'hip': rHip, 'knee': rKnee, 'ankle': rAnkle},
];

const minVisibility = 0.5;

const cueVisibility = 'Tüm vücudun kamerada görünsün';
const cueDepth = 'Daha derine in';
const cueBack = 'Sırtını dik tut';
const cueKneesIn = 'Dizlerini dışa it';
const cueElbowDrift = 'Dirseğini gövdene sabitle';
const cueSwing = 'Gövdeni sallama';
const cueFullCurl = 'Ağırlığı tam yukarı çek';
const cueLockout = 'Kollarını yukarıda tam uzat';
const cueArch = 'Belini aşırı bükme';
const cueGood = 'Harika';

double angle(P a, P b, P c) {
  final abx = a.x - b.x, aby = a.y - b.y, cbx = c.x - b.x, cby = c.y - b.y;
  final norm = math.sqrt(abx * abx + aby * aby) * math.sqrt(cbx * cbx + cby * cby);
  if (norm == 0) return 0;
  final cos = ((abx * cbx + aby * cby) / norm).clamp(-1.0, 1.0);
  return math.acos(cos) * 180 / math.pi;
}

double leanFromVertical(P top, P bottom) {
  final dx = top.x - bottom.x, dy = bottom.y - top.y;
  if (dx == 0 && dy == 0) return 0;
  return (math.atan2(dx, dy) * 180 / math.pi).abs();
}

bool visible(Landmarks lm, List<int> ids) => ids.every((i) => lm[i] != null && lm[i]!.vis >= minVisibility);

Map<String, int>? bestSide(Landmarks lm, List<String> keys) {
  Map<String, int>? best;
  var bestScore = -1.0;
  for (final side in sides) {
    final ids = keys.map((k) => side[k]!).toList();
    if (!visible(lm, ids)) continue;
    final score = ids.fold<double>(0, (s, i) => s + lm[i]!.vis);
    if (score > bestScore) {
      bestScore = score;
      best = side;
    }
  }
  return best;
}

class Feedback {
  Feedback(this.reps, this.goodReps, this.phase, this.angle, {this.cue, this.repDone, this.repIssues = const []});
  final int reps;
  final int goodReps;
  final String phase;
  double? angle;
  String? cue;
  final String? repDone;
  final List<String> repIssues;
}

abstract class ExerciseAnalyzer {
  ExerciseAnalyzer({this.smoothing = 0.5});
  final double smoothing;
  String get name;
  String get title;
  String get cameraTip;

  int reps = 0;
  int goodReps = 0;
  final Map<String, int> issues = {};
  String phase = 'bekleniyor';
  final Map<String, double> _smooth = {};
  final Set<String> _repIssues = {};
  double repMin = 999;
  double repMax = -1;

  double ema(String key, double value) {
    final prev = _smooth[key];
    final v = prev == null ? value : prev + smoothing * (value - prev);
    _smooth[key] = v;
    return v;
  }

  String? flag(String cue) => _repIssues.add(cue) ? cue : null;

  void addIssue(String cue) => _repIssues.add(cue);

  Feedback finishRep() {
    final list = _repIssues.toList()..sort();
    reps++;
    String result;
    if (list.isEmpty) {
      goodReps++;
      result = 'good';
    } else {
      for (final i in list) {
        issues[i] = (issues[i] ?? 0) + 1;
      }
      result = 'bad';
    }
    _repIssues.clear();
    repMin = 999;
    repMax = -1;
    return Feedback(reps, goodReps, phase, null, repDone: result, repIssues: list);
  }

  double get score => reps == 0 ? 0 : goodReps / reps * 100;

  Feedback update(Landmarks lm);
}

class SquatAnalyzer extends ExerciseAnalyzer {
  SquatAnalyzer({super.smoothing});
  @override
  String get name => 'squat';
  @override
  String get title => 'Squat';
  @override
  String get cameraTip => 'Telefonu yere koy ve kameraya YANDAN dur; baştan ayağa tüm vücudun görünsün.';
  static const up = 160.0, down = 100.0, started = 140.0, maxLean = 50.0;

  @override
  Feedback update(Landmarks lm) {
    final side = bestSide(lm, ['shoulder', 'hip', 'knee', 'ankle']);
    if (side == null) return Feedback(reps, goodReps, phase, null, cue: cueVisibility);
    final knee = ema('knee', angle(lm[side['hip']]!, lm[side['knee']]!, lm[side['ankle']]!));
    final lean = ema('lean', leanFromVertical(lm[side['shoulder']]!, lm[side['hip']]!));
    String? cue;

    if (phase == 'bekleniyor' && knee >= up) phase = 'yukarı';
    if (phase == 'yukarı' && knee < started) phase = 'aşağı';
    if (phase == 'aşağı') {
      repMin = math.min(repMin, knee);
      if (knee < 125 && lean > maxLean) cue = flag(cueBack) ?? cue;
      if (knee < 125 && visible(lm, [lKnee, rKnee, lAnkle, rAnkle])) {
        final kneeW = (lm[lKnee]!.x - lm[rKnee]!.x).abs();
        final ankleW = (lm[lAnkle]!.x - lm[rAnkle]!.x).abs();
        final bodyH = (lm[side['shoulder']]!.y - lm[side['ankle']]!.y).abs();
        if (bodyH > 0 && ankleW > bodyH * 0.15 && kneeW < ankleW * 0.75) cue = flag(cueKneesIn) ?? cue;
      }
      if (knee >= up) {
        phase = 'yukarı';
        if (repMin > down) addIssue(cueDepth);
        final fb = finishRep()..angle = knee;
        fb.cue = fb.repIssues.contains(cueDepth) ? cueDepth : (fb.repDone == 'good' ? cueGood : null);
        return fb;
      }
    }
    return Feedback(reps, goodReps, phase, knee, cue: cue);
  }
}

class BicepsCurlAnalyzer extends ExerciseAnalyzer {
  BicepsCurlAnalyzer({super.smoothing});
  @override
  String get name => 'biceps_curl';
  @override
  String get title => 'Biceps curl';
  @override
  String get cameraTip => 'Kameraya YANDAN dur; çalışan kolun kameraya baksın.';
  static const open = 150.0, closed = 50.0, started = 120.0, maxDrift = 30.0, maxSwing = 15.0;
  double? _leanStart;

  @override
  Feedback update(Landmarks lm) {
    final side = bestSide(lm, ['shoulder', 'elbow', 'wrist', 'hip']);
    if (side == null) return Feedback(reps, goodReps, phase, null, cue: cueVisibility);
    final sh = lm[side['shoulder']]!, el = lm[side['elbow']]!, wr = lm[side['wrist']]!, hip = lm[side['hip']]!;
    final elbow = ema('elbow', angle(sh, el, wr));
    final drift = ema('drift', angle(hip, sh, el));
    final lean = ema('lean', leanFromVertical(sh, hip));
    String? cue;

    if (phase == 'bekleniyor' && elbow >= open) {
      phase = 'aşağı';
      _leanStart = lean;
    }
    if (phase == 'aşağı' && elbow < started) {
      phase = 'yukarı';
      _leanStart ??= lean;
    }
    if (phase == 'yukarı') {
      repMin = math.min(repMin, elbow);
      if (drift > maxDrift) cue = flag(cueElbowDrift) ?? cue;
      if (_leanStart != null && (lean - _leanStart!).abs() > maxSwing) cue = flag(cueSwing) ?? cue;
      if (elbow >= open) {
        phase = 'aşağı';
        if (repMin > closed + 10) addIssue(cueFullCurl);
        _leanStart = lean;
        final fb = finishRep()..angle = elbow;
        fb.cue = fb.repIssues.contains(cueFullCurl) ? cueFullCurl : (fb.repDone == 'good' ? cueGood : null);
        return fb;
      }
    }
    return Feedback(reps, goodReps, phase, elbow, cue: cue);
  }
}

class ShoulderPressAnalyzer extends ExerciseAnalyzer {
  ShoulderPressAnalyzer({super.smoothing});
  @override
  String get name => 'shoulder_press';
  @override
  String get title => 'Omuz press';
  @override
  String get cameraTip => 'Kameraya YANDAN dur; kolların ve kalçan görünsün.';
  static const bottom = 100.0, lockout = 155.0, started = 130.0, maxArch = 20.0;

  @override
  Feedback update(Landmarks lm) {
    final side = bestSide(lm, ['shoulder', 'elbow', 'wrist', 'hip']);
    if (side == null) return Feedback(reps, goodReps, phase, null, cue: cueVisibility);
    final sh = lm[side['shoulder']]!, el = lm[side['elbow']]!, wr = lm[side['wrist']]!, hip = lm[side['hip']]!;
    final elbow = ema('elbow', angle(sh, el, wr));
    final lean = ema('lean', leanFromVertical(sh, hip));
    final wristAbove = wr.y < sh.y;
    String? cue;

    if (phase == 'bekleniyor' && elbow < bottom && wristAbove) phase = 'aşağı';
    if (phase == 'aşağı' && elbow > started && wristAbove) phase = 'yukarı';
    if (phase == 'yukarı') {
      repMax = math.max(repMax, elbow);
      if (lean > maxArch) cue = flag(cueArch) ?? cue;
      if (elbow < bottom) {
        phase = 'aşağı';
        if (repMax < lockout) addIssue(cueLockout);
        final fb = finishRep()..angle = elbow;
        fb.cue = fb.repIssues.contains(cueLockout) ? cueLockout : (fb.repDone == 'good' ? cueGood : null);
        return fb;
      }
    }
    return Feedback(reps, goodReps, phase, elbow, cue: cue);
  }
}

ExerciseAnalyzer createAnalyzer(String name) => switch (name) {
      'biceps_curl' => BicepsCurlAnalyzer(),
      'shoulder_press' => ShoulderPressAnalyzer(),
      _ => SquatAnalyzer(),
    };

const exerciseTitles = {'squat': 'Squat', 'biceps_curl': 'Biceps curl', 'shoulder_press': 'Omuz press'};
