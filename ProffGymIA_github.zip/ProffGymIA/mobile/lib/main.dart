import 'package:flutter/material.dart';

import 'api.dart';
import 'screens/form_screens.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'screens/nutrition_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/workout_screen.dart';
import 'services/notifications.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.instance.load();
  try {
    await Reminders.instance.init();
  } catch (_) {
  }
  runApp(const FitAIApp());
}

class FitAIApp extends StatefulWidget {
  const FitAIApp({super.key});

  @override
  State<FitAIApp> createState() => _FitAIAppState();
}

class _FitAIAppState extends State<FitAIApp> {
  bool? _loggedIn;

  @override
  void initState() {
    super.initState();
    Api.instance.onUnauthorized = () => setState(() => _loggedIn = false);
    Api.instance.restore().then((ok) => setState(() => _loggedIn = ok && Api.instance.me?['role'] == 'member'));
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FitAI',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: switch (_loggedIn) {
        null => const Scaffold(backgroundColor: FitColors.ink, body: Center(child: CircularProgressIndicator())),
        false => LoginScreen(onLoggedIn: () => setState(() => _loggedIn = true)),
        true => HomeShell(onLogout: () => setState(() => _loggedIn = false)),
      },
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.onLogout});
  final VoidCallback onLogout;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(openTab: (i) => setState(() => _index = i)),
      const NutritionScreen(),
      const WorkoutScreen(),
      const FormScreen(),
      ProfileScreen(onLogout: widget.onLogout),
    ];
    return Scaffold(
      body: KeyedSubtree(key: ValueKey(_index), child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana sayfa'),
          NavigationDestination(icon: Icon(Icons.restaurant_outlined), selectedIcon: Icon(Icons.restaurant), label: 'Beslenme'),
          NavigationDestination(icon: Icon(Icons.fitness_center_outlined), selectedIcon: Icon(Icons.fitness_center), label: 'Antrenman'),
          NavigationDestination(icon: Icon(Icons.accessibility_new_outlined), selectedIcon: Icon(Icons.accessibility_new), label: 'Form'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Ben'),
        ],
      ),
    );
  }
}
