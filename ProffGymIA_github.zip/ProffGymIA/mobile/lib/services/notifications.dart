import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class Reminders {
  Reminders._();
  static final Reminders instance = Reminders._();

  final _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    tz.setLocalLocation(_guessLocation());
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    );
    await _plugin.initialize(settings: settings);
    _ready = true;
  }

  tz.Location _guessLocation() {
    final offset = DateTime.now().timeZoneOffset.inMilliseconds;
    final istanbul = tz.getLocation('Europe/Istanbul');
    if (istanbul.currentTimeZone.offset == offset) return istanbul;
    for (final loc in tz.timeZoneDatabase.locations.values) {
      if (loc.currentTimeZone.offset == offset) return loc;
    }
    return tz.UTC;
  }

  Future<bool> requestPermission() async {
    await init();
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final granted = await android?.requestNotificationsPermission();
    final ios = _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
    final iosGranted = await ios?.requestPermissions(alert: true, sound: true);
    return granted ?? iosGranted ?? true;
  }

  Future<void> scheduleAll(List<dynamic> supplements) async {
    await init();
    await _plugin.cancelAll();
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'supplements',
        'Takviye hatırlatıcı',
        channelDescription: 'Protein, kreatin gibi takviyelerin alım saatleri',
        importance: Importance.high,
        priority: Priority.high,
      ),
      iOS: DarwinNotificationDetails(),
    );
    for (final s in supplements) {
      if (s['is_active'] != true) continue;
      final times = (s['reminder_times'] as List).cast<String>();
      for (var i = 0; i < times.length; i++) {
        final parts = times[i].split(':');
        final hour = int.parse(parts[0]), minute = int.parse(parts[1]);
        final now = tz.TZDateTime.now(tz.local);
        var when = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
        if (!when.isAfter(now)) when = when.add(const Duration(days: 1));
        final left = s['servings_left'] as int;
        await _plugin.zonedSchedule(
          id: (s['id'] as int) * 10 + i,
          title: '${s['name']} zamanı',
          body: '${s['dose'] ?? '1 servis'}${left <= 5 ? ' · kutuda $left servis kaldı' : ''}',
          scheduledDate: when,
          notificationDetails: details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          matchDateTimeComponents: DateTimeComponents.time,
        );
      }
    }
  }
}
