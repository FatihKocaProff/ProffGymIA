import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ApiException implements Exception {
  ApiException(this.message, [this.status]);
  final String message;
  final int? status;
  @override
  String toString() => message;
}

class Api {
  Api._();
  static final Api instance = Api._();

  static const defaultServer = 'http://10.0.2.2:8000';

  String baseUrl = defaultServer;
  String? token;
  Map<String, dynamic>? me;
  void Function()? onUnauthorized;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    baseUrl = prefs.getString('server') ?? defaultServer;
    token = prefs.getString('token');
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('server', baseUrl);
    if (token == null) {
      await prefs.remove('token');
    } else {
      await prefs.setString('token', token!);
    }
  }

  Uri _uri(String path, [Map<String, dynamic>? query]) {
    final q = <String, String>{};
    query?.forEach((k, v) {
      if (v != null) q[k] = '$v';
    });
    return Uri.parse('$baseUrl$path').replace(queryParameters: q.isEmpty ? null : q);
  }

  Map<String, String> get _headers => {
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<dynamic> _send(Future<http.Response> Function() call) async {
    http.Response res;
    try {
      res = await call().timeout(const Duration(seconds: 60));
    } catch (_) {
      throw ApiException('Sunucuya ulaşılamadı. Telefon ve bilgisayar aynı Wi-Fi ağında mı? Sunucu adresi: $baseUrl');
    }
    if (res.statusCode == 401 && token != null) {
      await logout();
      onUnauthorized?.call();
      throw ApiException('Oturumun sona erdi, tekrar giriş yap.', 401);
    }
    if (res.statusCode == 204) return null;
    final body = utf8.decode(res.bodyBytes);
    dynamic data;
    try {
      data = body.isEmpty ? null : jsonDecode(body);
    } catch (_) {
      data = null;
    }
    if (res.statusCode >= 400) {
      throw ApiException(_errorText(data, res.statusCode), res.statusCode);
    }
    return data;
  }

  String _errorText(dynamic data, int status) {
    final d = data is Map ? data['detail'] : null;
    if (d is String) return d;
    if (d is List && d.isNotEmpty) {
      return d.map((e) => '${(e['loc'] as List).last}: ${e['msg']}').join(', ');
    }
    if (d is Map && d['message'] != null) {
      final missing = (d['missing'] as List?)?.join(', ');
      return '${d['message']}${missing != null ? ' ($missing)' : ''}';
    }
    return 'İstek başarısız oldu ($status).';
  }

  Future<dynamic> get(String path, [Map<String, dynamic>? query]) =>
      _send(() => http.get(_uri(path, query), headers: _headers));

  Future<dynamic> post(String path, [Object? body]) => _send(() => http.post(
        _uri(path),
        headers: {..._headers, 'Content-Type': 'application/json'},
        body: jsonEncode(body ?? {}),
      ));

  Future<dynamic> patch(String path, Object body, [Map<String, dynamic>? query]) => _send(() => http.patch(
        _uri(path, query),
        headers: {..._headers, 'Content-Type': 'application/json'},
        body: jsonEncode(body),
      ));

  Future<dynamic> delete(String path) => _send(() => http.delete(_uri(path), headers: _headers));

  Future<Map<String, dynamic>> login(String server, String email, String password) async {
    baseUrl = server.trim().replaceAll(RegExp(r'/+$'), '');
    final data = await _send(() => http.post(
          _uri('/auth/login'),
          body: {'username': email.trim(), 'password': password},
        ));
    token = data['access_token'] as String;
    await _save();
    me = Map<String, dynamic>.from(await get('/users/me'));
    return me!;
  }

  Future<void> register(String server, String name, String email, String password) async {
    baseUrl = server.trim().replaceAll(RegExp(r'/+$'), '');
    await post('/auth/register', {'full_name': name.trim(), 'email': email.trim(), 'password': password});
  }

  Future<bool> restore() async {
    await load();
    if (token == null) return false;
    try {
      me = Map<String, dynamic>.from(await get('/users/me'));
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> logout() async {
    token = null;
    me = null;
    await _save();
  }

  Future<Map<String, dynamic>> uploadMealPhoto(Uint8List bytes, String filename, String mealType) async {
    final lower = filename.toLowerCase();
    final mime = lower.endsWith('.png') ? 'png' : (lower.endsWith('.webp') ? 'webp' : 'jpeg');
    final req = http.MultipartRequest('POST', _uri('/meals/photo'))
      ..headers.addAll(_headers)
      ..fields['meal_type'] = mealType
      ..fields['analyze'] = 'true'
      ..files.add(http.MultipartFile.fromBytes('photo', bytes, filename: filename, contentType: MediaType('image', mime)));
    final data = await _send(() async => http.Response.fromStream(await req.send()));
    return Map<String, dynamic>.from(data);
  }

  String photoUrl(String photoPath) => '$baseUrl/uploads/$photoPath';

  Future<Map<String, dynamic>> uploadProfilePhoto(Uint8List bytes, String filename) async {
    final lower = filename.toLowerCase();
    final mime = lower.endsWith('.png') ? 'png' : (lower.endsWith('.webp') ? 'webp' : 'jpeg');
    final req = http.MultipartRequest('POST', _uri('/users/me/photo'))
      ..headers.addAll(_headers)
      ..files.add(http.MultipartFile.fromBytes('photo', bytes, filename: filename, contentType: MediaType('image', mime)));
    final data = await _send(() async => http.Response.fromStream(await req.send()));
    me = Map<String, dynamic>.from(data);
    return me!;
  }

  Future<Map<String, dynamic>> deleteProfilePhoto() async {
    me = Map<String, dynamic>.from(await delete('/users/me/photo'));
    return me!;
  }

  Future<Map<String, dynamic>> analyzeMealText(String text, {bool quick = false}) async =>
      Map<String, dynamic>.from(await post('/ai/food-text', {'text': text, 'quick': quick}));
}
