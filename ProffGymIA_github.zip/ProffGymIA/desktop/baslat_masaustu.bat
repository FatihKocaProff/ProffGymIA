@echo off
chcp 65001 >nul
cd /d "%~dp0"
title FitAI Masaustu Panel

if not exist ".venv\Scripts\python.exe" (
    echo Ilk kurulum yapiliyor, birkac dakika surebilir...
    python -m venv .venv || (echo Python bulunamadi. python.org'dan Python 3.11+ kur. & pause & exit /b 1)
)
fc /b requirements.txt ".venv\installed-requirements.txt" >nul 2>&1
if errorlevel 1 (
    ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt || (echo Paket kurulumu basarisiz. & pause & exit /b 1)
    copy /y requirements.txt ".venv\installed-requirements.txt" >nul
)

echo Sunucunun (backend\baslat.bat) acik oldugundan emin ol.
".venv\Scripts\python.exe" main.py
if errorlevel 1 pause
