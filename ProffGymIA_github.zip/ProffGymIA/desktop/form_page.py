"""Canlı form analizi sayfası: PT danışanını kamera karşısında çalıştırır, sonuç danışana kaydedilir."""
from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWidgets import QCheckBox, QComboBox, QHBoxLayout, QLabel, QListWidget, QPushButton, QSpinBox, QVBoxLayout, QWidget

from api import Api, ApiError
from camera import FormCoachThread
from form_coach.logic import CAMERA_TIPS, EXERCISES
from ui_common import C, DISPLAY_FONT, Panel, error, info, label


class FormPage(QWidget):
    def __init__(self, api: Api):
        super().__init__()
        self.api = api
        self.thread: FormCoachThread | None = None
        self.pending_member: int | None = None

        root = QVBoxLayout(self)
        root.setContentsMargins(36, 30, 36, 30)
        root.setSpacing(14)
        root.addWidget(label("Form analizi", "H1"))
        root.addWidget(label("Kamera eklem açılarını ölçer, tekrarları sayar ve hatalı formda sesli uyarır. "
                             "Görüntü bu bilgisayarda işlenir, sunucuya yalnızca sonuç gider.", "Muted", wrap=True))

        controls = QHBoxLayout()
        self.member = QComboBox()
        self.member.setMinimumWidth(220)
        self.exercise = QComboBox()
        for key, cls in EXERCISES.items():
            self.exercise.addItem(cls.title, key)
        self.exercise.currentIndexChanged.connect(self.update_tip)
        self.cam_index = QSpinBox()
        self.cam_index.setRange(0, 5)
        self.cam_index.setPrefix("Kamera ")
        self.speak = QCheckBox("Sesli uyarı")
        self.speak.setChecked(True)
        self.start_btn = QPushButton("Başlat")
        self.start_btn.clicked.connect(self.toggle)
        for w in (label("Danışan"), self.member, label("Hareket"), self.exercise, self.cam_index, self.speak):
            controls.addWidget(w)
        controls.addStretch()
        controls.addWidget(self.start_btn)
        root.addLayout(controls)
        self.tip = label("", "Muted")
        root.addWidget(self.tip)

        body = QHBoxLayout()
        body.setSpacing(18)
        self.video = QLabel("Başlat'a bas")
        self.video.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video.setMinimumSize(640, 360)
        self.video.setStyleSheet(f"background:{C['rail']}; color:#b9bcb6; border-radius:8px;")
        body.addWidget(self.video, 3)

        side = QVBoxLayout()
        counter = Panel()
        self.reps_lbl = QLabel("0")
        self.reps_lbl.setStyleSheet(f'font-family:"{DISPLAY_FONT}"; font-size:64pt; font-weight:700;')
        self.good_lbl = label("doğru tekrar: 0", "Muted")
        self.phase_lbl = label("", "Muted")
        self.cue_lbl = QLabel("")
        self.cue_lbl.setWordWrap(True)
        self.cue_lbl.setStyleSheet(f"color:{C['red']}; font-size:15pt; font-weight:600;")
        counter.body.addWidget(label("Tekrar", "H2"))
        counter.body.addWidget(self.reps_lbl)
        counter.body.addWidget(self.good_lbl)
        counter.body.addWidget(self.phase_lbl)
        counter.body.addWidget(self.cue_lbl)
        side.addWidget(counter)
        issues = Panel("Bu setteki uyarılar")
        self.issues = QListWidget()
        self.issues.setStyleSheet("QListWidget{border:none; background:transparent;}")
        issues.body.addWidget(self.issues)
        side.addWidget(issues, 1)
        body.addLayout(side, 1)
        root.addLayout(body, 1)
        self.update_tip()

    def refresh(self):
        self.member.clear()
        try:
            members = self.api.members()
        except ApiError as exc:
            return error(self, exc)
        for m in members:
            self.member.addItem(m["full_name"], m["id"])
        if self.pending_member:
            idx = self.member.findData(self.pending_member)
            if idx >= 0:
                self.member.setCurrentIndex(idx)
            self.pending_member = None

    def preselect(self, member_id: int):
        self.pending_member = member_id

    def update_tip(self):
        self.tip.setText("İpucu: " + CAMERA_TIPS[self.exercise.currentData()])

    def toggle(self):
        if self.thread:
            self.finish()
            return
        if self.member.currentData() is None:
            return error(self, "Önce bir danışan seç. (PT isen danışanların yönetici tarafından atanmış olmalı.)")
        self.issues.clear()
        self.reps_lbl.setText("0")
        self.good_lbl.setText("doğru tekrar: 0")
        self.cue_lbl.setText("")
        self.thread = FormCoachThread(self.exercise.currentData(), self.cam_index.value(), self.speak.isChecked())
        self.thread.frame_ready.connect(self.show_frame)
        self.thread.feedback.connect(self.on_feedback)
        self.thread.status.connect(self.phase_lbl.setText)
        self.thread.failed.connect(self.on_failed)
        self.thread.start()
        self.start_btn.setText("Bitir ve kaydet")
        for w in (self.member, self.exercise, self.cam_index):
            w.setEnabled(False)

    def show_frame(self, img: QImage):
        self.video.setPixmap(QPixmap.fromImage(img).scaled(
            self.video.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def on_feedback(self, fb):
        self.reps_lbl.setText(str(fb.reps))
        self.good_lbl.setText(f"doğru tekrar: {fb.good_reps}")
        self.phase_lbl.setText(f"Faz: {fb.phase}" + (f"   ·   açı {fb.angle:.0f}°" if fb.angle is not None else ""))
        if fb.cue:
            self.cue_lbl.setText(fb.cue)
            self.cue_lbl.setStyleSheet(f"color:{C['green'] if fb.cue == 'Harika' else C['red']}; font-size:15pt; font-weight:600;")
        if fb.rep_done:
            text = f"Tekrar {fb.reps}: " + ("doğru" if fb.rep_done == "good" else ", ".join(fb.rep_issues))
            self.issues.insertItem(0, text)

    def on_failed(self, msg):
        self._reset()
        error(self, msg)

    def finish(self):
        summary = self.thread.summary()
        member_id = self.member.currentData()
        self._reset()
        if not summary["reps"]:
            return info(self, "Hiç tekrar sayılmadı, kayıt yapılmadı.")
        try:
            saved = self.api.post("/form-sessions", {
                "user_id": member_id, "exercise": summary["exercise"], "reps": summary["reps"],
                "good_reps": summary["good_reps"], "duration_seconds": summary.get("duration_seconds", 0),
                "issues": summary["issues"], "source": "desktop",
            })
        except ApiError as exc:
            return error(self, exc)
        issues = "\n".join(f"• {k}: {v}" for k, v in summary["issues"].items()) or "Uyarı yok"
        info(self, f"{saved['reps']} tekrar, {saved['good_reps']} doğru — form skoru %{saved['score']:.0f}\n\n{issues}\n\n"
                   "Sonuç danışanın kaydına eklendi ve PDF karnede görünecek.")

    def _reset(self):
        if self.thread:
            self.thread.stop()
            self.thread = None
        self.start_btn.setText("Başlat")
        for w in (self.member, self.exercise, self.cam_index):
            w.setEnabled(True)
        self.video.clear()
        self.video.setText("Başlat'a bas")

    def hideEvent(self, event):
        if self.thread:
            self._reset()
        super().hideEvent(event)
