"""FitAI masaüstü paneli (salon sahibi ve PT).

Çalıştırma: baslat_masaustu.bat  veya  python main.py
Önce backend/baslat.bat ile sunucu açık olmalı.
"""
from __future__ import annotations

import re
import sys

from PyQt6.QtCore import QSettings, Qt, QTimer
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QPushButton,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from api import Api, ApiError
from form_page import FormPage
from gate import GatePage
from pages import MemberDetailPage, MembersPage, PackagesPage, TodayPage, pick_photo
from ui_common import BODY_FONT, C, DISPLAY_FONT, LABELS, STYLE, Avatar, confirm, error, label, run_async

DEMO = [("Yönetici", "admin@fitai.com", "admin123"), ("PT", "pt@fitai.com", "pt1234")]
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class LoginDialog(QDialog):
    """Açılış penceresi: Giriş yap / Kayıt ol.

    Kayıt olan herkes üye olarak açılır; salon yöneticisi dilediği üyeyi personal trainer yapar.
    Veritabanında hiç yönetici yoksa (ilk kurulum) oluşturulan hesap salon yöneticisi olur.
    """

    LABEL_WIDTH = 104

    def __init__(self, api: Api, settings: QSettings):
        super().__init__()
        self.api, self.settings = api, settings
        self.mode = "login"
        self.first_setup = False
        self.setWindowTitle("FitAI — Giriş")
        self.setMinimumWidth(780)
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)

        brand = QFrame()
        brand.setObjectName("Rail")
        brand.setMinimumWidth(320)
        bv = QVBoxLayout(brand)
        bv.setContentsMargins(32, 32, 32, 32)
        word = QLabel("FitAI")
        word.setStyleSheet(f'font-family:"{DISPLAY_FONT}"; font-size:54pt; font-weight:700; color:#f3f3ee;')
        bv.addWidget(word)
        plates = QHBoxLayout()
        plates.setSpacing(5)
        for color, h in (("#c4303a", 150), ("#1f5fae", 138), ("#d9a514", 120), ("#2a8551", 100)):
            p = QFrame()
            p.setFixedSize(24, h)
            p.setStyleSheet(f"background:{color}; border-radius:5px;")
            plates.addWidget(p, 0, Qt.AlignmentFlag.AlignVCenter)
        bar = QFrame()
        bar.setFixedSize(90, 10)
        bar.setStyleSheet("background:#8d9196; border-radius:3px;")
        plates.addWidget(bar, 0, Qt.AlignmentFlag.AlignVCenter)
        plates.addStretch()
        bv.addStretch()
        bv.addLayout(plates)
        bv.addStretch()
        tag = QLabel("Salon yönetimi, turnike ve antrenör paneli")
        tag.setStyleSheet("color:#b9bcb6; font-size:11pt;")
        tag.setWordWrap(True)
        bv.addWidget(tag)
        row.addWidget(brand)

        form_host = QWidget()
        fv = QVBoxLayout(form_host)
        fv.setContentsMargins(40, 40, 40, 40)
        fv.setSpacing(10)
        fv.addStretch()
        self.title = label("Giriş yap", "H1")
        fv.addWidget(self.title)
        self.subtitle = label("", "Muted", wrap=True)
        fv.addWidget(self.subtitle)
        fv.addSpacing(6)

        self.email = QLineEdit(settings.value("email", ""))
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        login_page = QWidget()
        lf = self._form(login_page)
        lf.addRow(self._lbl("E-posta"), self.email)
        lf.addRow(self._lbl("Şifre"), self.password)

        self.r_name = QLineEdit()
        self.r_email = QLineEdit()
        self.r_phone = QLineEdit()
        self.r_phone.setPlaceholderText("İsteğe bağlı")
        self.r_password = QLineEdit()
        self.r_password.setPlaceholderText("En az 6 karakter")
        self.r_password2 = QLineEdit()
        for w in (self.r_password, self.r_password2):
            w.setEchoMode(QLineEdit.EchoMode.Password)
        register_page = QWidget()
        rf = self._form(register_page)
        rf.addRow(self._lbl("Ad soyad"), self.r_name)
        rf.addRow(self._lbl("E-posta"), self.r_email)
        rf.addRow(self._lbl("Telefon"), self.r_phone)
        rf.addRow(self._lbl("Şifre"), self.r_password)
        rf.addRow(self._lbl("Şifre tekrar"), self.r_password2)

        self.stack = QStackedWidget()
        self.stack.addWidget(login_page)
        self.stack.addWidget(register_page)
        fv.addWidget(self.stack)

        server_host = QWidget()
        sf = self._form(server_host)
        self.server = QLineEdit(settings.value("server", "http://127.0.0.1:8000"))
        self.server.editingFinished.connect(self.check_setup)
        sf.addRow(self._lbl("Sunucu"), self.server)
        fv.addWidget(server_host)

        self.msg = QLabel("")
        self.msg.setWordWrap(True)
        fv.addWidget(self.msg)
        self.submit_btn = QPushButton("Giriş yap")
        self.submit_btn.setAutoDefault(False)
        self.submit_btn.clicked.connect(self.submit)
        fv.addWidget(self.submit_btn)
        for w in (self.email, self.password, self.r_name, self.r_email, self.r_phone, self.r_password, self.r_password2):
            w.returnPressed.connect(self.submit)

        switch_row = QHBoxLayout()
        self.switch_text = label("", "Muted")
        self.switch_btn = QPushButton("")
        self.switch_btn.setAutoDefault(False)
        self.switch_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.switch_btn.setStyleSheet(
            f"QPushButton{{border:none; background:transparent; color:{C['blue']}; padding:0; font-weight:600; text-decoration:underline;}}"
            f"QPushButton:hover{{background:transparent; color:{C['ink']};}}"
        )
        self.switch_btn.clicked.connect(lambda: self.set_mode("register" if self.mode == "login" else "login"))
        switch_row.addWidget(self.switch_text)
        switch_row.addWidget(self.switch_btn)
        switch_row.addStretch()
        fv.addLayout(switch_row)

        self.demo_host = QWidget()
        demo_row = QHBoxLayout(self.demo_host)
        demo_row.setContentsMargins(0, 6, 0, 0)
        demo_row.addWidget(label("Örnek hesap:", "Muted"))
        for title, email, pw in DEMO:
            b = QPushButton(title)
            b.setObjectName("Ghost")
            b.setAutoDefault(False)
            b.clicked.connect(lambda _=False, e=email, p=pw: self.fill(e, p))
            demo_row.addWidget(b)
        demo_row.addStretch()
        fv.addWidget(self.demo_host)
        fv.addStretch()
        row.addWidget(form_host, 1)

        self.set_mode("login")
        (self.password if self.email.text() else self.email).setFocus()
        QTimer.singleShot(0, lambda: self.check_setup(open_register=not self.email.text()))

    def _form(self, host: QWidget) -> QFormLayout:
        form = QFormLayout(host)
        form.setContentsMargins(0, 0, 0, 0)
        form.setVerticalSpacing(10)
        return form

    def _lbl(self, text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setFixedWidth(self.LABEL_WIDTH)
        return lbl

    def set_msg(self, text: str = "", ok: bool = False):
        self.msg.setStyleSheet(f"color:{C['green'] if ok else C['red']}; font-weight:{600 if ok else 400};")
        self.msg.setText(text)

    def _base_url(self) -> str:
        return self.server.text().strip().rstrip("/") or "http://127.0.0.1:8000"

    def set_mode(self, mode: str):
        self.mode = mode
        register = mode == "register"
        self.stack.setCurrentIndex(1 if register else 0)
        self.demo_host.setVisible(not register)
        self.set_msg("")
        self._update_texts()
        if register:
            (self.r_email if self.r_name.text() else self.r_name).setFocus()
            self.check_setup()
        else:
            (self.password if self.email.text() else self.email).setFocus()

    def _update_texts(self):
        register = self.mode == "register"
        if register and self.first_setup:
            self.setWindowTitle("FitAI — İlk kurulum")
            self.title.setText("İlk kurulum")
            self.subtitle.setText("Bu salonda henüz yönetici hesabı yok. Oluşturacağın hesap salon yöneticisi olur.")
            self.submit_btn.setText("Yönetici hesabını oluştur")
        elif register:
            self.setWindowTitle("FitAI — Kayıt ol")
            self.title.setText("Kayıt ol")
            self.subtitle.setText("Hesabın üye olarak açılır. Salon yöneticisi seni personal trainer yaparsa bu panele de girebilirsin.")
            self.submit_btn.setText("Kayıt ol")
        else:
            self.setWindowTitle("FitAI — Giriş")
            self.title.setText("Giriş yap")
            self.subtitle.setText("Salon yöneticisi ve personal trainer hesabıyla.")
            self.submit_btn.setText("Giriş yap")
        self.switch_text.setText("Zaten hesabın var mı?" if register else "Hesabın yok mu?")
        self.switch_btn.setText("Giriş yap" if register else "Kayıt ol")

    def check_setup(self, open_register: bool = False):
        """Sunucuya 'yönetici var mı?' diye sorar; arayüzü dondurmamak için arka planda."""
        self.api.base_url = self._base_url()

        def done(status):
            first = bool(status.get("needs_admin"))
            changed = first != self.first_setup
            self.first_setup = first
            if first and open_register and self.mode == "login":
                self.set_mode("register")
            elif changed:
                self._update_texts()

        run_async(self.api.setup_status, done, lambda _err: None)

    def fill(self, email, password):
        self.email.setText(email)
        self.password.setText(password)
        self.submit()

    def submit(self):
        self.register() if self.mode == "register" else self.try_login()

    def try_login(self):
        self.api.base_url = self._base_url()
        if not self.email.text().strip():
            self.email.setFocus()
            return self.set_msg("E-posta adresini yaz.")
        if not self.password.text():
            from_email_field = self.email.hasFocus()
            self.password.setFocus()
            return self.set_msg("" if from_email_field else "Şifreni yaz.")
        try:
            me = self.api.login(self.email.text().strip(), self.password.text())
        except ApiError as exc:
            self.set_msg(str(exc))
            return
        if me["role"] == "member":
            self.api.logout()
            self.set_msg("Bu bir üye hesabı. Masaüstü panel salon yöneticisi ve personal trainer içindir; "
                         "üyeler mobil uygulamayı veya web panelini kullanır. Yönetici seni PT yaparsa buradan da girebilirsin.")
            return
        self.settings.setValue("server", self.api.base_url)
        self.settings.setValue("email", self.email.text().strip())
        self.accept()

    def register(self):
        name = self.r_name.text().strip()
        email = self.r_email.text().strip()
        phone = self.r_phone.text().strip() or None
        pw, pw2 = self.r_password.text(), self.r_password2.text()
        if len(name) < 2:
            return self.set_msg("Ad soyadını yaz.")
        if not EMAIL_RE.match(email):
            return self.set_msg("Geçerli bir e-posta adresi yaz.")
        if not 6 <= len(pw) <= 72:
            return self.set_msg("Şifre 6 ile 72 karakter arasında olmalı.")
        if pw != pw2:
            return self.set_msg("Şifreler aynı değil.")
        self.api.base_url = self._base_url()
        self.submit_btn.setEnabled(False)
        try:
            if self.first_setup:
                self.api.setup_admin(name, email, pw, phone)
                self.api.login(email, pw)
                self.settings.setValue("server", self.api.base_url)
                self.settings.setValue("email", email)
                self.accept()
                return
            self.api.register_member(name, email, pw, phone)
        except ApiError as exc:
            if self.first_setup and exc.status == 403:
                self.first_setup = False
                self._update_texts()
            self.set_msg(str(exc))
            return
        finally:
            self.submit_btn.setEnabled(True)
        self.settings.setValue("server", self.api.base_url)
        for w in (self.r_name, self.r_email, self.r_phone, self.r_password, self.r_password2):
            w.clear()
        self.email.setText(email)
        self.password.clear()
        self.set_mode("login")
        self.set_msg("Üye hesabın oluşturuldu. Bu e-posta ve şifreyle mobil uygulamaya ve web paneline girebilirsin. "
                     "Salon yöneticisi seni personal trainer yaptığında bu panele de girersin.", ok=True)


class MainWindow(QMainWindow):
    def __init__(self, api: Api, on_logout):
        super().__init__()
        self.api = api
        self.on_logout = on_logout
        self.setWindowTitle("FitAI Panel")
        self.resize(1360, 860)

        central = QWidget()
        self.setCentralWidget(central)
        row = QHBoxLayout(central)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)

        rail = QFrame()
        rail.setObjectName("Rail")
        rail.setFixedWidth(232)
        rv = QVBoxLayout(rail)
        rv.setContentsMargins(14, 22, 14, 18)
        rv.setSpacing(4)
        word = QLabel("FitAI")
        word.setObjectName("Wordmark")
        rv.addWidget(word)
        rv.addSpacing(18)

        self.stack = QStackedWidget()
        self.pages = {}
        is_admin = api.me["role"] == "admin"
        self.pages["today"] = TodayPage(api)
        self.pages["members"] = MembersPage(api)
        self.pages["member"] = MemberDetailPage(api)
        self.pages["packages"] = PackagesPage(api)
        self.pages["gate"] = GatePage(api)
        self.pages["form"] = FormPage(api)
        for page in self.pages.values():
            self.stack.addWidget(page)
            if hasattr(page, "open_member"):
                page.open_member.connect(self.open_member)
            if hasattr(page, "navigate"):
                page.navigate.connect(self.go)
        self.pages["member"].start_form.connect(self.start_form)

        nav = ([("today", "Bugün"), ("members", "Üyeler"), ("packages", "Paketler"), ("gate", "Turnike"), ("form", "Form analizi")]
               if is_admin else [("members", "Danışanlarım"), ("form", "Form analizi")])
        self.nav_group = QButtonGroup(self)
        self.nav_buttons = {}
        for key, text in nav:
            b = QPushButton(text)
            b.setObjectName("NavButton")
            b.setCheckable(True)
            b.clicked.connect(lambda _=False, k=key: self.go(k))
            self.nav_group.addButton(b)
            self.nav_buttons[key] = b
            rv.addWidget(b)
        rv.addStretch()
        who_row = QHBoxLayout()
        who_row.setSpacing(10)
        self.my_avatar = Avatar(42, dark=True)
        self.my_avatar.set_user(api.me, api)
        who_row.addWidget(self.my_avatar)
        who = QLabel(f"<b style='color:#f3f3ee'>{api.me['full_name']}</b><br>{LABELS['role'][api.me['role']]}")
        who_row.addWidget(who, 1)
        rv.addLayout(who_row)
        photo = QPushButton("Profil fotoğrafım")
        photo.setObjectName("LinkButton")
        photo.clicked.connect(self.change_my_photo)
        rv.addWidget(photo)
        out = QPushButton("Çıkış yap")
        out.setObjectName("LinkButton")
        out.clicked.connect(self.logout)
        rv.addWidget(out)

        row.addWidget(rail)
        row.addWidget(self.stack, 1)
        self.go(nav[0][0])

    def change_my_photo(self):
        """Giriş yapan yönetici/PT kendi profil fotoğrafını değiştirir veya kaldırır."""
        if self.api.me.get("photo_path") and confirm(self, "Mevcut fotoğrafını kaldırmak ister misin?\n\n"
                                                           "Hayır dersen yeni bir fotoğraf seçebilirsin.", "Profil fotoğrafı"):
            try:
                self.api.delete_photo()
            except ApiError as exc:
                return error(self, exc)
        else:
            picked = pick_photo(self)
            if not picked:
                return
            try:
                self.api.upload_photo(None, *picked)
            except ApiError as exc:
                return error(self, exc)
        self.my_avatar.set_user(self.api.me, self.api)

    def go(self, key: str):
        key, _, arg = key.partition(":")
        page = self.pages[key]
        if arg and hasattr(page, "preset"):
            page.preset = arg
        nav_key = "members" if key == "member" else key
        if nav_key in self.nav_buttons:
            self.nav_buttons[nav_key].setChecked(True)
        self.stack.setCurrentWidget(page)
        if key != "member":
            page.refresh()

    def open_member(self, user_id: int):
        self.stack.setCurrentWidget(self.pages["member"])
        self.nav_buttons["members"].setChecked(True)
        self.pages["member"].show_member(user_id)

    def start_form(self, user_id: int):
        self.pages["form"].preselect(user_id)
        self.go("form")

    def logout(self):
        self.api.logout()
        self.close()
        self.on_logout()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("FitAI Panel")
    app.setFont(QFont(BODY_FONT, 10))
    app.setStyleSheet(STYLE)
    settings = QSettings("FitAI", "Panel")
    api = Api()
    windows = []

    def show_login():
        dlg = LoginDialog(api, settings)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            app.quit()
            return
        win = MainWindow(api, show_login)
        windows.clear()
        windows.append(win)
        win.show()

    show_login()
    if windows:
        sys.exit(app.exec())


if __name__ == "__main__":
    main()
