@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Once baslat_masaustu.bat ile kurulumu yap. & pause & exit /b 1)
".venv\Scripts\python.exe" -m form_coach %*
pause
