"""Masaüstü panel sayfaları: Bugün, Üyeler, Üye detayı, Paketler."""
from __future__ import annotations

from datetime import date, datetime

import pyqtgraph as pg
from PyQt6.QtCore import QDate, Qt, QUrl, pyqtSignal
from PyQt6.QtGui import QDesktopServices, QPixmap
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from api import Api, ApiError
from ui_common import (
    C,
    DAYS,
    LABELS,
    Avatar,
    Chip,
    Panel,
    PlateRing,
    Scoreboard,
    cell,
    clear_layout,
    confirm,
    error,
    fmt_date,
    fmt_num,
    fmt_time,
    info,
    label,
    make_table,
    run_async,
    status_color,
    status_text,
    tl,
)


MAX_PHOTO_BYTES = 10 * 1024 * 1024


def pick_photo(parent) -> tuple[bytes, str] | None:
    """Dosya seçtirir; (içerik, dosya adı) döner. Vazgeçilirse veya dosya uygun değilse None."""
    path, _ = QFileDialog.getOpenFileName(parent, "Profil fotoğrafı seç", "", "Resimler (*.jpg *.jpeg *.png *.webp)")
    if not path:
        return None
    try:
        with open(path, "rb") as fh:
            data = fh.read(MAX_PHOTO_BYTES + 1)
    except OSError as exc:
        error(parent, f"Dosya okunamadı: {exc}")
        return None
    if len(data) > MAX_PHOTO_BYTES:
        error(parent, "Fotoğraf 10 MB'tan büyük olamaz.")
        return None
    return data, path.replace("\\", "/").rsplit("/", 1)[-1]


def page_header(title: str, subtitle: str = "") -> tuple[QHBoxLayout, QHBoxLayout]:
    """Sayfa başlığı; sağdaki aksiyon düzenini de döndürür."""
    row = QHBoxLayout()
    col = QVBoxLayout()
    col.setSpacing(2)
    col.addWidget(label(title, "H1"))
    if subtitle:
        col.addWidget(label(subtitle, "Muted"))
    row.addLayout(col)
    row.addStretch()
    actions = QHBoxLayout()
    row.addLayout(actions)
    return row, actions


class Page(QWidget):
    """Kaydırılabilir sayfa iskeleti. Alt sınıflar `build()` içinde self.content'i doldurur."""

    open_member = pyqtSignal(int)
    navigate = pyqtSignal(str)

    def __init__(self, api: Api):
        super().__init__()
        self.api = api
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)
        host = QWidget()
        scroll.setWidget(host)
        self.content = QVBoxLayout(host)
        self.content.setContentsMargins(36, 30, 36, 40)
        self.content.setSpacing(18)

    def refresh(self):
        clear_layout(self.content)
        try:
            self.build()
        except ApiError as exc:
            self.content.addWidget(label(f"Bu sayfa yüklenemedi: {exc}", "Muted", wrap=True))
        self.content.addStretch()

    def build(self):
        raise NotImplementedError


class TodayPage(Page):
    def build(self):
        s = self.api.stats()
        members = self.api.members()
        logs = self.api.get("/checkin/logs", limit=10)
        today = date.today()
        head, actions = page_header("Bugün", f"{fmt_date(today, True)}, {DAYS[today.weekday()]}")
        gate_btn = QPushButton("Turnikeyi aç")
        gate_btn.clicked.connect(lambda: self.navigate.emit("gate"))
        actions.addWidget(gate_btn)
        self.content.addLayout(head)
        self.content.addWidget(Scoreboard([
            (f"{s['active_members']} / {s['total_members']}", "aktif üye", "green"),
            (str(s["expiring_soon"]), "7 gün içinde bitiyor", "yellow"),
            (str(s["today_checkins"]), "bugünkü giriş", "blue"),
            (str(s["denied_today"]), "reddedilen giriş", "red"),
            (tl(s["month_revenue"]), "bu ayki satış", C["ink"]),
        ]))

        grid = QHBoxLayout()
        grid.setSpacing(18)
        exp = Panel("Üyeliği bitenler ve bitmek üzere olanlar")
        expiring = sorted((m for m in members if m["remaining_days"] <= 7), key=lambda m: -m["remaining_days"])
        if expiring:
            t = make_table(["Üye", "Durum"])
            for m in expiring:
                r = t.rowCount()
                t.insertRow(r)
                t.setItem(r, 0, cell(m["full_name"], data=m["id"]))
                t.setItem(r, 1, cell(status_text(m["remaining_days"], m["active"]), color=status_color(m["remaining_days"], m["active"]), bold=True))
            t.cellDoubleClicked.connect(lambda row, _c, t=t: self.open_member.emit(t.item(row, 0).data(Qt.ItemDataRole.UserRole)))
            exp.body.addWidget(t)
            exp.body.addWidget(label("Çift tıklayarak üyeyi aç.", "Muted"))
        else:
            exp.body.addWidget(label("Önümüzdeki 7 gün içinde biten üyelik yok.", "Muted"))
        upcoming = sorted((m for m in members if m["active"] and m["remaining_days"] > 7), key=lambda m: m["remaining_days"])[:3]
        if upcoming:
            exp.body.addWidget(label("Sıradaki bitişler", "H2"))
            t2 = make_table(["Üye", "Bitiş", "Kalan"])
            for m in upcoming:
                r = t2.rowCount()
                t2.insertRow(r)
                t2.setItem(r, 0, cell(m["full_name"], data=m["id"]))
                t2.setItem(r, 1, cell(fmt_date(m["end_date"])))
                t2.setItem(r, 2, cell(f"{m['remaining_days']} gün", align_right=True, color="green", bold=True))
            t2.setFixedHeight(46 + 40 * len(upcoming))
            t2.cellDoubleClicked.connect(lambda row, _c, t=t2: self.open_member.emit(t.item(row, 0).data(Qt.ItemDataRole.UserRole)))
            exp.body.addWidget(t2)
        all_btn = QPushButton("Kalan güne göre tüm üyelikler")
        all_btn.setObjectName("Ghost")
        all_btn.clicked.connect(lambda: self.navigate.emit("members:30"))
        exp.body.addWidget(all_btn, 0, Qt.AlignmentFlag.AlignLeft)
        grid.addWidget(exp, 1)

        last = Panel("Son geçişler")
        if logs:
            t = make_table(["Saat", "Kişi", "Yöntem", "Sonuç"], stretch_col=1)
            for lg in logs:
                r = t.rowCount()
                t.insertRow(r)
                t.setItem(r, 0, cell(fmt_time(lg["created_at"])))
                t.setItem(r, 1, cell(f"{lg['full_name'] or 'Tanınmayan'} — {lg['reason'] or ''}"))
                t.setItem(r, 2, cell(LABELS["method"].get(lg["method"], lg["method"])))
                t.setItem(r, 3, cell("Girdi" if lg["granted"] else "Reddedildi", color="green" if lg["granted"] else "red", bold=True))
            last.body.addWidget(t)
        else:
            last.body.addWidget(label("Bugün henüz geçiş yok.", "Muted"))
        grid.addWidget(last, 1)
        self.content.addLayout(grid)


MEMBER_FILTERS = [
    ("Hepsi", None),
    ("Aktif (7 günden fazla)", "active"),
    ("Bitmek üzere (7 gün)", 7),
    ("15 gün içinde bitiyor", 15),
    ("30 gün içinde bitiyor", 30),
    ("Süresi dolmuş / paketi yok", "expired"),
]


class MembersPage(Page):
    preset = None

    def build(self):
        is_admin = self.api.me["role"] == "admin"
        self.members = self.api.members()
        head, actions = page_header("Üyeler" if is_admin else "Danışanlarım",
                                    f"{len(self.members)} {'kayıtlı üye' if is_admin else 'danışan'}")
        if is_admin:
            new_btn = QPushButton("Yeni üye kaydet")
            new_btn.clicked.connect(self.new_member)
            actions.addWidget(new_btn)
        self.content.addLayout(head)

        panel = Panel()
        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Ad, e-posta veya telefon ara")
        self.search.textChanged.connect(self.fill)
        self.status_filter = QComboBox()
        for text, key in MEMBER_FILTERS:
            self.status_filter.addItem(text, key)
        if self.preset is not None:
            idx = self.status_filter.findData(int(self.preset) if str(self.preset).isdigit() else self.preset)
            self.status_filter.setCurrentIndex(max(idx, 0))
            self.preset = None
        self.status_filter.currentIndexChanged.connect(self.fill)
        filters.addWidget(self.search, 3)
        filters.addWidget(self.status_filter, 1)
        panel.body.addLayout(filters)
        self.table = make_table(["Ad", "E-posta", "PT" if is_admin else "Hedef", "Durum", "Kalan gün", "Son kilo"])
        self.table.setMinimumHeight(460)
        self.table.cellDoubleClicked.connect(lambda row, _c: self.open_member.emit(self.table.item(row, 0).data(Qt.ItemDataRole.UserRole)))
        panel.body.addWidget(self.table)
        self.empty = label("", "Muted", wrap=True)
        self.empty.hide()
        panel.body.addWidget(self.empty)
        panel.body.addWidget(label("Üyenin detayını açmak için satıra çift tıkla.", "Muted"))
        self.content.addWidget(panel)
        self.fill()
        if is_admin:
            self.content.addWidget(self._trainers_panel())

    def _trainers_panel(self) -> Panel:
        """Personal trainer'lar. Üye → PT ve PT → üye geçişi kişinin detay sayfasındaki butonla yapılır."""
        trainers = self.api.trainers()
        counts: dict[int, int] = {}
        for m in self.members:
            if m["trainer_id"]:
                counts[m["trainer_id"]] = counts.get(m["trainer_id"], 0) + 1
        panel = Panel(f"Personal trainer'lar ({len(trainers)})")
        if not trainers:
            panel.body.addWidget(label("Henüz personal trainer yok. Bir üyenin detayını açıp “Personal trainer yap” butonuna bas.",
                                       "Muted", wrap=True))
            return panel
        t = make_table(["Ad", "E-posta", "Danışan"])
        for tr in trainers:
            r = t.rowCount()
            t.insertRow(r)
            t.setItem(r, 0, cell(tr["full_name"], bold=True, data=tr["id"]))
            t.setItem(r, 1, cell(tr["email"]))
            t.setItem(r, 2, cell(counts.get(tr["id"], 0), align_right=True))
        t.setMinimumHeight(min(60 + 40 * len(trainers), 260))
        t.cellDoubleClicked.connect(lambda row, _c: self.open_member.emit(t.item(row, 0).data(Qt.ItemDataRole.UserRole)))
        panel.body.addWidget(t)
        panel.body.addWidget(label("Bir üyeyi PT yapmak için üyenin detayını aç ve “Personal trainer yap”a bas. "
                                   "PT'yi tekrar üye yapmak için satırına çift tıkla.", "Muted", wrap=True))
        return panel

    @staticmethod
    def _matches(m: dict, key) -> bool:
        if key == "active":
            return m["active"] and m["remaining_days"] > 7
        if key == "expired":
            return not m["active"]
        if isinstance(key, int):
            return m["active"] and m["remaining_days"] <= key
        return True

    def fill(self):
        is_admin = self.api.me["role"] == "admin"
        q = self.search.text().strip().lower()
        key = self.status_filter.currentData()
        rows = [m for m in self.members
                if (not q or q in f"{m['full_name']} {m['email']} {m['phone'] or ''}".lower()) and self._matches(m, key)]
        if isinstance(key, int):
            rows.sort(key=lambda m: m["remaining_days"])
        self.table.setRowCount(0)
        self._show_empty(rows, key, q)
        for m in rows:
            r = self.table.rowCount()
            self.table.insertRow(r)
            self.table.setItem(r, 0, cell(m["full_name"], bold=True, data=m["id"]))
            self.table.setItem(r, 1, cell(m["email"]))
            self.table.setItem(r, 2, cell((m["trainer_name"] or "—") if is_admin else LABELS["goal"][m["goal"]]))
            self.table.setItem(r, 3, cell(status_text(m["remaining_days"], m["active"]), color=status_color(m["remaining_days"], m["active"]), bold=True))
            self.table.setItem(r, 4, cell(f"{m['remaining_days']}  ·  {fmt_date(m['end_date'])}" if m["active"] else "0", align_right=True))
            self.table.setItem(r, 5, cell(f"{fmt_num(m['last_weight'])} kg" if m["last_weight"] else "—", align_right=True))

    def _show_empty(self, rows: list, key, q: str):
        if rows:
            self.empty.hide()
            return
        text = "Aramaya uyan kayıt yok."
        if not self.members:
            text = "Henüz üye yok."
        elif isinstance(key, int) and not q:
            nearest = min((m for m in self.members if m["active"]), key=lambda m: m["remaining_days"], default=None)
            text = f"Önümüzdeki {key} gün içinde üyeliği biten yok."
            if nearest:
                text += (f" En yakın bitiş: {nearest['full_name']}, {nearest['remaining_days']} gün kaldı "
                         f"({fmt_date(nearest['end_date'])}). Daha uzun süreyi görmek için yukarıdan 15 veya 30 günü seç.")
        self.empty.setText(text)
        self.empty.show()

    def new_member(self):
        dlg = NewMemberDialog(self.api, self)
        if dlg.exec() and dlg.created:
            self.open_member.emit(dlg.created["id"])


class NewMemberDialog(QDialog):
    def __init__(self, api: Api, parent=None):
        super().__init__(parent)
        self.api = api
        self.created = None
        self.setWindowTitle("Yeni üye kaydet")
        self.setMinimumWidth(420)
        form = QFormLayout(self)
        self.name = QLineEdit()
        self.email = QLineEdit()
        self.phone = QLineEdit()
        self.password = QLineEdit("uye1234")
        self.trainer = QComboBox()
        self.trainer.addItem("Atanmasın", None)
        for t in api.trainers():
            self.trainer.addItem(t["full_name"], t["id"])
        form.addRow("Ad soyad", self.name)
        form.addRow("E-posta", self.email)
        form.addRow("Telefon", self.phone)
        form.addRow("Geçici şifre", self.password)
        form.addRow("PT", self.trainer)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Kaydet")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Vazgeç")
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def save(self):
        try:
            self.created = self.api.post("/users", {
                "full_name": self.name.text().strip(), "email": self.email.text().strip(),
                "phone": self.phone.text().strip() or None, "password": self.password.text(),
                "role": "member", "trainer_id": self.trainer.currentData(),
            })
        except ApiError as exc:
            error(self, exc)
            return
        self.accept()


class MemberDetailPage(Page):
    start_form = pyqtSignal(int)

    def __init__(self, api: Api):
        super().__init__(api)
        self.user_id: int | None = None

    def show_member(self, user_id: int):
        self.user_id = user_id
        self.refresh()

    def build(self):
        uid = self.user_id
        is_admin = self.api.me["role"] == "admin"
        q = {"user_id": uid}
        user = self.api.user(uid)
        status = self.api.get("/memberships/status", **q)

        back = QPushButton("← " + ("Üyeler" if is_admin else "Danışanlarım"))
        back.setObjectName("Ghost")
        back.setFixedWidth(160)
        back.clicked.connect(lambda: self.navigate.emit("members"))
        self.content.addWidget(back)

        head = QHBoxLayout()
        head.setSpacing(24)
        ring = PlateRing(150)
        ring.set_status(status["remaining_days"], status["active"])
        head.addWidget(ring)
        photo_col = QVBoxLayout()
        photo_col.setSpacing(6)
        avatar = Avatar(112)
        avatar.set_user(user, self.api)
        photo_col.addWidget(avatar, 0, Qt.AlignmentFlag.AlignHCenter)
        if is_admin:
            photo_btn = QPushButton("Fotoğrafı değiştir" if user.get("photo_path") else "Fotoğraf ekle")
            photo_btn.setObjectName("Ghost")
            photo_btn.clicked.connect(lambda: self.change_photo(user))
            photo_col.addWidget(photo_btn)
            if user.get("photo_path"):
                remove_btn = QPushButton("Fotoğrafı kaldır")
                remove_btn.setObjectName("Ghost")
                remove_btn.clicked.connect(lambda: self.remove_photo(user))
                photo_col.addWidget(remove_btn)
        head.addLayout(photo_col)
        info_col = QVBoxLayout()
        info_col.addWidget(label(user["full_name"], "H1"))
        info_col.addWidget(label(f"{user['email']}   {user['phone'] or ''}", "Muted"))
        chips = QHBoxLayout()
        if user["role"] == "trainer":
            chips.addWidget(Chip("Personal trainer", "green"))
        chips.addWidget(Chip(status_text(status["remaining_days"], status["active"]), status_color(status["remaining_days"], status["active"])))
        chips.addWidget(Chip(LABELS["goal"][user["goal"]], "blue"))
        if status["end_date"]:
            chips.addWidget(label(f"Bitiş: {fmt_date(status['end_date'], True)}", "Muted"))
        chips.addStretch()
        info_col.addLayout(chips)
        btns = QHBoxLayout()
        pdf_btn = QPushButton("PDF gelişim karnesi")
        pdf_btn.clicked.connect(self.save_report)
        form_btn = QPushButton("Form analizi başlat")
        form_btn.setObjectName("Ghost")
        form_btn.clicked.connect(lambda: self.start_form.emit(uid))
        btns.addWidget(pdf_btn)
        btns.addWidget(form_btn)
        if is_admin:
            face_btn = QPushButton("Turnike için yüz kaydet")
            face_btn.setObjectName("Ghost")
            face_btn.clicked.connect(lambda: self.enroll_face(user))
            btns.addWidget(face_btn)
            if user["role"] != "admin":
                to_trainer = user["role"] == "member"
                role_btn = QPushButton("Personal trainer yap" if to_trainer else "Üye yap")
                role_btn.setObjectName("Ghost")
                role_btn.clicked.connect(lambda: self.change_role(user, "trainer" if to_trainer else "member"))
                btns.addWidget(role_btn)
        btns.addStretch()
        info_col.addLayout(btns)
        head.addLayout(info_col, 1)
        self.content.addLayout(head)

        tabs = QTabWidget()
        tabs.addTab(self._tab_general(user, is_admin), "Genel")
        tabs.addTab(self._tab_progress(q), "Kilo ve beslenme")
        tabs.addTab(self._tab_workouts(uid), "Antrenman")
        tabs.addTab(self._tab_form(q), "Form analizi")
        self.content.addWidget(tabs)

    def change_photo(self, user: dict):
        picked = pick_photo(self)
        if not picked:
            return
        try:
            self.api.upload_photo(user["id"], *picked)
        except ApiError as exc:
            return error(self, exc)
        self.refresh()

    def remove_photo(self, user: dict):
        if not confirm(self, f"{user['full_name']} kişisinin profil fotoğrafı kaldırılsın mı?"):
            return
        try:
            self.api.delete_photo(user["id"])
        except ApiError as exc:
            return error(self, exc)
        self.refresh()

    def change_role(self, user: dict, role: str):
        name = user["full_name"]
        if role == "trainer":
            question = f"{name} personal trainer yapılsın mı?\n\nMasaüstü panele PT olarak girebilecek ve ona danışan atayabileceksin."
        else:
            question = f"{name} tekrar üye yapılsın mı?\n\nVarsa danışanlarının PT ataması kaldırılır."
        if not confirm(self, question):
            return
        try:
            self.api.set_role(user["id"], role)
        except ApiError as exc:
            return error(self, exc)
        info(self, f"{name} artık {'personal trainer' if role == 'trainer' else 'üye'}.")
        self.refresh()

    def _tab_general(self, user, is_admin):
        w = QWidget()
        grid = QGridLayout(w)
        grid.setContentsMargins(0, 14, 0, 0)
        grid.setSpacing(18)
        uid = user["id"]
        row = 0
        if is_admin:
            sell = Panel("Paket sat veya üyeliği uzat")
            pkgs = self.api.packages()
            if pkgs:
                line = QHBoxLayout()
                combo = QComboBox()
                for p in pkgs:
                    combo.addItem(f"{p['name']} · {p['duration_days']} gün · {tl(p['price'])}", p)
                price = QDoubleSpinBox()
                price.setRange(0, 1_000_000)
                price.setDecimals(0)
                price.setSuffix(" ₺")
                price.setValue(pkgs[0]["price"])
                combo.currentIndexChanged.connect(lambda _i: price.setValue(combo.currentData()["price"]))
                btn = QPushButton("Satışı kaydet")
                line.addWidget(combo, 3)
                line.addWidget(price, 1)
                line.addWidget(btn)
                sell.body.addLayout(line)
                sell.body.addWidget(label("Üyelik devam ediyorsa yeni süre mevcut bitişin ertesi günü başlar.", "Muted", wrap=True))

                def do_sell():
                    try:
                        m = self.api.post("/memberships", {"user_id": uid, "package_id": combo.currentData()["id"], "price_paid": price.value()})
                    except ApiError as exc:
                        return error(self, exc)
                    info(self, f"Satış kaydedildi. Yeni bitiş: {fmt_date(m['end_date'], True)}")
                    self.refresh()

                btn.clicked.connect(do_sell)
            else:
                sell.body.addWidget(label("Satışta paket yok. Paketler sayfasından ekle.", "Muted"))
            grid.addWidget(sell, row, 0)

            assign = Panel("PT ataması")
            line = QHBoxLayout()
            trainer = QComboBox()
            trainer.addItem("Atanmasın", None)
            for t in self.api.trainers():
                trainer.addItem(t["full_name"], t["id"])
                if t["id"] == user["trainer_id"]:
                    trainer.setCurrentIndex(trainer.count() - 1)
            save = QPushButton("Kaydet")
            save.setObjectName("Ghost")

            def do_assign():
                try:
                    self.api.patch(f"/users/{uid}/trainer", {"trainer_id": trainer.currentData()})
                except ApiError as exc:
                    return error(self, exc)
                info(self, "PT ataması kaydedildi.")

            save.clicked.connect(do_assign)
            line.addWidget(trainer, 1)
            line.addWidget(save)
            assign.body.addLayout(line)
            history = self.api.get("/memberships", user_id=uid)
            if history:
                assign.body.addWidget(label("Satış geçmişi", "H2"))
                for m in history[:5]:
                    assign.body.addWidget(label(f"{fmt_date(m['start_date'], True)} – {fmt_date(m['end_date'], True)}   ·   {tl(m['price_paid'])}"))
            grid.addWidget(assign, row, 1)
            row += 1

        metab = Panel("Metabolizma")
        try:
            m = self.api.get("/users/me/metabolism", user_id=uid)
        except ApiError:
            metab.body.addWidget(label("Profil eksik: cinsiyet, doğum tarihi, boy ve en az bir kilo kaydı gerekiyor. "
                                       "Üye bunları mobil uygulamadan girer.", "Muted", wrap=True))
        else:
            figs = QGridLayout()
            items = [(m["bmr"], "kcal", "BMR"), (m["tdee"], "kcal", "Günlük harcama"), (m["target_calories"], "kcal", "Hedef kalori"),
                     (m["protein_g"], "g", "Protein"), (m["carbs_g"], "g", "Karbonhidrat"), (m["fat_g"], "g", "Yağ"),
                     (fmt_num(m["water_ml"] / 1000, 2), "L", "Su"), (fmt_num(m["bmi"]), "", f"BMI · {m['bmi_category']}")]
            for i, (v, unit, cap) in enumerate(items):
                box = QVBoxLayout()
                num = QLabel(f"{v} <span style='font-size:10pt;color:{C['ink2']}'>{unit}</span>")
                num.setStyleSheet('font-family:"Bahnschrift"; font-size:20pt; font-weight:600;')
                box.addWidget(num)
                box.addWidget(label(cap, "Muted"))
                figs.addLayout(box, i // 4, i % 4)
            metab.body.addLayout(figs)
            metab.body.addWidget(label("BMR Mifflin-St Jeor formülüyle, günlük harcama aktivite seviyesine göre hesaplandı.", "Muted", wrap=True))
        grid.addWidget(metab, row, 0)

        sup = Panel("Takviyeler")
        supplements = self.api.get("/supplements", user_id=uid)
        if supplements:
            for s in supplements:
                line = QHBoxLayout()
                line.addWidget(label(f"<b>{s['name']}</b>  {s['dose'] or ''}"))
                line.addStretch()
                line.addWidget(label(", ".join(s["reminder_times"]) or "saat yok", "Muted"))
                line.addWidget(Chip(f"{s['servings_left']} servis", "yellow" if s["low_stock"] else "green"))
                sup.body.addLayout(line)
        else:
            sup.body.addWidget(label("Takviye eklenmemiş. Üye mobil uygulamadan ekler.", "Muted"))
        grid.addWidget(sup, row, 1)
        return w

    def _tab_progress(self, q):
        w = QWidget()
        grid = QGridLayout(w)
        grid.setContentsMargins(0, 14, 0, 0)
        grid.setSpacing(18)

        chart_panel = Panel("Kilo değişimi (son 60 gün)")
        weights = self.api.get("/weights", days=60, **q)
        if len(weights) >= 2:
            plot = pg.PlotWidget(axisItems={"bottom": pg.DateAxisItem(orientation="bottom")})
            plot.setBackground(C["surface"])
            plot.showGrid(x=False, y=True, alpha=0.25)
            plot.setMinimumHeight(240)
            plot.setMouseEnabled(x=False, y=False)
            plot.hideButtons()
            xs = [datetime.fromisoformat(r["log_date"]).timestamp() for r in weights]
            ys = [r["weight_kg"] for r in weights]
            plot.plot(xs, ys, pen=pg.mkPen(C["blue"], width=2.5),
                      fillLevel=min(ys) - 0.5, brush=pg.mkBrush(31, 95, 174, 25))
            plot.plot([xs[-1]], [ys[-1]], pen=None, symbol="o", symbolSize=9, symbolBrush=C["surface"], symbolPen=pg.mkPen(C["blue"], width=2.5))
            for axis in ("left", "bottom"):
                plot.getAxis(axis).setPen(pg.mkPen(C["line"]))
                plot.getAxis(axis).setTextPen(pg.mkPen(C["ink2"]))
            chart_panel.body.addWidget(plot)
            delta = ys[-1] - ys[0]
            color = C["green"] if delta < 0 else C["blue"]
            chart_panel.body.addWidget(label(f"{len(ys)} kayıtta değişim: <b style='color:{color}'>{'+' if delta > 0 else ''}{fmt_num(delta)} kg</b>"
                                             f"   ·   {fmt_num(ys[0])} → {fmt_num(ys[-1])} kg"))
        else:
            chart_panel.body.addWidget(label("Grafik için en az iki gün kilo kaydı gerekiyor.", "Muted"))
        grid.addWidget(chart_panel, 0, 0, 1, 2)

        macro = Panel("Bugünkü beslenme")
        s = self.api.get("/meals/summary", **q)
        for name, val, target, unit in [("Kalori", s["calories"], s["target_calories"], "kcal"),
                                        ("Protein", s["protein_g"], s["target_protein_g"], "g"),
                                        ("Karbonhidrat", s["carbs_g"], s["target_carbs_g"], "g"),
                                        ("Yağ", s["fat_g"], s["target_fat_g"], "g")]:
            top = QHBoxLayout()
            top.addWidget(label(name))
            top.addStretch()
            top.addWidget(label(f"{fmt_num(val)}{' / ' + str(target) if target else ''} {unit}"))
            macro.body.addLayout(top)
            bar = QProgressBar()
            bar.setTextVisible(False)
            bar.setFixedHeight(10)
            bar.setRange(0, 100)
            pct = int(min(val / target * 100, 100)) if target else 0
            over = bool(target) and val > target * 1.05
            bar.setValue(pct)
            bar.setStyleSheet(f"QProgressBar{{background:{C['surface2']}; border:none; border-radius:5px;}}"
                              f"QProgressBar::chunk{{background:{C['red'] if over else C['blue']}; border-radius:5px;}}")
            macro.body.addWidget(bar)
        grid.addWidget(macro, 1, 0)

        meals_panel = Panel("Son 7 günün öğünleri")
        meals = self.api.get("/meals", days=7, **q)
        if meals:
            t = make_table(["Foto", "Gün", "Öğün", "Ne yedi", "kcal", "P / K / Y"], stretch_col=3)
            t.verticalHeader().setDefaultSectionSize(64)
            for meal in meals:
                r = t.rowCount()
                t.insertRow(r)
                thumb = QLabel("—")
                thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
                t.setCellWidget(r, 0, thumb)
                if meal["photo_path"]:
                    self._load_thumb(thumb, meal["photo_path"])
                t.setItem(r, 1, cell(fmt_date(meal["meal_date"])))
                tag = {"ai": "  · AI", "auto": "  · otomatik", "diary": "  · defter"}.get(meal["source"], "")
                t.setItem(r, 2, cell(LABELS["meal"][meal["meal_type"]] + tag))
                t.setItem(r, 3, cell(meal["description"] or ""))
                t.setItem(r, 4, cell(round(meal["calories"]), align_right=True, bold=True))
                t.setItem(r, 5, cell(f"{fmt_num(meal['protein_g'])} / {fmt_num(meal['carbs_g'])} / {fmt_num(meal['fat_g'])}", align_right=True))
            t.setMinimumHeight(min(80 + 64 * len(meals), 420))
            meals_panel.body.addWidget(t)
        else:
            meals_panel.body.addWidget(label("Son 7 günde öğün girilmemiş.", "Muted"))
        grid.addWidget(meals_panel, 1, 1)
        grid.setColumnStretch(0, 2)
        grid.setColumnStretch(1, 3)
        return w

    def _load_thumb(self, target: QLabel, photo_path: str):
        def loaded(data):
            pix = QPixmap()
            if pix.loadFromData(data):
                target.setPixmap(pix.scaled(56, 56, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation))
        run_async(self.api.download, loaded, None, self.api.file_url(photo_path))

    def _tab_workouts(self, uid):
        w = QWidget()
        col = QVBoxLayout(w)
        col.setContentsMargins(0, 14, 0, 0)
        col.setSpacing(18)
        plan = Panel("Program (bugünden itibaren 14 gün)")
        workouts = self.api.get("/workouts", days=14, user_id=uid)
        if not workouts:
            plan.body.addWidget(label("Planlanmış antrenman yok.", "Muted"))
        for wo in workouts:
            head = QHBoxLayout()
            d = date.fromisoformat(wo["workout_date"])
            head.addWidget(label(f"<b style='font-size:12pt'>{wo['title']}</b>   <span style='color:{C['ink2']}'>{fmt_date(d)} {DAYS[d.weekday()]}</span>"))
            head.addStretch()
            head.addWidget(Chip("Tamamlandı", "green") if wo["completed"] else Chip("Planlandı", "blue"))
            delete = QPushButton("Sil")
            delete.setObjectName("Ghost")
            delete.clicked.connect(lambda _=False, wid=wo["id"]: self._delete_workout(wid))
            head.addWidget(delete)
            plan.body.addLayout(head)
            if wo["notes"]:
                plan.body.addWidget(label(wo["notes"], "Muted", wrap=True))
            if wo["exercises"]:
                t = make_table(["Hareket", "Set", "Tekrar", "Ağırlık"])
                for e in wo["exercises"]:
                    r = t.rowCount()
                    t.insertRow(r)
                    t.setItem(r, 0, cell(e["name"]))
                    t.setItem(r, 1, cell(e["sets"], align_right=True))
                    t.setItem(r, 2, cell(e["reps"], align_right=True))
                    t.setItem(r, 3, cell(f"{fmt_num(e['weight_kg'])} kg" if e["weight_kg"] is not None else "—", align_right=True))
                t.setFixedHeight(46 + 40 * len(wo["exercises"]))
                plan.body.addWidget(t)
        col.addWidget(plan)
        col.addWidget(WorkoutForm(self.api, uid, on_saved=self.refresh))
        return w

    def _delete_workout(self, wid):
        if not confirm(self, "Bu antrenman silinsin mi?"):
            return
        try:
            self.api.delete(f"/workouts/{wid}")
        except ApiError as exc:
            return error(self, exc)
        self.refresh()

    def _tab_form(self, q):
        w = QWidget()
        col = QVBoxLayout(w)
        col.setContentsMargins(0, 14, 0, 0)
        panel = Panel("Form analizi geçmişi (son 30 gün)")
        sessions = self.api.get("/form-sessions", days=30, **q)
        if sessions:
            t = make_table(["Tarih", "Hareket", "Tekrar", "Doğru", "Skor", "En sık uyarı", "Kaynak"], stretch_col=5)
            for s in sessions:
                r = t.rowCount()
                t.insertRow(r)
                issues = s["issues"] or {}
                top = max(issues.items(), key=lambda kv: kv[1]) if issues else None
                score_color = "green" if s["score"] >= 80 else "yellow" if s["score"] >= 60 else "red"
                t.setItem(r, 0, cell(f"{fmt_date(s['created_at'])} {fmt_time(s['created_at'])}"))
                t.setItem(r, 1, cell(LABELS["exercise"].get(s["exercise"], s["exercise"])))
                t.setItem(r, 2, cell(s["reps"], align_right=True))
                t.setItem(r, 3, cell(s["good_reps"], align_right=True))
                t.setItem(r, 4, cell(f"%{s['score']:.0f}", align_right=True, color=score_color, bold=True))
                t.setItem(r, 5, cell(f"{top[0]} ({top[1]})" if top else "—"))
                t.setItem(r, 6, cell("Masaüstü" if s["source"] == "desktop" else "Mobil"))
            t.setMinimumHeight(min(60 + 40 * len(sessions), 480))
            panel.body.addWidget(t)
        else:
            panel.body.addWidget(label("Henüz form analizi yapılmamış. Yukarıdaki 'Form analizi başlat' ile başla.", "Muted"))
        col.addWidget(panel)
        return w

    def save_report(self):
        today = date.today()
        dlg = QDialog(self)
        dlg.setWindowTitle("PDF gelişim karnesi")
        form = QFormLayout(dlg)
        month = QComboBox()
        for i in range(6):
            y, m = today.year, today.month - i
            while m <= 0:
                m, y = m + 12, y - 1
            month.addItem(f"{['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'][m-1]} {y}", f"{y}-{m:02d}")
        form.addRow("Ay", month)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Oluştur")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Vazgeç")
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        form.addRow(buttons)
        if not dlg.exec():
            return
        try:
            pdf = self.api.report_pdf(self.user_id, month.currentData())
        except ApiError as exc:
            return error(self, exc)
        name = self.api.user(self.user_id)["full_name"].replace(" ", "_")
        path, _ = QFileDialog.getSaveFileName(self, "Karneyi kaydet", f"FitAI_Karne_{name}_{month.currentData()}.pdf", "PDF (*.pdf)")
        if not path:
            return
        with open(path, "wb") as fh:
            fh.write(pdf)
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def enroll_face(self, user):
        from gate import FaceEnrollDialog

        dlg = FaceEnrollDialog(self.api, user, self)
        dlg.exec()


class WorkoutForm(Panel):
    """PT'nin danışana antrenman tanımladığı form."""

    def __init__(self, api: Api, client_id: int, on_saved):
        super().__init__("Yeni antrenman tanımla")
        self.api, self.client_id, self.on_saved = api, client_id, on_saved
        top = QHBoxLayout()
        self.day = QDateEdit(QDate.currentDate())
        self.day.setCalendarPopup(True)
        self.day.setDisplayFormat("dd.MM.yyyy")
        self.title = QLineEdit()
        self.title.setPlaceholderText("Başlık, örn. Alt vücut + core")
        top.addWidget(self.day)
        top.addWidget(self.title, 1)
        self.body.addLayout(top)
        self.notes = QLineEdit()
        self.notes.setPlaceholderText("Not (isteğe bağlı), örn. Squat'ta dizler ayak uçlarını geçmesin")
        self.body.addWidget(self.notes)
        self.body.addWidget(label("Hareketler: ad, set, tekrar, ağırlık (kg)", "Muted"))
        self.rows_layout = QVBoxLayout()
        self.body.addLayout(self.rows_layout)
        self.rows: list[tuple] = []
        self.add_row("Squat")
        actions = QHBoxLayout()
        add = QPushButton("Hareket ekle")
        add.setObjectName("Ghost")
        add.clicked.connect(lambda: self.add_row())
        save = QPushButton("Antrenmanı kaydet")
        save.clicked.connect(self.save)
        actions.addWidget(add)
        actions.addStretch()
        actions.addWidget(save)
        self.body.addLayout(actions)

    def add_row(self, name: str = ""):
        row = QHBoxLayout()
        n = QLineEdit(name)
        n.setPlaceholderText("Hareket")
        sets = QSpinBox()
        sets.setRange(1, 50)
        sets.setValue(3)
        sets.setSuffix(" set")
        reps = QSpinBox()
        reps.setRange(1, 500)
        reps.setValue(10)
        reps.setSuffix(" tekrar")
        kg = QDoubleSpinBox()
        kg.setRange(0, 500)
        kg.setSingleStep(2.5)
        kg.setSuffix(" kg")
        kg.setSpecialValueText("ağırlıksız")
        remove = QPushButton("Kaldır")
        remove.setObjectName("Ghost")
        holder = QWidget()
        holder.setLayout(row)
        for wdg, stretch in ((n, 3), (sets, 1), (reps, 1), (kg, 1), (remove, 0)):
            row.addWidget(wdg, stretch)
        row.setContentsMargins(0, 0, 0, 0)
        entry = (holder, n, sets, reps, kg)
        self.rows.append(entry)
        self.rows_layout.addWidget(holder)

        def drop():
            self.rows.remove(entry)
            holder.deleteLater()

        remove.clicked.connect(drop)

    def save(self):
        exercises = [
            {"name": n.text().strip(), "sets": s.value(), "reps": r.value(), "weight_kg": k.value() or None}
            for _h, n, s, r, k in self.rows if n.text().strip()
        ]
        if not self.title.text().strip():
            return error(self, "Antrenmana bir başlık ver.")
        try:
            self.api.post("/workouts", {
                "client_id": self.client_id, "workout_date": self.day.date().toString("yyyy-MM-dd"),
                "title": self.title.text().strip(), "notes": self.notes.text().strip() or None, "exercises": exercises,
            })
        except ApiError as exc:
            return error(self, exc)
        info(self, "Antrenman kaydedildi. Üye mobil uygulamada görecek.")
        self.on_saved()


class PackagesPage(Page):
    def build(self):
        pkgs = self.api.packages(include_inactive=True)
        head, actions = page_header("Paketler", "Üyeler aktif paketleri mobil uygulamada görür.")
        add = QPushButton("Paket ekle")
        add.clicked.connect(lambda: self.edit(None))
        actions.addWidget(add)
        self.content.addLayout(head)
        panel = Panel()
        t = make_table(["Paket", "Süre", "Fiyat", "Günlük", "Durum"])
        for p in pkgs:
            r = t.rowCount()
            t.insertRow(r)
            t.setItem(r, 0, cell(f"{p['name']}   {p['description'] or ''}", bold=True, data=p))
            t.setItem(r, 1, cell(f"{p['duration_days']} gün", align_right=True))
            t.setItem(r, 2, cell(tl(p["price"]), align_right=True))
            t.setItem(r, 3, cell(tl(p["price"] / p["duration_days"]), align_right=True, color="ink2"))
            t.setItem(r, 4, cell("Satışta" if p["is_active"] else "Satışta değil", color="green" if p["is_active"] else "red", bold=True))
        t.cellDoubleClicked.connect(lambda row, _c: self.edit(t.item(row, 0).data(Qt.ItemDataRole.UserRole)))
        t.setMinimumHeight(300)
        panel.body.addWidget(t)
        panel.body.addWidget(label("Düzenlemek için satıra çift tıkla.", "Muted"))
        self.content.addWidget(panel)

    def edit(self, p):
        dlg = QDialog(self)
        dlg.setWindowTitle("Paketi düzenle" if p else "Paket ekle")
        dlg.setMinimumWidth(380)
        form = QFormLayout(dlg)
        name = QLineEdit(p["name"] if p else "")
        days = QSpinBox()
        days.setRange(1, 3660)
        days.setValue(p["duration_days"] if p else 30)
        days.setSuffix(" gün")
        price = QDoubleSpinBox()
        price.setRange(0, 1_000_000)
        price.setDecimals(0)
        price.setSuffix(" ₺")
        price.setValue(p["price"] if p else 0)
        desc = QLineEdit((p or {}).get("description") or "")
        active = QCheckBox("Satışta")
        active.setChecked(p["is_active"] if p else True)
        form.addRow("Paket adı", name)
        form.addRow("Süre", days)
        form.addRow("Fiyat", price)
        form.addRow("Açıklama", desc)
        form.addRow("", active)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Kaydet")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Vazgeç")
        form.addRow(buttons)
        buttons.rejected.connect(dlg.reject)

        def save():
            body = {"name": name.text().strip(), "duration_days": days.value(), "price": price.value(),
                    "description": desc.text().strip() or None, "is_active": active.isChecked()}
            try:
                if p:
                    self.api.patch(f"/packages/{p['id']}", body)
                else:
                    self.api.post("/packages", body)
            except ApiError as exc:
                return error(dlg, exc)
            dlg.accept()
            self.refresh()

        buttons.accepted.connect(save)
        dlg.exec()
