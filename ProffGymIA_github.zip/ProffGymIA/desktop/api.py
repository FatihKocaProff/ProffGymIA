"""FitAI API istemcisi. Masaüstü panelin sunucuyla tüm konuşması buradan geçer."""
from __future__ import annotations

import requests


class ApiError(Exception):
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class Api:
    def __init__(self, base_url: str = "http://127.0.0.1:8000"):
        self.base_url = base_url.rstrip("/")
        self.token: str | None = None
        self.me: dict | None = None
        self.session = requests.Session()

    def _request(self, method: str, path: str, *, timeout: float = 15, raw: bool = False, **kwargs):
        headers = kwargs.pop("headers", {})
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        try:
            resp = self.session.request(method, self.base_url + path, headers=headers, timeout=timeout, **kwargs)
        except requests.ConnectionError as exc:
            raise ApiError("Sunucuya ulaşılamadı. backend klasöründeki baslat.bat açık mı?") from exc
        except requests.Timeout as exc:
            raise ApiError("Sunucu zamanında yanıt vermedi.") from exc
        if resp.status_code == 204:
            return None
        if not resp.ok:
            raise ApiError(self._error_text(resp), resp.status_code)
        if raw:
            return resp.content
        return resp.json()

    @staticmethod
    def _error_text(resp) -> str:
        try:
            detail = resp.json().get("detail")
        except ValueError:
            return f"İstek başarısız ({resp.status_code})"
        if isinstance(detail, str):
            return detail
        if isinstance(detail, list):
            fields = {"email": "Geçerli bir e-posta adresi yaz.", "password": "Şifre 6 ile 72 karakter arasında olmalı.",
                      "full_name": "Ad soyadını yaz."}
            return " ".join(dict.fromkeys(
                fields.get(d.get("loc", [""])[-1]) or f"{d.get('loc', [''])[-1]}: {d.get('msg')}" for d in detail))
        if isinstance(detail, dict):
            missing = detail.get("missing")
            return detail.get("message", "Hata") + (f" ({', '.join(missing)})" if missing else "")
        return f"İstek başarısız ({resp.status_code})"

    def get(self, path, **params):
        return self._request("GET", path, params={k: v for k, v in params.items() if v is not None})

    def post(self, path, json=None, **kwargs):
        return self._request("POST", path, json=json, **kwargs)

    def patch(self, path, json=None, **params):
        return self._request("PATCH", path, json=json, params=params or None)

    def delete(self, path):
        return self._request("DELETE", path)

    def login(self, email: str, password: str) -> dict:
        data = self._request("POST", "/auth/login", data={"username": email, "password": password})
        self.token = data["access_token"]
        self.me = self.get("/users/me")
        return self.me

    def logout(self):
        self.token = None
        self.me = None

    def setup_status(self) -> dict:
        """{'needs_admin': True} ise veritabanında henüz salon yöneticisi yok (ilk kurulum)."""
        return self._request("GET", "/auth/setup", timeout=4)

    def register_member(self, full_name: str, email: str, password: str, phone: str | None = None) -> dict:
        """Kayıt ol: hesap her zaman üye olarak açılır; yönetici dilerse sonradan PT yapar."""
        return self._request("POST", "/auth/register", json={
            "full_name": full_name, "email": email, "password": password, "phone": phone,
        })

    def setup_admin(self, full_name: str, email: str, password: str, phone: str | None = None) -> dict:
        """İlk kurulum: hiç yönetici yokken ilk salon yöneticisi hesabını açar."""
        return self._request("POST", "/auth/setup-admin", json={
            "full_name": full_name, "email": email, "password": password, "phone": phone,
        })

    def file_url(self, photo_path: str) -> str:
        return f"{self.base_url}/uploads/{photo_path}"

    def download(self, url_or_path: str) -> bytes:
        path = url_or_path.replace(self.base_url, "")
        return self._request("GET", path, raw=True, timeout=30)

    def set_role(self, uid: int, role: str):
        """role: 'member' (üye) veya 'trainer' (personal trainer). Yalnızca yönetici."""
        return self.patch(f"/users/{uid}/role", {"role": role})

    def stats(self):
        return self.get("/overview/stats")

    def members(self):
        return self.get("/overview/members")

    def user(self, uid):
        return self.get(f"/users/{uid}")

    def trainers(self):
        return self.get("/users", role="trainer")

    def packages(self, include_inactive=False):
        return self.get("/packages", include_inactive=str(include_inactive).lower())

    def checkin_qr(self, token):
        return self.post("/checkin/qr", {"token": token})

    def checkin_face(self, jpeg: bytes):
        return self._request("POST", "/checkin/face", files={"frame": ("kare.jpg", jpeg, "image/jpeg")}, timeout=20)

    def enroll_face(self, uid: int, jpeg: bytes):
        return self._request("POST", f"/users/{uid}/face", files={"photo": ("yuz.jpg", jpeg, "image/jpeg")}, timeout=60)

    def upload_photo(self, uid: int | None, data: bytes, filename: str) -> dict:
        """Profil fotoğrafı yükler. uid=None: giriş yapan kişinin kendi fotoğrafı; aksi halde (yönetici) üyenin."""
        ext = filename.lower().rsplit(".", 1)[-1]
        mime = {"png": "image/png", "webp": "image/webp"}.get(ext, "image/jpeg")
        path = "/users/me/photo" if uid is None else f"/users/{uid}/photo"
        user = self._request("POST", path, files={"photo": (filename, data, mime)}, timeout=30)
        if uid is None or (self.me and uid == self.me.get("id")):
            self.me = user
        return user

    def delete_photo(self, uid: int | None = None) -> dict:
        user = self.delete("/users/me/photo" if uid is None else f"/users/{uid}/photo")
        if uid is None or (self.me and uid == self.me.get("id")):
            self.me = user
        return user

    def report_pdf(self, uid: int, month: str | None = None) -> bytes:
        params = {"user_id": uid}
        if month:
            params["month"] = month
        return self._request("GET", "/reports/monthly", params=params, raw=True, timeout=60)
