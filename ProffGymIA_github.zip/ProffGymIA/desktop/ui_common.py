"""Ortak görünüm: renkler, stil sayfası ve tekrar kullanılan bileşenler.

Renkler web paneliyle aynıdır (olimpik ağırlık plakaları) ve her zaman anlam taşır:
yeşil = aktif/izin, sarı = bitmek üzere, kırmızı = süresi dolmuş/red, mavi = işlem.
"""
from __future__ import annotations

from datetime import date, datetime

from PyQt6.QtCore import QObject, QRectF, QRunnable, Qt, QThreadPool, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QPixmap
from PyQt6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QAbstractItemView,
    QHeaderView,
    QVBoxLayout,
    QWidget,
)

C = {
    "bg": "#e3e4df",
    "surface": "#f6f6f2",
    "surface2": "#ecede7",
    "ink": "#1d2025",
    "ink2": "#565b62",
    "line": "#c9cbc4",
    "rail": "#1d2025",
    "blue": "#1f5fae",
    "red": "#c4303a",
    "yellow": "#c99a0e",
    "yellow_ink": "#7d5c00",
    "green": "#2a8551",
    "blue_soft": "#dbe6f4",
    "red_soft": "#f6dcdd",
    "yellow_soft": "#f5ebc9",
    "green_soft": "#d8ecdf",
}
DISPLAY_FONT = "Bahnschrift"
BODY_FONT = "Segoe UI"

LABELS = {
    "role": {"admin": "Salon yöneticisi", "trainer": "Personal trainer", "member": "Üye"},
    "goal": {"lose": "Kilo vermek", "maintain": "Kiloyu korumak", "gain": "Kilo almak"},
    "meal": {"breakfast": "Kahvaltı", "lunch": "Öğle", "dinner": "Akşam", "snack": "Ara öğün"},
    "method": {"qr": "QR", "face": "Yüz", "manual": "Elle"},
    "exercise": {"squat": "Squat", "biceps_curl": "Biceps curl", "shoulder_press": "Omuz press"},
}
MONTHS = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
DAYS = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]

STYLE = f"""
* {{ font-family: "{BODY_FONT}"; font-size: 10.5pt; color: {C['ink']}; }}
QMainWindow, QDialog {{ background: {C['bg']}; }}
#Rail {{ background: {C['rail']}; }}
#Rail QLabel {{ color: #d9dbd5; }}
#Wordmark {{ font-family: "{DISPLAY_FONT}"; font-size: 22pt; font-weight: 700; color: #f3f3ee; }}
#NavButton {{ text-align: left; padding: 10px 14px; border: none; border-left: 4px solid transparent;
              color: #d9dbd5; background: transparent; font-weight: 500; border-radius: 4px; }}
#NavButton:hover {{ background: rgba(255,255,255,0.06); }}
#NavButton:checked {{ background: rgba(255,255,255,0.10); border-left-color: {C['blue']}; color: white; }}
#LinkButton {{ border: none; background: transparent; color: #b9bcb6; text-decoration: underline; text-align: left; padding: 0; }}
QLabel#H1 {{ font-family: "{DISPLAY_FONT}"; font-size: 24pt; font-weight: 600; }}
QLabel#H2 {{ font-family: "{DISPLAY_FONT}"; font-size: 14pt; font-weight: 600; }}
QLabel#Muted {{ color: {C['ink2']}; }}
QFrame#Panel {{ background: {C['surface']}; border: 1px solid {C['line']}; border-radius: 8px; }}
QPushButton {{ background: {C['blue']}; color: white; border: 1px solid {C['blue']}; border-radius: 4px;
               padding: 8px 14px; font-weight: 600; }}
QPushButton:hover {{ background: #2a6cbf; }}
QPushButton:disabled {{ background: #9fb3cc; border-color: #9fb3cc; }}
QPushButton#Ghost {{ background: transparent; color: {C['ink']}; border: 1px solid {C['line']}; }}
QPushButton#Ghost:hover {{ background: {C['surface2']}; }}
QPushButton#Danger {{ background: {C['red']}; border-color: {C['red']}; }}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit, QTextEdit {{
    background: {C['surface']}; border: 1px solid {C['line']}; border-radius: 4px; padding: 6px 8px; }}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QDateEdit:focus {{ border: 2px solid {C['blue']}; }}
QTableWidget {{ background: {C['surface']}; border: none; gridline-color: {C['line']};
               selection-background-color: {C['blue_soft']}; selection-color: {C['ink']}; }}
QHeaderView::section {{ background: {C['surface']}; color: {C['ink2']}; border: none;
                        border-bottom: 1px solid {C['line']}; padding: 6px; font-weight: 600; }}
QTabWidget::pane {{ border: none; }}
QTabBar::tab {{ background: transparent; padding: 8px 16px; border-bottom: 3px solid transparent; color: {C['ink2']}; font-weight: 600; }}
QTabBar::tab:selected {{ color: {C['ink']}; border-bottom-color: {C['blue']}; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
"""


def fmt_date(value, with_year=False) -> str:
    if not value:
        return "—"
    d = date.fromisoformat(value[:10]) if isinstance(value, str) else value
    return f"{d.day} {MONTHS[d.month - 1]}" + (f" {d.year}" if with_year else "")


def fmt_time(value) -> str:
    if not value:
        return ""
    return datetime.fromisoformat(value).strftime("%H:%M")


def fmt_num(n, digits=1) -> str:
    if n is None:
        return "—"
    s = f"{n:,.{digits}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return s[: -(digits + 1)] if digits and s.endswith("," + "0" * digits) else s


def tl(n) -> str:
    return f"{fmt_num(n or 0, 0)} ₺"


def status_color(remaining: int, active: bool) -> str:
    if not active:
        return "red"
    return "yellow" if remaining <= 7 else "green"


def status_text(remaining: int, active: bool) -> str:
    if not active:
        return "Süresi dolmuş"
    return f"{remaining} gün kaldı" if remaining <= 7 else "Aktif"


def tr_upper(text: str) -> str:
    return text.replace("i", "İ").replace("ı", "I").upper()


def initials(name: str) -> str:
    return "".join(tr_upper(w[0]) for w in (name or "").split()[:2]) or "?"


def label(text: str = "", name: str | None = None, wrap: bool = False) -> QLabel:
    lbl = QLabel(text)
    if name:
        lbl.setObjectName(name)
    lbl.setWordWrap(wrap)
    return lbl


class Panel(QFrame):
    """Başlıklı beyaz kutu."""

    def __init__(self, title: str | None = None, parent=None):
        super().__init__(parent)
        self.setObjectName("Panel")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(18, 16, 18, 16)
        self.body.setSpacing(10)
        if title:
            self.header = QHBoxLayout()
            self.header.addWidget(label(title, "H2"))
            self.header.addStretch()
            self.body.addLayout(self.header)


class Chip(QLabel):
    def __init__(self, text: str, color: str = "blue"):
        super().__init__(f"● {text}")
        fg = C["yellow_ink"] if color == "yellow" else C[color]
        self.setStyleSheet(
            f"background:{C[color + '_soft']}; color:{fg}; border-radius:10px; padding:2px 10px; font-weight:600; font-size:9pt;"
        )
        self.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)


class Scoreboard(QFrame):
    """Üstte renkli şerit olan skor kutuları (web paneliyle aynı)."""

    def __init__(self, items: list[tuple[str, str, str]]):
        super().__init__()
        self.setObjectName("Panel")
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)
        for i, (value, caption, color) in enumerate(items):
            box = QFrame()
            border_left = f"border-left:1px solid {C['line']};" if i else ""
            box.setStyleSheet(f"QFrame{{border-top:5px solid {C.get(color, color)}; {border_left} background:transparent;}}")
            v = QVBoxLayout(box)
            v.setContentsMargins(18, 12, 18, 14)
            num = QLabel(value)
            num.setStyleSheet(f'font-family:"{DISPLAY_FONT}"; font-size:28pt; font-weight:600; border:none;')
            cap = QLabel(caption)
            cap.setStyleSheet(f"color:{C['ink2']}; border:none;")
            v.addWidget(num)
            v.addWidget(cap)
            row.addWidget(box, 1)


class PlateRing(QWidget):
    """Ağırlık plakası biçiminde kalan gün halkası. 30 gün = tam halka."""

    def __init__(self, size: int = 150):
        super().__init__()
        self.setFixedSize(size, size)
        self.days, self.active = 0, False

    def set_status(self, days: int, active: bool):
        self.days, self.active = days, active
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w = self.width()
        thick = w * 0.11
        rect = QRectF(thick / 2 + 2, thick / 2 + 2, w - thick - 4, w - thick - 4)
        pen = QPen(QColor(C["surface2"]), thick)
        pen.setCapStyle(Qt.PenCapStyle.FlatCap)
        p.setPen(pen)
        p.drawEllipse(rect)
        frac = min(self.days / 30, 1.0) if self.active else 0
        pen.setColor(QColor(C[status_color(self.days, self.active)]))
        p.setPen(pen)
        p.drawArc(rect, 90 * 16, int(-frac * 360 * 16))
        p.setPen(QColor(C["ink"]))
        f = QFont(DISPLAY_FONT, int(w * 0.2))
        f.setBold(True)
        p.setFont(f)
        p.drawText(QRectF(0, w * 0.22, w, w * 0.4), Qt.AlignmentFlag.AlignCenter, str(self.days))
        p.setPen(QColor(C["ink2"]))
        p.setFont(QFont(BODY_FONT, max(int(w * 0.055), 7)))
        p.drawText(QRectF(0, w * 0.58, w, w * 0.15), Qt.AlignmentFlag.AlignCenter, "gün kaldı")


class Avatar(QWidget):
    """Yuvarlak profil fotoğrafı. Fotoğraf yoksa ad soyadın baş harflerini gösterir."""

    def __init__(self, size: int = 40, dark: bool = False):
        super().__init__()
        self.setFixedSize(size, size)
        self._pix: QPixmap | None = None
        self._initials = "?"
        self._path: str | None = None
        self._bg, self._fg = ("#3a3e44", "#f3f3ee") if dark else (C["surface2"], C["ink2"])

    def set_user(self, user: dict, api=None):
        self._initials = initials(user.get("full_name", ""))
        self._path = user.get("photo_path")
        self._pix = None
        self.update()
        if self._path and api is not None:
            run_async(api.download, lambda data, p=self._path: self._loaded(p, data), None, api.file_url(self._path))

    def _loaded(self, path: str, data: bytes):
        try:
            if path != self._path:
                return
            pix = QPixmap()
            if pix.loadFromData(data):
                self._pix = pix
                self.update()
        except RuntimeError:
            pass

    def paintEvent(self, _):
        s = self.width()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        clip = QPainterPath()
        clip.addEllipse(QRectF(0, 0, s, s))
        p.setClipPath(clip)
        if self._pix is not None:
            scaled = self._pix.scaled(s, s, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap((s - scaled.width()) // 2, (s - scaled.height()) // 2, scaled)
            return
        p.fillRect(0, 0, s, s, QColor(self._bg))
        p.setPen(QColor(self._fg))
        f = QFont(DISPLAY_FONT, max(int(s * 0.28), 7))
        f.setBold(True)
        p.setFont(f)
        p.drawText(QRectF(0, 0, s, s), Qt.AlignmentFlag.AlignCenter, self._initials)


def make_table(headers: list[str], stretch_col: int = 0) -> QTableWidget:
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.verticalHeader().setVisible(False)
    t.setShowGrid(False)
    t.setAlternatingRowColors(False)
    t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    t.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    t.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
    h = t.horizontalHeader()
    h.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
    for i in range(len(headers)):
        h.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch if i == stretch_col else QHeaderView.ResizeMode.ResizeToContents)
    t.verticalHeader().setDefaultSectionSize(40)
    return t


def cell(text, align_right=False, color: str | None = None, bold=False, data=None) -> QTableWidgetItem:
    item = QTableWidgetItem(str(text))
    if align_right:
        item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    if color:
        item.setForeground(QColor(C["yellow_ink"] if color == "yellow" else C.get(color, color)))
    if bold:
        f = item.font()
        f.setBold(True)
        item.setFont(f)
    if data is not None:
        item.setData(Qt.ItemDataRole.UserRole, data)
    return item


def error(parent, message: str, title: str = "İşlem yapılamadı"):
    QMessageBox.warning(parent, title, str(message))


def info(parent, message: str, title: str = "FitAI"):
    QMessageBox.information(parent, title, message)


def confirm(parent, message: str, title: str = "Emin misin?") -> bool:
    return QMessageBox.question(parent, title, message) == QMessageBox.StandardButton.Yes


def clear_layout(layout):
    while layout.count():
        item = layout.takeAt(0)
        if item.widget():
            item.widget().deleteLater()
        elif item.layout():
            clear_layout(item.layout())


class _Signals(QObject):
    done = pyqtSignal(object)
    failed = pyqtSignal(str)


class Task(QRunnable):
    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn, self.args, self.kwargs = fn, args, kwargs
        self.signals = _Signals()

    def run(self):
        try:
            result = self.fn(*self.args, **self.kwargs)
        except Exception as exc:
            self.signals.failed.emit(str(exc))
        else:
            self.signals.done.emit(result)


_running: set[Task] = set()


def run_async(fn, on_done=None, on_error=None, *args, **kwargs) -> Task:
    """fn'i arka planda çalıştırır; sonuç ana iş parçacığında on_done/on_error'a gelir."""
    task = Task(fn, *args, **kwargs)
    task.setAutoDelete(False)
    _running.add(task)
    if on_done:
        task.signals.done.connect(on_done)
    if on_error:
        task.signals.failed.connect(on_error)
    task.signals.done.connect(lambda _r, t=task: _running.discard(t))
    task.signals.failed.connect(lambda _e, t=task: _running.discard(t))
    QThreadPool.globalInstance().start(task)
    return task
