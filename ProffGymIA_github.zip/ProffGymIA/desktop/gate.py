"""Turnike ekranı: yüz tanıma kamerası + QR okuyucu, büyük yeşil/kırmızı sonuç ekranı."""
from __future__ import annotations

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWidgets import (
    QCheckBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from api import Api, ApiError
from camera import CameraThread
from ui_common import C, DISPLAY_FONT, LABELS, Panel, cell, error, fmt_time, label, make_table, run_async

HOLD_MS = 4000
FACE_INTERVAL_MS = 1200


class ResultBoard(QFrame):
    """Turnikenin büyük durum ekranı. İzin = yeşil, red = kırmızı."""

    def __init__(self):
        super().__init__()
        self.setMinimumHeight(220)
        v = QVBoxLayout(self)
        v.setContentsMargins(28, 24, 28, 24)
        self.state = QLabel()
        self.detail = QLabel()
        self.detail.setWordWrap(True)
        v.addWidget(self.state)
        v.addWidget(self.detail)
        v.addStretch()
        self.idle()

    def _paint(self, bg: str, fg: str):
        self.setStyleSheet(f"ResultBoard{{background:{bg}; border-radius:8px; border:1px solid {C['line'] if bg == C['surface'] else bg};}}")
        self.state.setStyleSheet(f'color:{fg}; font-family:"{DISPLAY_FONT}"; font-size:38pt; font-weight:700;')
        self.detail.setStyleSheet(f"color:{fg}; font-size:13pt;")

    def idle(self):
        self._paint(C["surface"], C["ink"])
        self.state.setText("Bekleniyor")
        self.detail.setText("Kameraya bak veya uygulamadaki QR kodu okut.")

    def show_result(self, r: dict):
        granted = r["granted"]
        self._paint(C["green"] if granted else C["red"], "white")
        self.state.setText("Geçiş onaylandı" if granted else "Giriş reddedildi")
        parts = []
        if r.get("full_name"):
            parts.append(f"<b>{r['full_name']}</b>")
        parts.append(r["reason"])
        if granted and r.get("remaining_days") is not None and r.get("user_id"):
            parts.append(f"{r['remaining_days']} gün kaldı")
        if r.get("face_score") is not None:
            parts.append(f"benzerlik {r['face_score']:.2f}")
        self.detail.setText("  ·  ".join(parts))


class GatePage(QWidget):
    def __init__(self, api: Api):
        super().__init__()
        self.api = api
        self.camera: CameraThread | None = None
        self.busy = False
        self.holding = False

        root = QVBoxLayout(self)
        root.setContentsMargins(36, 30, 36, 30)
        root.setSpacing(16)
        root.addWidget(label("Turnike", "H1"))
        root.addWidget(label("Yüz tanıma açıkken kamera üyeleri kendiliğinden tanır. USB QR okuyucu da aşağıdaki alana yazar.", "Muted", wrap=True))

        body = QHBoxLayout()
        body.setSpacing(18)
        left = QVBoxLayout()
        self.video = QLabel("Kamera kapalı")
        self.video.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video.setMinimumSize(560, 315)
        self.video.setStyleSheet(f"background:{C['rail']}; color:#b9bcb6; border-radius:8px;")
        left.addWidget(self.video, 1)
        controls = QHBoxLayout()
        self.cam_btn = QPushButton("Kamerayı aç")
        self.cam_btn.clicked.connect(self.toggle_camera)
        self.cam_index = QSpinBox()
        self.cam_index.setRange(0, 5)
        self.cam_index.setPrefix("Kamera ")
        self.face_on = QCheckBox("Yüz tanıma")
        self.face_on.setChecked(True)
        controls.addWidget(self.cam_btn)
        controls.addWidget(self.cam_index)
        controls.addWidget(self.face_on)
        controls.addStretch()
        left.addLayout(controls)
        qr_row = QHBoxLayout()
        self.qr_input = QLineEdit()
        self.qr_input.setPlaceholderText("QR içeriği (okuyucu buraya yazar, Enter ile doğrular)")
        self.qr_input.returnPressed.connect(self.check_qr)
        qr_btn = QPushButton("Doğrula")
        qr_btn.clicked.connect(self.check_qr)
        qr_row.addWidget(self.qr_input, 1)
        qr_row.addWidget(qr_btn)
        left.addLayout(qr_row)
        body.addLayout(left, 3)

        right = QVBoxLayout()
        self.board = ResultBoard()
        right.addWidget(self.board)
        logs = Panel("Geçiş kayıtları")
        self.logs = make_table(["Saat", "Kişi", "Yöntem", "Sonuç"], stretch_col=1)
        logs.body.addWidget(self.logs)
        right.addWidget(logs, 1)
        body.addLayout(right, 2)
        root.addLayout(body, 1)

        self.face_timer = QTimer(self)
        self.face_timer.setInterval(FACE_INTERVAL_MS)
        self.face_timer.timeout.connect(self.try_face)
        self.hold_timer = QTimer(self)
        self.hold_timer.setSingleShot(True)
        self.hold_timer.timeout.connect(self.release)

    def refresh(self):
        self.load_logs()
        self.qr_input.setFocus()

    def load_logs(self):
        try:
            logs = self.api.get("/checkin/logs", limit=30)
        except ApiError:
            return
        self.logs.setRowCount(0)
        for lg in logs:
            r = self.logs.rowCount()
            self.logs.insertRow(r)
            self.logs.setItem(r, 0, cell(fmt_time(lg["created_at"])))
            self.logs.setItem(r, 1, cell(f"{lg['full_name'] or 'Tanınmayan'} — {lg['reason'] or ''}"))
            self.logs.setItem(r, 2, cell(LABELS["method"].get(lg["method"], lg["method"])))
            self.logs.setItem(r, 3, cell("Girdi" if lg["granted"] else "Reddedildi", color="green" if lg["granted"] else "red", bold=True))

    def toggle_camera(self):
        if self.camera:
            self.stop_camera()
            return
        self.camera = CameraThread(self.cam_index.value())
        self.camera.frame_ready.connect(self.show_frame)
        self.camera.failed.connect(self.camera_failed)
        self.camera.start()
        self.cam_btn.setText("Kamerayı kapat")
        self.face_timer.start()

    def stop_camera(self):
        self.face_timer.stop()
        if self.camera:
            self.camera.stop()
            self.camera = None
        self.cam_btn.setText("Kamerayı aç")
        self.video.clear()
        self.video.setText("Kamera kapalı")

    def camera_failed(self, msg):
        self.stop_camera()
        error(self, msg)

    def show_frame(self, img: QImage):
        self.video.setPixmap(QPixmap.fromImage(img).scaled(
            self.video.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def hideEvent(self, event):
        self.stop_camera()
        super().hideEvent(event)

    def try_face(self):
        if not self.camera or not self.face_on.isChecked() or self.busy or self.holding:
            return
        jpeg = self.camera.latest_jpeg(80)
        if not jpeg:
            return
        self.busy = True
        run_async(self.api.checkin_face, self.face_done, self.face_failed, jpeg)

    def face_done(self, r):
        self.busy = False
        if r.get("face_found"):
            self.present(r)

    def face_failed(self, msg):
        self.busy = False
        self.face_on.setChecked(False)
        error(self, f"{msg}\n\nYüz tanıma kapatıldı; QR ile devam edebilirsin.")

    def check_qr(self):
        token = self.qr_input.text().strip()
        if not token:
            return
        self.qr_input.clear()
        try:
            r = self.api.checkin_qr(token)
        except ApiError as exc:
            return error(self, exc)
        self.present(r)

    def present(self, r):
        self.board.show_result(r)
        self.holding = True
        self.hold_timer.start(HOLD_MS)
        self.load_logs()

    def release(self):
        self.holding = False
        self.board.idle()
        self.qr_input.setFocus()


class FaceEnrollDialog(QDialog):
    """Üyenin yüzünü turnike için kaydeder: kameradan çek veya dosyadan seç."""

    def __init__(self, api: Api, user: dict, parent=None):
        super().__init__(parent)
        self.api, self.user = api, user
        self.setWindowTitle(f"Yüz kaydı — {user['full_name']}")
        self.setMinimumSize(620, 520)
        v = QVBoxLayout(self)
        v.addWidget(label("Üye kameraya önden, aydınlık bir yerde baksın. Karede yalnızca bir yüz olmalı.", "Muted", wrap=True))
        self.video = QLabel("Kamera açılıyor…")
        self.video.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video.setMinimumSize(560, 315)
        self.video.setStyleSheet(f"background:{C['rail']}; color:#b9bcb6; border-radius:8px;")
        v.addWidget(self.video, 1)
        self.status = label("", wrap=True)
        v.addWidget(self.status)
        row = QHBoxLayout()
        self.capture_btn = QPushButton("Fotoğraf çek ve kaydet")
        self.capture_btn.clicked.connect(self.capture)
        from_file = QPushButton("Dosyadan seç")
        from_file.setObjectName("Ghost")
        from_file.clicked.connect(self.from_file)
        close = QPushButton("Kapat")
        close.setObjectName("Ghost")
        close.clicked.connect(self.reject)
        row.addWidget(self.capture_btn)
        row.addWidget(from_file)
        row.addStretch()
        row.addWidget(close)
        v.addLayout(row)
        self.camera = CameraThread(0)
        self.camera.frame_ready.connect(lambda img: self.video.setPixmap(QPixmap.fromImage(img).scaled(
            self.video.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)))
        self.camera.failed.connect(lambda m: self.status.setText(m + " Dosyadan seçebilirsin."))
        self.camera.start()

    def capture(self):
        jpeg = self.camera.latest_jpeg(92)
        if not jpeg:
            return self.status.setText("Henüz kamera görüntüsü yok.")
        self.send(jpeg)

    def from_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Üye fotoğrafı", "", "Görseller (*.jpg *.jpeg *.png)")
        if path:
            with open(path, "rb") as fh:
                self.send(fh.read())

    def send(self, data: bytes):
        self.capture_btn.setEnabled(False)
        self.status.setText("Yüz işleniyor… (ilk seferde model indirildiği için biraz sürebilir)")

        def done(r):
            self.capture_btn.setEnabled(True)
            self.status.setText(f"<b style='color:{C['green']}'>Yüz kaydedildi.</b> Üye artık turnikeden yüzüyle geçebilir.")

        def failed(msg):
            self.capture_btn.setEnabled(True)
            self.status.setText(f"<b style='color:{C['red']}'>{msg}</b>")

        run_async(self.api.enroll_face, done, failed, self.user["id"], data)

    def done(self, result):
        self.camera.stop()
        super().done(result)
