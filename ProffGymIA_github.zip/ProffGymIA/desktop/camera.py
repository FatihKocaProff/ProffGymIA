"""Kamera iş parçacıkları. Görüntü yakalama arayüzü dondurmasın diye ayrı thread'de çalışır."""
from __future__ import annotations

import sys
import threading
import time

from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtGui import QImage


def to_qimage(frame_bgr) -> QImage:
    import cv2

    rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    h, w, _ = rgb.shape
    return QImage(rgb.data, w, h, 3 * w, QImage.Format.Format_RGB888).copy()


def open_camera(index: int):
    import cv2

    cap = cv2.VideoCapture(index, cv2.CAP_DSHOW) if sys.platform == "win32" else cv2.VideoCapture(index)
    if not cap.isOpened():
        cap = cv2.VideoCapture(index)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 960)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 540)
    return cap


class CameraThread(QThread):
    frame_ready = pyqtSignal(QImage)
    failed = pyqtSignal(str)

    def __init__(self, index: int = 0, mirror: bool = True, parent=None):
        super().__init__(parent)
        self.index = index
        self.mirror = mirror
        self._running = False
        self._lock = threading.Lock()
        self._latest = None

    def latest_jpeg(self, quality: int = 85) -> bytes | None:
        """Son karenin JPEG hali (sunucuya göndermek için)."""
        import cv2

        with self._lock:
            frame = None if self._latest is None else self._latest.copy()
        if frame is None:
            return None
        ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, quality])
        return buf.tobytes() if ok else None

    def process(self, frame):
        """Alt sınıflar kareyi işleyip (çizim yapıp) geri döndürebilir."""
        return frame

    def run(self):
        import cv2

        cap = open_camera(self.index)
        if not cap.isOpened():
            self.failed.emit("Kamera açılamadı. Başka bir uygulama kullanıyor olabilir ya da kamera numarasını değiştir.")
            return
        self._running = True
        misses = 0
        try:
            while self._running:
                ok, frame = cap.read()
                if not ok:
                    misses += 1
                    if misses > 30:
                        self.failed.emit("Kameradan görüntü alınamıyor.")
                        break
                    time.sleep(0.03)
                    continue
                misses = 0
                if self.mirror:
                    frame = cv2.flip(frame, 1)
                with self._lock:
                    self._latest = frame
                shown = self.process(frame.copy())
                self.frame_ready.emit(to_qimage(shown))
        finally:
            cap.release()

    def stop(self):
        self._running = False
        self.wait(2000)


class FormCoachThread(CameraThread):
    """Kamera + MediaPipe + form kuralları. Her tekrar ve uyarı sinyal olarak gelir."""

    feedback = pyqtSignal(object)
    status = pyqtSignal(str)

    def __init__(self, exercise: str, index: int = 0, speak: bool = True, parent=None):
        super().__init__(index, mirror=True, parent=parent)
        self.exercise = exercise
        self.speak = speak
        self.analyzer = None
        self.pose = None
        self.speaker = None
        self.started_at = None
        self._flash = None
        self._flash_until = 0.0

    def run(self):
        from form_coach.engine import PoseEstimator, Speaker
        from form_coach.logic import EXERCISES

        self.status.emit("Vücut analizi modeli yükleniyor…")
        try:
            self.pose = PoseEstimator()
        except Exception as exc:
            self.failed.emit(str(exc))
            return
        self.analyzer = EXERCISES[self.exercise]()
        self.speaker = Speaker(enabled=self.speak)
        self.started_at = time.monotonic()
        self.status.emit("Hazır. Harekete başla.")
        try:
            super().run()
        finally:
            self.pose.close()

    def process(self, frame):
        from form_coach.engine import draw_overlay
        from form_coach.logic import CUE_VISIBILITY

        lm = self.pose.process(frame)
        fb = self.analyzer.update(lm) if lm else None
        if lm is None:
            self.speaker.say(CUE_VISIBILITY)
        elif fb:
            self.speaker.say(fb.cue)
            if fb.rep_done:
                self._flash, self._flash_until = fb.rep_done, time.monotonic() + 0.6
            self.feedback.emit(fb)
        if time.monotonic() > self._flash_until:
            self._flash = None
        return draw_overlay(frame, lm, fb, self.analyzer.title, self._flash)

    def summary(self) -> dict:
        if not self.analyzer:
            return {"reps": 0, "good_reps": 0, "issues": {}, "exercise": self.exercise, "score": 0}
        s = self.analyzer.summary()
        s["duration_seconds"] = int(time.monotonic() - (self.started_at or time.monotonic()))
        return s
