"""Sentetik iskeletlerle form analizi kurallarının testi (kamera gerekmez)."""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from form_coach import logic as L


def rot(v, deg):
    r = math.radians(deg)
    return (v[0] * math.cos(r) - v[1] * math.sin(r), v[0] * math.sin(r) + v[1] * math.cos(r))


def unit(v):
    n = math.hypot(*v)
    return (v[0] / n, v[1] / n)


def squat_pose(knee_deg, lean_deg=10, knees_in=False):
    """Yandan squat iskeleti: diz açısı ve gövde eğimi verilir."""
    ankle = (0.5, 0.9)
    knee = (0.56, 0.72)
    shin = unit((ankle[0] - knee[0], ankle[1] - knee[1]))
    thigh = rot(shin, knee_deg)
    hip = (knee[0] + 0.2 * thigh[0], knee[1] + 0.2 * thigh[1])
    r = math.radians(lean_deg)
    shoulder = (hip[0] + 0.25 * math.sin(r), hip[1] - 0.25 * math.cos(r))
    lm = {}
    for side, dx in (("left", 0.0), ("right", 0.002)):
        s = L.SIDES[side]
        lm[s["ankle"]] = L.Point(ankle[0] + dx, ankle[1], 0.9)
        lm[s["knee"]] = L.Point(knee[0] + dx, knee[1], 0.9)
        lm[s["hip"]] = L.Point(hip[0] + dx, hip[1], 0.9)
        lm[s["shoulder"]] = L.Point(shoulder[0] + dx, shoulder[1], 0.9)
    if knees_in:
        lm[L.L_ANKLE].x, lm[L.R_ANKLE].x = 0.40, 0.60
        lm[L.L_KNEE].x, lm[L.R_KNEE].x = 0.47, 0.53
    return lm


def run(analyzer, frames):
    out = []
    for lm in frames:
        out.append(analyzer.update(lm))
    return out


def rep(lo, hi=175, step=5, **kw):
    down = list(range(hi, lo - 1, -step))
    return [squat_pose(a, **kw) for a in down + down[::-1]]


def test_angle_basic():
    assert round(L.angle(L.Point(0, 0), L.Point(1, 0), L.Point(1, 1))) == 90
    assert round(L.angle(L.Point(0, 0), L.Point(1, 0), L.Point(2, 0))) == 180


def test_synthetic_pose_has_requested_knee_angle():
    lm = squat_pose(95)
    assert abs(L.angle(lm[L.L_HIP], lm[L.L_KNEE], lm[L.L_ANKLE]) - 95) < 0.5


def test_squat_good_reps_counted():
    a = L.SquatAnalyzer(smoothing=1.0)
    fbs = run(a, rep(85) + rep(85))
    assert a.reps == 2 and a.good_reps == 2
    assert [f.rep_done for f in fbs if f.rep_done] == ["good", "good"]


def test_squat_shallow_rep_is_flagged():
    a = L.SquatAnalyzer(smoothing=1.0)
    fbs = run(a, rep(120))
    assert a.reps == 1 and a.good_reps == 0
    assert a.issues[L.CUE_DEPTH] == 1
    assert any(f.cue == L.CUE_DEPTH for f in fbs)


def test_squat_back_lean_warning_spoken_once():
    a = L.SquatAnalyzer(smoothing=1.0)
    fbs = run(a, rep(85, lean_deg=65))
    assert [f.cue for f in fbs].count(L.CUE_BACK) == 1
    assert a.summary()["issues"] == {L.CUE_BACK: 1}


def test_squat_knees_caving_front_view():
    a = L.SquatAnalyzer(smoothing=1.0)
    run(a, rep(85, knees_in=True))
    assert a.issues[L.CUE_KNEES_IN] == 1


def test_missing_body_asks_for_visibility():
    a = L.SquatAnalyzer()
    fb = a.update({L.L_HIP: L.Point(0.5, 0.5, 0.2)})
    assert fb.cue == L.CUE_VISIBILITY and a.reps == 0


def curl_pose(elbow_deg, drift_deg=5):
    sh, hip = (0.5, 0.3), (0.5, 0.6)
    arm = rot((0, 1), -drift_deg)
    el = (sh[0] + 0.15 * arm[0], sh[1] + 0.15 * arm[1])
    fore = rot((-arm[0], -arm[1]), -elbow_deg)
    wr = (el[0] + 0.14 * fore[0], el[1] + 0.14 * fore[1])
    s = L.SIDES["left"]
    return {s["shoulder"]: L.Point(*sh), s["hip"]: L.Point(*hip), s["elbow"]: L.Point(*el), s["wrist"]: L.Point(*wr)}


def test_curl_counts_and_detects_elbow_drift():
    a = L.BicepsCurlAnalyzer(smoothing=1.0)
    good = [curl_pose(x) for x in list(range(170, 39, -10)) + list(range(40, 171, 10))]
    bad = [curl_pose(x, drift_deg=45) for x in list(range(170, 39, -10)) + list(range(40, 171, 10))]
    run(a, good + bad)
    assert abs(L.angle(*[curl_pose(60)[i] for i in (L.L_SHOULDER, L.L_ELBOW, L.L_WRIST)]) - 60) < 0.5
    assert a.reps == 2 and a.good_reps == 1 and a.issues[L.CUE_ELBOW_DRIFT] == 1


def test_curl_half_rep():
    a = L.BicepsCurlAnalyzer(smoothing=1.0)
    run(a, [curl_pose(x) for x in list(range(170, 89, -10)) + list(range(90, 171, 10))])
    assert a.reps == 1 and a.issues[L.CUE_FULL_CURL] == 1


def press_pose(elbow_deg):
    """Yandan omuz press: üst kol yataya yakın, ön kol yukarı."""
    sh, hip = (0.5, 0.4), (0.5, 0.7)
    up_arm = rot((1, 0), -(elbow_deg - 90) / 2)
    el = (sh[0] + 0.13 * up_arm[0], sh[1] + 0.13 * up_arm[1])
    fore = rot((-up_arm[0], -up_arm[1]), elbow_deg)
    wr = (el[0] + 0.13 * fore[0], el[1] + 0.13 * fore[1])
    s = L.SIDES["right"]
    return {s["shoulder"]: L.Point(*sh), s["hip"]: L.Point(*hip), s["elbow"]: L.Point(*el), s["wrist"]: L.Point(*wr)}


def test_shoulder_press_lockout():
    a = L.ShoulderPressAnalyzer(smoothing=1.0)
    p = press_pose(80)
    assert p[L.R_WRIST].y < p[L.R_SHOULDER].y, "bilek omuzdan yukarıda olmalı"
    full = [press_pose(x) for x in list(range(80, 171, 10)) + list(range(170, 79, -10))]
    half = [press_pose(x) for x in list(range(80, 141, 10)) + list(range(140, 79, -10))]
    run(a, full + half)
    assert a.reps == 2 and a.good_reps == 1 and a.issues[L.CUE_LOCKOUT] == 1


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("OK", name)
