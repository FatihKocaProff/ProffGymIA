"""Bağımsız form analizi (2. aşama scripti). Masaüstü paneli olmadan da çalışır.

Kullanım:
    python -m form_coach squat
    python -m form_coach biceps_curl --camera 1
    python -m form_coach shoulder_press --sessiz

Tuşlar:  Q / ESC = çık,  R = sayacı sıfırla
"""
import argparse
import sys
import time

from .engine import PoseEstimator, Speaker, ascii_fold, draw_overlay
from .logic import CAMERA_TIPS, EXERCISES


def main() -> int:
    parser = argparse.ArgumentParser(description="FitAI canlı form analizi")
    parser.add_argument("exercise", choices=list(EXERCISES), nargs="?", default="squat")
    parser.add_argument("--camera", type=int, default=0, help="Kamera numarası (varsayılan 0)")
    parser.add_argument("--sessiz", action="store_true", help="Sesli uyarıyı kapat")
    args = parser.parse_args()

    import cv2

    cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        print("Kamera açılamadı. --camera 1 ile başka bir kamera dene.")
        return 1

    print("Model yükleniyor...")
    pose = PoseEstimator()
    analyzer = EXERCISES[args.exercise]()
    speaker = Speaker(enabled=not args.sessiz)
    print(CAMERA_TIPS[args.exercise])
    print("Q: çık · R: sıfırla")

    flash, flash_until = None, 0.0
    started = time.monotonic()
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame = cv2.flip(frame, 1)
            lm = pose.process(frame)
            fb = analyzer.update(lm) if lm else None
            if lm is None:
                speaker.say("Tüm vücudun kamerada görünsün")
            elif fb:
                speaker.say(fb.cue)
                if fb.rep_done:
                    flash, flash_until = fb.rep_done, time.monotonic() + 0.6
                    print(f"Tekrar {fb.reps}: {'DOĞRU' if fb.rep_done == 'good' else ', '.join(fb.rep_issues)}")
            if time.monotonic() > flash_until:
                flash = None
            draw_overlay(frame, lm, fb, analyzer.title, flash)
            if fb and fb.cue:
                cv2.putText(frame, ascii_fold(fb.cue), (16, frame.shape[0] - 24), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (58, 48, 196), 2, cv2.LINE_AA)
            cv2.imshow("FitAI Form Analizi", frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                break
            if key == ord("r"):
                analyzer = EXERCISES[args.exercise]()
    finally:
        cap.release()
        cv2.destroyAllWindows()
        pose.close()

    s = analyzer.summary()
    print(f"\nÖzet: {s['reps']} tekrar, {s['good_reps']} doğru (skor %{s['score']:.0f}), "
          f"süre {int(time.monotonic() - started)} sn")
    for issue, count in s["issues"].items():
        print(f"  - {issue}: {count}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
