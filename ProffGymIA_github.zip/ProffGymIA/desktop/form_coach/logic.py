"""Form analizi mantığı: eklem açıları, tekrar sayma ve form hataları.

Kameradan ve MediaPipe'tan bağımsızdır; yalnızca vücut noktalarının (landmark)
koordinatlarıyla çalışır. Bu yüzden birim testle doğrulanabilir ve aynı kurallar
mobil uygulamada (lib/form/form_logic.dart) birebir kullanılır.

Koordinatlar MediaPipe / ML Kit Pose ile aynıdır: 33 nokta, x sağa, y AŞAĞI artar,
değerler 0-1 (normalize). `vis` noktanın görünür olma olasılığıdır.
"""
from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass, field

NOSE = 0
L_SHOULDER, R_SHOULDER = 11, 12
L_ELBOW, R_ELBOW = 13, 14
L_WRIST, R_WRIST = 15, 16
L_HIP, R_HIP = 23, 24
L_KNEE, R_KNEE = 25, 26
L_ANKLE, R_ANKLE = 27, 28

SIDES = {
    "left": dict(shoulder=L_SHOULDER, elbow=L_ELBOW, wrist=L_WRIST, hip=L_HIP, knee=L_KNEE, ankle=L_ANKLE),
    "right": dict(shoulder=R_SHOULDER, elbow=R_ELBOW, wrist=R_WRIST, hip=R_HIP, knee=R_KNEE, ankle=R_ANKLE),
}

MIN_VISIBILITY = 0.5

CUE_VISIBILITY = "Tüm vücudun kamerada görünsün"
CUE_DEPTH = "Daha derine in"
CUE_BACK = "Sırtını dik tut"
CUE_KNEES_IN = "Dizlerini dışa it"
CUE_ELBOW_DRIFT = "Dirseğini gövdene sabitle"
CUE_SWING = "Gövdeni sallama"
CUE_FULL_CURL = "Ağırlığı tam yukarı çek"
CUE_FULL_EXTEND = "Kolunu tam aç"
CUE_LOCKOUT = "Kollarını yukarıda tam uzat"
CUE_ARCH = "Belini aşırı bükme"
CUE_GOOD = "Harika"


@dataclass
class Point:
    x: float
    y: float
    vis: float = 1.0


Landmarks = dict[int, Point]


def angle(a: Point, b: Point, c: Point) -> float:
    """b noktasındaki açı (derece, 0-180). Örn. kalça-diz-ayak bileği = diz açısı."""
    ab = (a.x - b.x, a.y - b.y)
    cb = (c.x - b.x, c.y - b.y)
    dot = ab[0] * cb[0] + ab[1] * cb[1]
    norm = math.hypot(*ab) * math.hypot(*cb)
    if norm == 0:
        return 0.0
    return math.degrees(math.acos(max(-1.0, min(1.0, dot / norm))))


def lean_from_vertical(top: Point, bottom: Point) -> float:
    """İki noktayı birleştiren çizginin dikeyle yaptığı açı (gövde eğimi için)."""
    dx, dy = top.x - bottom.x, bottom.y - top.y
    return abs(math.degrees(math.atan2(dx, dy))) if (dx or dy) else 0.0


def visible(lm: Landmarks, *ids: int) -> bool:
    return all(i in lm and lm[i].vis >= MIN_VISIBILITY for i in ids)


def best_side(lm: Landmarks, keys: tuple[str, ...]) -> dict | None:
    """Kameraya dönük (daha iyi görünen) vücut yarısını seçer."""
    scored = []
    for side in SIDES.values():
        ids = [side[k] for k in keys]
        if visible(lm, *ids):
            scored.append((sum(lm[i].vis for i in ids), side))
    return max(scored, key=lambda s: s[0])[1] if scored else None


@dataclass
class Feedback:
    """Her karede ekrana/sese verilen sonuç."""

    reps: int
    good_reps: int
    phase: str
    angle: float | None
    cue: str | None = None
    rep_done: str | None = None
    rep_issues: list[str] = field(default_factory=list)


class ExerciseAnalyzer:
    name = ""
    title = ""
    keys: tuple[str, ...] = ()

    def __init__(self, smoothing: float = 0.5):
        self.smoothing = smoothing
        self.reps = 0
        self.good_reps = 0
        self.issues: Counter[str] = Counter()
        self.phase = "bekleniyor"
        self._smooth: dict[str, float] = {}
        self._rep_issues: set[str] = set()
        self._rep_min = 999.0
        self._rep_max = -1.0
        self._started = False

    def _ema(self, key: str, value: float) -> float:
        prev = self._smooth.get(key)
        value = value if prev is None else prev + self.smoothing * (value - prev)
        self._smooth[key] = value
        return value

    def _flag(self, cue: str) -> str | None:
        """Bu tekrarda ilk kez görülen hatayı döndürür (sesli uyarı için)."""
        if cue in self._rep_issues:
            return None
        self._rep_issues.add(cue)
        return cue

    def _finish_rep(self) -> Feedback:
        issues = sorted(self._rep_issues)
        self.reps += 1
        if issues:
            self.issues.update(issues)
            result = "bad"
        else:
            self.good_reps += 1
            result = "good"
        self._rep_issues = set()
        self._rep_min, self._rep_max = 999.0, -1.0
        return Feedback(self.reps, self.good_reps, self.phase, None, None, result, issues)

    def summary(self) -> dict:
        return {
            "exercise": self.name,
            "reps": self.reps,
            "good_reps": self.good_reps,
            "score": round(self.good_reps / self.reps * 100, 1) if self.reps else 0.0,
            "issues": dict(self.issues.most_common()),
        }

    def update(self, lm: Landmarks) -> Feedback:
        raise NotImplementedError


class SquatAnalyzer(ExerciseAnalyzer):
    """Diz açısı 160°'nin üstü = ayakta, 100°'nin altı = yeterli derinlik.

    Yandan çekimde gövde eğimi, önden çekimde dizlerin içe çökmesi kontrol edilir.
    """

    name, title = "squat", "Squat"
    keys = ("shoulder", "hip", "knee", "ankle")
    UP, DOWN, STARTED = 160, 100, 140
    MAX_LEAN = 50

    def update(self, lm: Landmarks) -> Feedback:
        side = best_side(lm, self.keys)
        if not side:
            return Feedback(self.reps, self.good_reps, self.phase, None, CUE_VISIBILITY)
        knee = self._ema("knee", angle(lm[side["hip"]], lm[side["knee"]], lm[side["ankle"]]))
        lean = self._ema("lean", lean_from_vertical(lm[side["shoulder"]], lm[side["hip"]]))
        cue = None

        if self.phase == "bekleniyor" and knee >= self.UP:
            self.phase = "yukarı"
        if self.phase == "yukarı" and knee < self.STARTED:
            self.phase = "aşağı"
        if self.phase == "aşağı":
            self._rep_min = min(self._rep_min, knee)
            if knee < 125 and lean > self.MAX_LEAN:
                cue = self._flag(CUE_BACK) or cue
            if knee < 125 and visible(lm, L_KNEE, R_KNEE, L_ANKLE, R_ANKLE):
                knee_w = abs(lm[L_KNEE].x - lm[R_KNEE].x)
                ankle_w = abs(lm[L_ANKLE].x - lm[R_ANKLE].x)
                body_h = abs(lm[side["shoulder"]].y - lm[side["ankle"]].y)
                if body_h > 0 and ankle_w > body_h * 0.15 and knee_w < ankle_w * 0.75:
                    cue = self._flag(CUE_KNEES_IN) or cue
            if knee >= self.UP:
                self.phase = "yukarı"
                if self._rep_min > self.DOWN:
                    self._rep_issues.add(CUE_DEPTH)
                fb = self._finish_rep()
                fb.angle = knee
                fb.cue = CUE_DEPTH if CUE_DEPTH in fb.rep_issues else (CUE_GOOD if fb.rep_done == "good" else None)
                return fb
        return Feedback(self.reps, self.good_reps, self.phase, knee, cue)


class BicepsCurlAnalyzer(ExerciseAnalyzer):
    """Dirsek açısı 150°'nin üstü = kol açık, 50°'nin altı = tam kasılma."""

    name, title = "biceps_curl", "Biceps curl"
    keys = ("shoulder", "elbow", "wrist", "hip")
    OPEN, CLOSED, STARTED = 150, 50, 120
    MAX_DRIFT, MAX_SWING = 30, 15

    def __init__(self, smoothing: float = 0.5):
        super().__init__(smoothing)
        self._lean_start: float | None = None

    def update(self, lm: Landmarks) -> Feedback:
        side = best_side(lm, self.keys)
        if not side:
            return Feedback(self.reps, self.good_reps, self.phase, None, CUE_VISIBILITY)
        sh, el, wr, hip = (lm[side[k]] for k in ("shoulder", "elbow", "wrist", "hip"))
        elbow = self._ema("elbow", angle(sh, el, wr))
        drift = self._ema("drift", angle(hip, sh, el))
        lean = self._ema("lean", lean_from_vertical(sh, hip))
        cue = None

        if self.phase == "bekleniyor" and elbow >= self.OPEN:
            self.phase = "aşağı"
            self._lean_start = lean
        if self.phase == "aşağı" and elbow < self.STARTED:
            self.phase = "yukarı"
            self._lean_start = self._lean_start if self._lean_start is not None else lean
        if self.phase == "yukarı":
            self._rep_min = min(self._rep_min, elbow)
            if drift > self.MAX_DRIFT:
                cue = self._flag(CUE_ELBOW_DRIFT) or cue
            if self._lean_start is not None and abs(lean - self._lean_start) > self.MAX_SWING:
                cue = self._flag(CUE_SWING) or cue
            if elbow >= self.OPEN:
                self.phase = "aşağı"
                if self._rep_min > self.CLOSED + 10:
                    self._rep_issues.add(CUE_FULL_CURL)
                self._lean_start = lean
                fb = self._finish_rep()
                fb.angle = elbow
                fb.cue = CUE_FULL_CURL if CUE_FULL_CURL in fb.rep_issues else (CUE_GOOD if fb.rep_done == "good" else None)
                return fb
        return Feedback(self.reps, self.good_reps, self.phase, elbow, cue)


class ShoulderPressAnalyzer(ExerciseAnalyzer):
    """Yandan çekim. Eller omuz hizasında (dirsek < 100°) başlar, yukarıda dirsek > 155° olmalı."""

    name, title = "shoulder_press", "Omuz press"
    keys = ("shoulder", "elbow", "wrist", "hip")
    BOTTOM, LOCKOUT, STARTED = 100, 155, 130
    MAX_ARCH = 20

    def update(self, lm: Landmarks) -> Feedback:
        side = best_side(lm, self.keys)
        if not side:
            return Feedback(self.reps, self.good_reps, self.phase, None, CUE_VISIBILITY)
        sh, el, wr, hip = (lm[side[k]] for k in ("shoulder", "elbow", "wrist", "hip"))
        elbow = self._ema("elbow", angle(sh, el, wr))
        lean = self._ema("lean", lean_from_vertical(sh, hip))
        wrist_above = wr.y < sh.y
        cue = None

        if self.phase == "bekleniyor" and elbow < self.BOTTOM and wrist_above:
            self.phase = "aşağı"
        if self.phase == "aşağı" and elbow > self.STARTED and wrist_above:
            self.phase = "yukarı"
        if self.phase == "yukarı":
            self._rep_max = max(self._rep_max, elbow)
            if lean > self.MAX_ARCH:
                cue = self._flag(CUE_ARCH) or cue
            if elbow < self.BOTTOM:
                self.phase = "aşağı"
                if self._rep_max < self.LOCKOUT:
                    self._rep_issues.add(CUE_LOCKOUT)
                fb = self._finish_rep()
                fb.angle = elbow
                fb.cue = CUE_LOCKOUT if CUE_LOCKOUT in fb.rep_issues else (CUE_GOOD if fb.rep_done == "good" else None)
                return fb
        return Feedback(self.reps, self.good_reps, self.phase, elbow, cue)


EXERCISES: dict[str, type[ExerciseAnalyzer]] = {
    SquatAnalyzer.name: SquatAnalyzer,
    BicepsCurlAnalyzer.name: BicepsCurlAnalyzer,
    ShoulderPressAnalyzer.name: ShoulderPressAnalyzer,
}

CAMERA_TIPS = {
    "squat": "Kameraya YANDAN dur; baştan ayağa tüm vücudun görünsün.",
    "biceps_curl": "Kameraya YANDAN dur; çalışan kolun kameraya baksın.",
    "shoulder_press": "Kameraya YANDAN dur; kolların ve kalçan görünsün.",
}
