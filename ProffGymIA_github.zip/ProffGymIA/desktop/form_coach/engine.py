"""Kamera görüntüsünden vücut noktalarını çıkarır (MediaPipe Pose Landmarker),
iskeleti çizer ve uyarıları sesli okur.

MediaPipe'ın yeni "Tasks" API'si kullanılır (eski mp.solutions yeni sürümlerde kaldırıldı).
Model dosyası (~5 MB) ilk çalıştırmada otomatik indirilir.
"""
from __future__ import annotations

import queue
import threading
import time
import urllib.request
from pathlib import Path

from .logic import Feedback, Landmarks, Point

MODEL_URL = "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task"
MODEL_PATH = Path(__file__).resolve().parent / "models" / "pose_landmarker_lite.task"

BONES = [(11, 12), (11, 13), (13, 15), (12, 14), (14, 16), (11, 23), (12, 24), (23, 24),
         (23, 25), (25, 27), (24, 26), (26, 28), (27, 31), (28, 32)]

GREEN = (81, 133, 42)
RED = (58, 48, 196)
WHITE = (240, 240, 240)
BLUE = (174, 95, 31)


def ensure_model() -> Path:
    if MODEL_PATH.exists() and MODEL_PATH.stat().st_size > 1_000_000:
        return MODEL_PATH
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = MODEL_PATH.with_suffix(".part")
    try:
        urllib.request.urlretrieve(MODEL_URL, tmp)
    except OSError as exc:
        raise RuntimeError(
            f"Vücut analizi modeli indirilemedi: {exc}\nİnternet bağlantısını kontrol et veya dosyayı elle "
            f"indirip şuraya koy: {MODEL_PATH}\n{MODEL_URL}"
        ) from exc
    tmp.replace(MODEL_PATH)
    return MODEL_PATH


class PoseEstimator:
    """Kareleri sırayla işler (VIDEO modu: kareler arası takip daha akıcıdır)."""

    def __init__(self):
        import mediapipe as mp
        from mediapipe.tasks import python as mp_tasks
        from mediapipe.tasks.python import vision

        self._mp = mp
        options = vision.PoseLandmarkerOptions(
            base_options=mp_tasks.BaseOptions(model_asset_buffer=ensure_model().read_bytes()),
            running_mode=vision.RunningMode.VIDEO,
            num_poses=1,
            min_pose_detection_confidence=0.5,
            min_pose_presence_confidence=0.5,
            min_tracking_confidence=0.5,
        )
        self._landmarker = vision.PoseLandmarker.create_from_options(options)
        self._t0 = time.monotonic()
        self._last_ts = -1

    def process(self, frame_bgr) -> Landmarks | None:
        import cv2

        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        image = self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb)
        ts = int((time.monotonic() - self._t0) * 1000)
        if ts <= self._last_ts:
            ts = self._last_ts + 1
        self._last_ts = ts
        result = self._landmarker.detect_for_video(image, ts)
        if not result.pose_landmarks:
            return None
        return {
            i: Point(p.x, p.y, p.visibility if p.visibility is not None else 1.0)
            for i, p in enumerate(result.pose_landmarks[0])
        }

    def close(self):
        self._landmarker.close()


def draw_overlay(frame, lm: Landmarks | None, fb: Feedback | None, title: str, flash: str | None = None):
    """İskeleti ve tekrar sayacını kareye çizer. flash: 'good'/'bad' tekrar bittiğinde renk."""
    import cv2

    h, w = frame.shape[:2]
    color = GREEN if flash == "good" else RED if flash == "bad" else WHITE
    if lm:
        for a, b in BONES:
            if a in lm and b in lm and lm[a].vis > 0.5 and lm[b].vis > 0.5:
                cv2.line(frame, (int(lm[a].x * w), int(lm[a].y * h)), (int(lm[b].x * w), int(lm[b].y * h)), color, 3, cv2.LINE_AA)
        for i, p in lm.items():
            if i >= 11 and p.vis > 0.5:
                cv2.circle(frame, (int(p.x * w), int(p.y * h)), 5, BLUE, -1, cv2.LINE_AA)

    cv2.rectangle(frame, (0, 0), (w, 64), (37, 32, 29), -1)
    if fb:
        cv2.putText(frame, f"{fb.reps}", (16, 50), cv2.FONT_HERSHEY_DUPLEX, 1.6, WHITE, 2, cv2.LINE_AA)
        cv2.putText(frame, f"dogru {fb.good_reps}", (90, 46), cv2.FONT_HERSHEY_SIMPLEX, 0.8, GREEN, 2, cv2.LINE_AA)
        if fb.angle is not None:
            cv2.putText(frame, f"{fb.angle:.0f} deg", (w - 150, 46), cv2.FONT_HERSHEY_SIMPLEX, 0.8, WHITE, 2, cv2.LINE_AA)
    cv2.putText(frame, ascii_fold(title), (260, 46), cv2.FONT_HERSHEY_SIMPLEX, 0.8, WHITE, 2, cv2.LINE_AA)
    return frame


def ascii_fold(text: str) -> str:
    """OpenCV'nin yazı tipi Türkçe karakter çizemez; ekrandaki kısa etiketler için sadeleştir."""
    return text.translate(str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosuCGIOSU"))


class Speaker:
    """Uyarıları arka planda sesli okur. Aynı uyarıyı 4 sn içinde tekrarlamaz.

    Windows'ta Türkçe ses için: Ayarlar > Saat ve dil > Konuşma > Ses ekle > Türkçe.
    Türkçe ses yoksa bip sesi çalar.
    """

    def __init__(self, enabled: bool = True, cooldown: float = 4.0):
        self.enabled = enabled
        self.cooldown = cooldown
        self._last: dict[str, float] = {}
        self._queue: queue.Queue[str] = queue.Queue(maxsize=3)
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def say(self, text: str | None):
        if not text or not self.enabled:
            return
        now = time.monotonic()
        if now - self._last.get(text, 0) < self.cooldown:
            return
        self._last[text] = now
        try:
            self._queue.put_nowait(text)
        except queue.Full:
            pass

    def _run(self):
        engine = None
        turkish = False
        try:
            import pyttsx3

            engine = pyttsx3.init()
            for voice in engine.getProperty("voices"):
                ident = f"{voice.id} {voice.name} {getattr(voice, 'languages', '')}".lower()
                if "tr" in ident.split("_") or "turkish" in ident or "türk" in ident or "tr-tr" in ident:
                    engine.setProperty("voice", voice.id)
                    turkish = True
                    break
            engine.setProperty("rate", 175)
        except Exception:
            engine = None
        while True:
            text = self._queue.get()
            try:
                if engine is not None and turkish:
                    engine.say(text)
                    engine.runAndWait()
                else:
                    _beep(good=text == "Harika")
            except Exception:
                _beep()


def _beep(good: bool = False):
    try:
        import winsound

        winsound.Beep(880 if good else 440, 180)
    except Exception:
        print("\a", end="", flush=True)
