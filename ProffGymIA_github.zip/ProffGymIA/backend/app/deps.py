"""Ortak bağımlılıklar: giriş yapmış kullanıcı, rol kontrolü, danışan erişim kontrolü."""
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from .database import get_db
from .models import Role, User
from .security import decode_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    user_id = decode_token(token, "access")
    user = db.get(User, user_id) if user_id else None
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Oturum geçersiz veya süresi dolmuş",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


def require_roles(*roles: Role):
    def checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Bu işlem için yetkiniz yok")
        return user

    return checker


require_admin = require_roles(Role.admin)
require_staff = require_roles(Role.admin, Role.trainer)


def resolve_target_user(current: User, user_id: int | None, db: Session) -> User:
    """Verinin kime ait olduğunu belirler.

    - user_id verilmezse: giriş yapan kullanıcının kendisi
    - Admin: herkesin verisine erişir
    - Trainer: yalnızca kendi danışanlarının verisine erişir
    - Üye: yalnızca kendi verisine erişir
    """
    if user_id is None or user_id == current.id:
        return current
    target = db.get(User, user_id)
    if not target:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kullanıcı bulunamadı")
    if current.role == Role.admin:
        return target
    if current.role == Role.trainer and target.trainer_id == current.id:
        return target
    raise HTTPException(status.HTTP_403_FORBIDDEN, "Bu kullanıcının verisine erişemezsiniz")
