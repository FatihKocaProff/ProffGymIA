"""FitAI backend.

Ortak kod (ortak/beslenme, ortak/giris_siniri) artık normal bir paket olarak kurulur:
requirements.txt içindeki "-e ../../ortak" satırı. Eskiden burada sys.path elle değiştiriliyordu;
klasör taşınınca anlaşılmaz bir ImportError veriyordu.
"""
from importlib.util import find_spec

if find_spec("beslenme") is None or find_spec("giris_siniri") is None:
    raise ImportError(
        "Ortak paket (proffgym-ortak) kurulu değil. backend klasöründe "
        "'.venv\\Scripts\\python -m pip install -r requirements.txt' çalıştır "
        "(veya baslat.bat'ı aç). 'ortak' klasörü ProffGymIA klasörünün yanında durmalı."
    )
