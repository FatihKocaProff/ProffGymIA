"use strict";

const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { } },
  del(k) { try { localStorage.removeItem(k); } catch { } },
};
const todayISO = () => new Date().toLocaleDateString("sv-SE");
const fmtDate = (iso, opts = { day: "numeric", month: "long" }) => (iso ? new Date(iso + (iso.length === 10 ? "T00:00" : "")).toLocaleDateString("tr-TR", opts) : "—");
const fmtTime = (iso) => (iso ? new Date(iso).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) : "");
const tl = (n) => Number(n || 0).toLocaleString("tr-TR", { maximumFractionDigits: 0 }) + " ₺";
const n1 = (n) => Number(n || 0).toLocaleString("tr-TR", { maximumFractionDigits: 1 });

const LABELS = {
  role: { admin: "Salon yöneticisi", trainer: "Personal trainer", member: "Üye" },
  goal: { lose: "Kilo vermek", maintain: "Kiloyu korumak", gain: "Kilo almak" },
  activity: {
    sedentary: "Hareketsiz", light: "Haftada 1–3 gün", moderate: "Haftada 3–5 gün",
    active: "Haftada 6–7 gün", very_active: "Çok aktif (günde 2 antrenman)",
  },
  meal: { breakfast: "Kahvaltı", lunch: "Öğle", dinner: "Akşam", snack: "Ara öğün" },
  gender: { male: "Erkek", female: "Kadın" },
  method: { qr: "QR", face: "Yüz", manual: "Elle" },
};
const options = (map, selected) => Object.entries(map).map(([k, v]) => `<option value="${k}" ${k === selected ? "selected" : ""}>${esc(v)}</option>`).join("");
const initials = (name) => String(name || "").trim().split(/\s+/).slice(0, 2).map((w) => (w[0] || "").toLocaleUpperCase("tr")).join("") || "?";

function avatar(u, size = "sm") {
  return u?.photo_path
    ? `<img class="avatar ${size}" src="/uploads/${esc(u.photo_path)}" alt="" loading="lazy">`
    : `<span class="avatar ${size}" aria-hidden="true">${esc(initials(u?.full_name))}</span>`;
}

let token = store.get("fitai_token");
let me = null;
let timers = [];
let qrScanner = null;

function clearTimers() {
  timers.forEach((t) => clearInterval(t));
  timers = [];
  if (qrScanner) { qrScanner.stop().catch(() => {}); qrScanner = null; }
}

function toast(msg, bad = false) {
  const el = document.createElement("div");
  el.textContent = msg;
  if (bad) el.className = "bad";
  $("#toast").append(el);
  setTimeout(() => el.remove(), 3800);
}

async function api(path, { method = "GET", body, form } = {}) {
  const headers = {};
  if (token) headers.Authorization = "Bearer " + token;
  let payload;
  if (form) payload = new URLSearchParams(form);
  else if (body instanceof FormData) payload = body;
  else if (body !== undefined) { headers["Content-Type"] = "application/json"; payload = JSON.stringify(body); }

  let res;
  try {
    res = await fetch(path, { method, headers, body: payload });
  } catch {
    throw new Error("Sunucuya ulaşılamadı. baslat.bat penceresinin açık olduğundan emin ol.");
  }
  if (res.status === 401 && path !== "/auth/login") { logout(); throw new Error("Oturumun sona erdi, tekrar giriş yap."); }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const err = new Error(errorText(data, res.status));
    err.status = res.status;
    throw err;
  }
  return data;
}

function errorText(data, status) {
  const d = data?.detail;
  if (typeof d === "string") return d;
  if (Array.isArray(d)) {
    const FIELD = { email: "Geçerli bir e-posta adresi yaz.", password: "Şifre 6 ile 72 karakter arasında olmalı.", full_name: "Ad soyadını yaz." };
    return [...new Set(d.map((e) => FIELD[e.loc?.slice(-1)[0]] || `${e.loc?.slice(-1)[0] ?? ""}: ${e.msg}`))].join(" ");
  }
  if (d?.message) return d.message;
  return `İstek başarısız oldu (${status}).`;
}

function onSubmit(form, handler) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("button[type=submit]", form);
    const err = $(".err", form);
    if (err) err.textContent = "";
    if (btn) btn.disabled = true;
    try {
      await handler(Object.fromEntries(new FormData(form)), form);
    } catch (ex) {
      if (err) err.textContent = ex.message; else toast(ex.message, true);
    } finally {
      if (btn) btn.disabled = false;
    }
  });
}

const num = (v) => (v === "" || v == null ? null : Number(v));

const DEMO = [
  ["Yönetici", "admin@fitai.com", "admin123"],
  ["PT", "pt@fitai.com", "pt1234"],
  ["Üye (aktif)", "ayse@fitai.com", "uye1234"],
  ["Üye (süresi bitmiş)", "eski@fitai.com", "uye1234"],
];

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
let setupNeedsAdmin = false;

function renderLogin(mode = "login") {
  clearTimers();
  const reg = mode === "register";
  $("#app").innerHTML = `
  <div class="login">
    <section class="login-brand" aria-hidden="true">
      <div class="wordmark">FitAI</div>
      <div class="plates"><span class="p-red"></span><span class="p-blue"></span><span class="p-yellow"></span><span class="p-green"></span><span class="bar"></span></div>
      <p>Turnike, üyelik, antrenör ve beslenme takibi tek bir panelde.</p>
    </section>
    <section class="login-form">${reg ? `
      <form id="register-form" novalidate>
        <h1 id="reg-title">Kayıt ol</h1>
        <p class="note" id="reg-note"></p>
        <label>Ad soyad<input name="full_name" autocomplete="name" required minlength="2"></label>
        <label>E-posta<input name="email" type="email" autocomplete="email" required></label>
        <label>Telefon<input name="phone" type="tel" autocomplete="tel" placeholder="İsteğe bağlı"></label>
        <div class="form-grid">
          <label>Şifre<input name="password" type="password" autocomplete="new-password" required minlength="6" placeholder="En az 6 karakter"></label>
          <label>Şifre tekrar<input name="password2" type="password" autocomplete="new-password" required></label>
        </div>
        <p class="err" role="alert"></p>
        <button class="btn block" type="submit" id="reg-submit">Kayıt ol</button>
        <p class="switch-mode">Zaten hesabın var mı? <button type="button" class="linklike" data-mode="login">Giriş yap</button></p>
      </form>` : `
      <form id="login-form" novalidate>
        <h1>Giriş yap</h1>
        <label>E-posta<input name="username" type="email" autocomplete="username" required></label>
        <label>Şifre<input name="password" type="password" autocomplete="current-password" required></label>
        <p class="err" role="alert"></p>
        <button class="btn block" type="submit">Giriş yap</button>
        <p class="switch-mode">Hesabın yok mu? <button type="button" class="linklike" data-mode="register">Kayıt ol</button></p>
        <div class="demo">
          <p class="small muted">Örnek hesaplarla dene (önce <b>seed.py</b> çalışmış olmalı):</p>
          <div class="demo-buttons">${DEMO.map(([l, e, p]) => `<button type="button" class="btn ghost sm" data-e="${e}" data-p="${p}">${l}</button>`).join("")}</div>
        </div>
      </form>`}
    </section>
  </div>`;
  $$("[data-mode]").forEach((b) => b.addEventListener("click", () => renderLogin(b.dataset.mode)));
  if (reg) bindRegister(); else bindLogin();
}

async function signIn(username, password) {
  const t = await api("/auth/login", { method: "POST", form: { username, password } });
  token = t.access_token;
  store.set("fitai_token", token);
  await boot();
}

function bindLogin() {
  const form = $("#login-form");
  $$(".demo-buttons button", form).forEach((b) =>
    b.addEventListener("click", () => {
      form.username.value = b.dataset.e;
      form.password.value = b.dataset.p;
      form.requestSubmit();
    })
  );
  onSubmit(form, async (v) => {
    if (!v.username || !v.password) throw new Error("E-posta ve şifreyi gir.");
    await signIn(v.username, v.password);
  });
  form.username.focus();
  optional(api("/auth/setup")).then((s) => {
    setupNeedsAdmin = !!s?.needs_admin;
    if (setupNeedsAdmin && $("#login-form") === form && !form.username.value) renderLogin("register");
  });
}

function bindRegister() {
  const form = $("#register-form");
  const applySetup = () => {
    const first = setupNeedsAdmin;
    $("#reg-title").textContent = first ? "İlk kurulum" : "Kayıt ol";
    $("#reg-submit").textContent = first ? "Yönetici hesabını oluştur" : "Kayıt ol";
    $("#reg-note").textContent = first
      ? "Bu salonda henüz yönetici hesabı yok. Oluşturacağın hesap salon yöneticisi olur."
      : "Hesabın üye olarak açılır ve hemen giriş yaparsın. Salon yöneticisi seni personal trainer yapabilir.";
  };
  applySetup();
  optional(api("/auth/setup")).then((s) => {
    if (s) setupNeedsAdmin = !!s.needs_admin;
    if ($("#register-form") === form) applySetup();
  });

  onSubmit(form, async (v) => {
    const body = { full_name: (v.full_name || "").trim(), email: (v.email || "").trim(), password: v.password || "", phone: (v.phone || "").trim() || null };
    if (body.full_name.length < 2) throw new Error("Ad soyadını yaz.");
    if (!EMAIL_RE.test(body.email)) throw new Error("Geçerli bir e-posta adresi yaz.");
    if (body.password.length < 6 || body.password.length > 72) throw new Error("Şifre 6 ile 72 karakter arasında olmalı.");
    if (body.password !== v.password2) throw new Error("Şifreler aynı değil.");
    let u;
    try {
      u = await api(setupNeedsAdmin ? "/auth/setup-admin" : "/auth/register", { method: "POST", body });
    } catch (e) {
      if (setupNeedsAdmin && e.status === 403) { setupNeedsAdmin = false; applySetup(); }
      throw e;
    }
    setupNeedsAdmin = false;
    await signIn(body.email, body.password);
    toast(u.role === "admin" ? "Salon yöneticisi hesabın oluşturuldu." : `Hoş geldin, ${u.full_name}! Üye hesabın açıldı.`);
  });
  form.full_name.focus();
}

function logout() {
  token = null;
  me = null;
  store.del("fitai_token");
  location.hash = "";
  renderLogin();
}

const NAV = {
  admin: [["bugun", "Bugün"], ["uyeler", "Üyeler"], ["paketler", "Paketler"], ["turnike", "Turnike"]],
  trainer: [["danisanlar", "Danışanlarım"]],
  member: [["ana", "Ana sayfa"], ["takip", "Kilo ve beslenme"], ["antrenman", "Antrenmanım"], ["profil", "Profilim"]],
};

const VIEWS = {
  bugun: viewToday, uyeler: viewMembers, uye: viewPerson, paketler: viewPackages, turnike: viewGate,
  danisanlar: viewMembers, danisan: viewPerson,
  ana: viewHome, takip: viewTracking, antrenman: viewMyWorkouts, profil: viewProfile,
};

function renderShell() {
  $("#app").innerHTML = `
  <div class="shell">
    <aside class="rail">
      <div class="wordmark"><i aria-hidden="true"><b style="background:#c4303a"></b><b style="background:#1f5fae"></b><b style="background:#d9a514"></b><b style="background:#2a8551"></b></i>FitAI</div>
      <nav aria-label="Ana menü">${NAV[me.role].map(([k, l]) => `<a href="#/${k}" data-k="${k}">${l}</a>`).join("")}${me.role === "member" ? `<a href="/panel/diyet/">Diyet defteri ↗</a>` : ""}</nav>
      <div class="who">
        <div class="who-row"><button type="button" class="avatar-btn" id="my-photo" title="Profil fotoğrafını değiştir" aria-label="Profil fotoğrafını değiştir">${avatar(me, "sm")}</button>
          <div><strong>${esc(me.full_name)}</strong><span>${LABELS.role[me.role]}</span></div></div>
        <button type="button" id="logout">Çıkış yap</button></div>
    </aside>
    <main id="view"></main>
  </div>`;
  $("#logout").addEventListener("click", logout);
  $("#my-photo").addEventListener("click", () => photoDialog(me, "me", (u) => { me = u; refreshMe(); route(); }));
}

function refreshMe() {
  const btn = $("#my-photo");
  if (btn) btn.innerHTML = avatar(me, "sm");
  const name = $(".rail .who strong");
  if (name) name.textContent = me.full_name;
}

function photoDialog(user, target, onSaved) {
  const base = target === "me" ? "/users/me/photo" : `/users/${target}/photo`;
  openDialog(`
    <form class="photo-dlg" onsubmit="return false">
      <h2>Profil fotoğrafı</h2>
      <div class="photo-preview">${avatar(user, "xl")}</div>
      <p class="small muted" style="text-align:center">JPEG, PNG veya WEBP, en çok 10 MB. Fotoğraf ortadan kare kırpılır.</p>
      <p class="err" role="alert"></p>
      <div class="actions">
        ${user.photo_path ? `<button type="button" class="btn ghost" data-remove>Fotoğrafı kaldır</button>` : ""}
        <button type="button" class="btn ghost" data-close>Kapat</button>
        <label class="btn" tabindex="0">${user.photo_path ? "Yeni fotoğraf seç" : "Fotoğraf seç"}<input type="file" accept="image/jpeg,image/png,image/webp" hidden></label>
      </div>
    </form>`, (dlg) => {
    const err = $(".err", dlg);
    const preview = $(".photo-preview", dlg);
    const done = (u, msg) => { dlg.close(); toast(msg); onSaved?.(u); };
    const input = $("input[type=file]", dlg);
    $("label.btn", dlg).addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); } });
    input.addEventListener("change", async () => {
      const file = input.files[0];
      if (!file) return;
      if (file.size > 10 * 1024 * 1024) { err.textContent = "Fotoğraf 10 MB'tan büyük olamaz."; return; }
      err.textContent = "";
      preview.innerHTML = `<img class="avatar xl" src="${URL.createObjectURL(file)}" alt="">`;
      preview.classList.add("busy");
      const fd = new FormData();
      fd.append("photo", file);
      try {
        done(await api(base, { method: "POST", body: fd }), "Profil fotoğrafı kaydedildi");
      } catch (ex) {
        err.textContent = ex.message;
        preview.classList.remove("busy");
        preview.innerHTML = avatar(user, "xl");
        input.value = "";
      }
    });
    $("[data-remove]", dlg)?.addEventListener("click", async () => {
      try { done(await api(base, { method: "DELETE" }), "Profil fotoğrafı kaldırıldı"); }
      catch (ex) { err.textContent = ex.message; }
    });
  });
}

async function route() {
  if (!me) return;
  clearTimers();
  const [key, id] = location.hash.replace(/^#\/?/, "").split("/");
  const allowed = NAV[me.role].map(([k]) => k).concat(me.role === "admin" ? ["uye"] : me.role === "trainer" ? ["danisan"] : []);
  if (!allowed.includes(key)) { location.hash = "#/" + NAV[me.role][0][0]; return; }

  const navKey = key === "uye" ? "uyeler" : key === "danisan" ? "danisanlar" : key;
  $$(".rail nav a").forEach((a) => (a.dataset.k === navKey ? a.setAttribute("aria-current", "page") : a.removeAttribute("aria-current")));

  const view = $("#view");
  view.innerHTML = `<p class="loading">Yükleniyor…</p>`;
  try {
    await VIEWS[key](view, id ? (/^\d+$/.test(id) ? Number(id) : decodeURIComponent(id)) : undefined);
  } catch (e) {
    view.innerHTML = `<div class="panel"><h2>Bu sayfa açılamadı</h2><p class="muted" style="margin-top:8px">${esc(e.message)}</p></div>`;
  }
  view.focus?.();
}

async function boot() {
  if (!token) return renderLogin();
  try {
    me = await api("/users/me");
  } catch {
    return logout();
  }
  renderShell();
  await route();
}

window.addEventListener("hashchange", route);
document.addEventListener("DOMContentLoaded", boot);

function statusColor(s) {
  if (!s.active) return "red";
  return s.remaining_days <= 7 ? "yellow" : "green";
}
function statusChip(s) {
  if (!s.active) return `<span class="chip red">Süresi dolmuş</span>`;
  if (s.remaining_days <= 7) return `<span class="chip yellow">${s.remaining_days} gün kaldı</span>`;
  return `<span class="chip green">Aktif</span>`;
}

function plate(s, size = "") {
  const r = 70, c = 2 * Math.PI * r;
  const frac = s.active ? Math.min(s.remaining_days / 30, 1) : 0;
  const color = `var(--${statusColor(s)})`;
  return `
  <div class="plate ${size}" role="img" aria-label="${s.remaining_days} gün üyelik kaldı">
    <svg viewBox="0 0 168 168">
      <circle class="track" cx="84" cy="84" r="${r}" fill="none" stroke-width="18"/>
      <circle class="val" cx="84" cy="84" r="${r}" fill="none" stroke="${color}" stroke-width="18"
        stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${(c * (1 - frac)).toFixed(1)}"/>    </svg>
    <div class="center"><span class="num">${s.remaining_days}</span><small>gün kaldı</small></div>
  </div>`;
}

function weightChart(rows) {
  if (rows.length < 2) return `<p class="empty">Grafik için en az iki gün kilo kaydı gerekiyor.</p>`;
  const W = 640, H = 230, P = { l: 44, r: 54, t: 14, b: 30 };
  const ys = rows.map((r) => r.weight_kg);
  let min = Math.min(...ys), max = Math.max(...ys);
  if (max - min < 1) { min -= 0.5; max += 0.5; }
  const pad = (max - min) * 0.12;
  const lo = min - pad, hi = max + pad;
  const x = (i) => P.l + (i * (W - P.l - P.r)) / (rows.length - 1);
  const y = (v) => P.t + ((hi - v) * (H - P.t - P.b)) / (hi - lo);
  const pts = rows.map((r, i) => [x(i), y(r.weight_kg)]);
  const line = pts.map(([px, py], i) => `${i ? "L" : "M"}${px.toFixed(1)},${py.toFixed(1)}`).join(" ");
  const area = `${line} L${pts.at(-1)[0].toFixed(1)},${H - P.b} L${P.l},${H - P.b} Z`;
  const ticks = [min, (min + max) / 2, max];
  const last = rows.at(-1), first = rows[0];
  const delta = last.weight_kg - first.weight_kg;
  return `
  <div class="chart">
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Kilo grafiği: ${n1(first.weight_kg)} kg'dan ${n1(last.weight_kg)} kg'a">
      <g class="grid">${ticks.map((t) => `<line x1="${P.l}" x2="${W - P.r}" y1="${y(t)}" y2="${y(t)}"/><text x="${P.l - 8}" y="${y(t) + 4}" text-anchor="end">${n1(t)}</text>`).join("")}</g>
      <path class="area" d="${area}"/>
      <path class="line" d="${line}"/>
      <circle class="dot" cx="${pts.at(-1)[0]}" cy="${pts.at(-1)[1]}" r="5"/>
      <text class="last" x="${pts.at(-1)[0] + 9}" y="${pts.at(-1)[1] + 5}">${n1(last.weight_kg)}</text>
      <g class="xl"><text x="${P.l}" y="${H - 8}">${fmtDate(first.log_date, { day: "numeric", month: "short" })}</text>
      <text x="${W - P.r}" y="${H - 8}" text-anchor="end">${fmtDate(last.log_date, { day: "numeric", month: "short" })}</text></g>
    </svg>
    <p class="small muted" style="margin-top:6px">${rows.length} kayıt içinde değişim:
      <span class="delta" style="color:var(--${Math.abs(delta) < 0.05 ? "ink-2" : delta < 0 ? "green" : "blue"})">${delta > 0 ? "+" : ""}${n1(delta)} kg</span></p>
  </div>`;
}

function metabolismFigures(m) {
  const f = (v, l, u = "") => `<div class="figure"><span class="num">${v}<span class="unit">${u}</span></span><span class="lbl">${l}</span></div>`;
  return `<div class="figures">
    ${f(m.bmr, "BMR", "kcal")}${f(m.tdee, "Günlük harcama", "kcal")}${f(m.target_calories, "Hedef kalori", "kcal")}
    ${f(m.protein_g, "Protein", "g")}${f(m.carbs_g, "Karbonhidrat", "g")}${f(m.fat_g, "Yağ", "g")}
    ${f((m.water_ml / 1000).toLocaleString("tr-TR"), "Su", "L")}${f(n1(m.bmi), "BMI · " + esc(m.bmi_category))}
  </div>`;
}

function macroBars(s) {
  const row = (label, val, target, unit) => {
    const pct = target ? Math.min((val / target) * 100, 100) : 0;
    const over = target && val > target * 1.05;
    return `<div class="bar-row"><div class="top"><span>${label}</span><span class="num">${n1(val)}${target ? " / " + target : ""} ${unit}</span></div>
      <div class="bar-track"><div class="bar-fill ${over ? "over" : ""}" style="width:${target ? pct : 0}%"></div></div></div>`;
  };
  return `<div class="bars">
    ${row("Kalori", s.calories, s.target_calories, "kcal")}${row("Protein", s.protein_g, s.target_protein_g, "g")}
    ${row("Karbonhidrat", s.carbs_g, s.target_carbs_g, "g")}${row("Yağ", s.fat_g, s.target_fat_g, "g")}
  </div>${s.target_calories ? "" : `<p class="small muted" style="margin-top:10px">Hedefler için profil ve kilo bilgisi gerekiyor.</p>`}`;
}

const EXERCISE = { squat: "Squat", biceps_curl: "Biceps curl", shoulder_press: "Omuz press" };

function formTable(sessions) {
  if (!sessions.length) return `<p class="empty">Bu dönemde form analizi yapılmamış. Analiz mobil uygulamadan veya masaüstü panelden yapılır.</p>`;
  return `<div class="table-wrap"><table><thead><tr><th>Tarih</th><th>Hareket</th><th class="r">Doğru / tekrar</th><th class="r">Skor</th><th>En sık uyarı</th></tr></thead><tbody>
    ${sessions.map((s) => {
      const top = Object.entries(s.issues || {}).sort((a, b) => b[1] - a[1])[0];
      const c = s.score >= 80 ? "green" : s.score >= 60 ? "yellow" : "red";
      return `<tr><td>${fmtDate(s.created_at.slice(0, 10), { day: "numeric", month: "short" })} <span class="muted small">${fmtTime(s.created_at)}</span></td>
        <td>${esc(EXERCISE[s.exercise] || s.exercise)}</td><td class="r num">${s.good_reps} / ${s.reps}</td>
        <td class="r"><span class="chip ${c}">%${Math.round(s.score)}</span></td><td class="muted">${top ? `${esc(top[0])} (${top[1]})` : "—"}</td></tr>`;
    }).join("")}</tbody></table></div>`;
}

async function openReport(userId) {
  const win = window.open("", "_blank");
  try {
    const res = await fetch(`/reports/monthly${userId ? `?user_id=${userId}` : ""}`, { headers: { Authorization: "Bearer " + token } });
    if (!res.ok) throw new Error(errorText(await res.json().catch(() => null), res.status));
    const url = URL.createObjectURL(await res.blob());
    if (win) win.location = url; else location.href = url;
  } catch (e) {
    if (win) win.close();
    toast(e.message, true);
  }
}

function mealList(meals, canDelete = false) {
  if (!meals.length) return `<p class="empty">Bu gün için öğün girilmemiş.</p>`;
  return meals.map((m) => `
    <div class="meal">
      <div><strong>${LABELS.meal[m.meal_type]}</strong> <span class="muted small">${m.meal_date !== todayISO() ? fmtDate(m.meal_date, { day: "numeric", month: "short" }) : ""}</span>
        <div>${esc(m.description || (m.photo_path ? "Fotoğraflı öğün" : ""))}${m.source === "ai" ? ` <span class="chip blue">AI${m.ai_detail?.confidence ? " · güven " + esc(m.ai_detail.confidence) : ""}</span>` : ""}${m.source === "auto" ? ` <span class="chip neutral" title="Yazılan öğünden besin tablosuyla hesaplandı">Otomatik hesap</span>` : ""}${m.source === "diary" ? ` <span class="chip neutral" title="Kepçe diyet defterinden eklendi">Diyet defteri</span>` : ""}</div>
        ${(m.source === "auto" || (m.source === "ai" && !m.photo_path)) && m.ai_detail?.items?.length ? `<div class="small muted">${m.ai_detail.items.map((i) => `${esc(i.name)} ${Math.round(i.calories)} kcal`).join(" · ")}</div>` : ""}
        ${m.ai_detail?.error ? `<div class="small" style="color:var(--red)">Analiz yapılamadı: ${esc(m.ai_detail.error)}</div>` : ""}
        <div class="macros">P ${n1(m.protein_g)} g · K ${n1(m.carbs_g)} g · Y ${n1(m.fat_g)} g${m.photo_path ? ` · <a href="/uploads/${esc(m.photo_path)}" target="_blank" rel="noopener">fotoğraf</a>` : ""}</div></div>
      <div style="text-align:right"><div class="kcal">${Math.round(m.calories)} kcal</div>
        ${canDelete ? `<button class="btn ghost sm" data-del-meal="${m.id}">Sil</button>` : ""}</div>
    </div>`).join("");
}

function workoutBlock(w, { canComplete = false, canDelete = false } = {}) {
  return `
  <div class="workout">
    <div class="workout-head">
      <div><h3>${esc(w.title)}</h3><p class="small muted">${fmtDate(w.workout_date, { weekday: "long", day: "numeric", month: "long" })}</p></div>
      <div class="form-row">
        ${w.completed ? `<span class="chip green">Tamamlandı</span>` : `<span class="chip blue">Planlandı</span>`}
        ${canComplete ? `<button class="btn ${w.completed ? "ghost" : ""} sm" data-complete="${w.id}" data-val="${!w.completed}">${w.completed ? "Geri al" : "Tamamladım"}</button>` : ""}
        ${canDelete ? `<button class="btn ghost sm" data-del-workout="${w.id}">Sil</button>` : ""}
      </div>
    </div>
    ${w.notes ? `<p class="muted" style="margin-bottom:8px">${esc(w.notes)}</p>` : ""}
    ${w.exercises.length ? `<div class="table-wrap"><table><thead><tr><th>Hareket</th><th class="r">Set</th><th class="r">Tekrar</th><th class="r">Ağırlık</th></tr></thead><tbody>
      ${w.exercises.map((e) => `<tr><td>${esc(e.name)}</td><td class="r num">${e.sets}</td><td class="r num">${e.reps}</td><td class="r num">${e.weight_kg != null ? n1(e.weight_kg) + " kg" : "—"}</td></tr>`).join("")}
    </tbody></table></div>` : ""}
  </div>`;
}

function bindWorkoutActions(root, reload) {
  $$("[data-complete]", root).forEach((b) => b.addEventListener("click", async () => {
    try { await api(`/workouts/${b.dataset.complete}/complete?completed=${b.dataset.val}`, { method: "PATCH" }); reload(); }
    catch (e) { toast(e.message, true); }
  }));
  $$("[data-del-workout]", root).forEach((b) => b.addEventListener("click", async () => {
    if (!confirm("Bu antrenman silinsin mi?")) return;
    try { await api(`/workouts/${b.dataset.delWorkout}`, { method: "DELETE" }); toast("Antrenman silindi"); reload(); }
    catch (e) { toast(e.message, true); }
  }));
}

async function optional(promise) {
  try { return await promise; } catch { return null; }
}

function openDialog(html, bind) {
  const dlg = $("#dlg");
  dlg.innerHTML = html;
  $$("[data-close]", dlg).forEach((b) => b.addEventListener("click", () => dlg.close()));
  bind(dlg);
  dlg.showModal();
}

async function viewToday(v) {
  const [s, members, logs] = await Promise.all([api("/overview/stats"), api("/overview/members"), api("/checkin/logs?limit=8")]);
  const expiring = members.filter((m) => m.remaining_days <= 7).sort((a, b) => b.remaining_days - a.remaining_days);
  const upcoming = members.filter((m) => m.active && m.remaining_days > 7).sort((a, b) => a.remaining_days - b.remaining_days).slice(0, 3);
  const score = (val, lbl, c, href) => href
    ? `<a class="score" href="${href}" style="--c:var(--${c})"><span class="num">${val}</span><span class="lbl">${lbl} →</span></a>`
    : `<div class="score" style="--c:var(--${c})"><span class="num">${val}</span><span class="lbl">${lbl}</span></div>`;
  const memberRow = (m) => `
        <tr class="link" data-href="#/uye/${m.id}"><td><div class="who-cell">${avatar(m, "xs")}<div>${esc(m.full_name)}<div class="small muted">${esc(m.phone || m.email)}</div></div></div></td>
          <td class="r">${m.active ? `<span class="small muted">${fmtDate(m.end_date, { day: "numeric", month: "short" })}</span> ` : ""}${m.active && m.remaining_days > 7 ? `<span class="chip green">${m.remaining_days} gün kaldı</span>` : statusChip(m)}</td></tr>`;

  v.innerHTML = `
  <header class="page-head"><div><h1>Bugün</h1><p class="sub">${new Date().toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p></div>
    <a class="btn" href="#/turnike">Turnikeyi aç</a></header>
  <section class="scoreboard" aria-label="Günün özeti">
    ${score(`${s.active_members}<span class="muted" style="font-size:1.3rem"> / ${s.total_members}</span>`, "aktif üye", "green", "#/uyeler")}
    ${score(s.expiring_soon, "7 gün içinde bitiyor", "yellow", "#/uyeler/soon")}
    ${score(s.today_checkins, "bugünkü giriş", "blue")}
    ${score(s.denied_today, "reddedilen giriş", "red")}
    ${score(tl(s.month_revenue).replace(" ₺", `<span style="font-size:1.4rem"> ₺</span>`), "bu ayki satış", "ink")}
  </section>
  <div class="grid2">
    <section class="panel"><div class="panel-head"><h2>Üyeliği bitenler ve bitmek üzere olanlar</h2></div>
      ${expiring.length ? `<div class="table-wrap"><table><tbody>${expiring.map(memberRow).join("")}
      </tbody></table></div>` : `<p class="empty">Önümüzdeki 7 gün içinde biten üyelik yok.</p>`}
      ${upcoming.length ? `<h3 class="small muted" style="margin:14px 0 4px;font-weight:600">Sıradaki bitişler</h3>
        <div class="table-wrap"><table><tbody>${upcoming.map(memberRow).join("")}</tbody></table></div>
        <p class="small" style="margin-top:8px"><a href="#/uyeler/d30">30 gün içinde bitenlerin tümü →</a></p>` : ""}
    </section>
    <section class="panel"><div class="panel-head"><h2>Son geçişler</h2><a href="#/turnike" class="small">Tümü</a></div>
      ${logs.length ? `<div class="table-wrap"><table><tbody>${logs.map((l) => `
        <tr><td class="num">${fmtTime(l.created_at)}</td><td>${esc(l.full_name || "Tanınmayan")}<div class="small muted">${esc(l.reason || "")}</div></td>
        <td class="r"><span class="chip ${l.granted ? "green" : "red"}">${l.granted ? "Girdi" : "Reddedildi"}</span></td></tr>`).join("")}
      </tbody></table></div>` : `<p class="empty">Bugün henüz geçiş yok. Turnike ekranından bir QR okutarak dene.</p>`}
    </section>
  </div>`;
  $$("tr[data-href]", v).forEach((tr) => tr.addEventListener("click", () => (location.hash = tr.dataset.href)));
}

const MEMBER_FILTERS = {
  active: { label: "Aktif (7 günden fazla)", test: (m) => m.active && m.remaining_days > 7 },
  soon: { label: "Bitmek üzere (7 gün)", days: 7, test: (m) => m.active && m.remaining_days <= 7 },
  d15: { label: "15 gün içinde bitiyor", days: 15, test: (m) => m.active && m.remaining_days <= 15 },
  d30: { label: "30 gün içinde bitiyor", days: 30, test: (m) => m.active && m.remaining_days <= 30 },
  expired: { label: "Süresi dolmuş / paketi yok", test: (m) => !m.active },
};

async function viewMembers(v, preset) {
  const isAdmin = me.role === "admin";
  const [members, trainers] = await Promise.all([api("/overview/members"), isAdmin ? api("/users?role=trainer") : []]);
  const base = isAdmin ? "uye" : "danisan";
  const clientCount = {};
  members.forEach((m) => { if (m.trainer_id) clientCount[m.trainer_id] = (clientCount[m.trainer_id] || 0) + 1; });

  v.innerHTML = `
  <header class="page-head"><div><h1>${isAdmin ? "Üyeler" : "Danışanlarım"}</h1>
    <p class="sub">${members.length} ${isAdmin ? "kayıtlı üye" : "danışan"}</p></div>
    ${isAdmin ? `<button class="btn" id="new-member">Yeni üye kaydet</button>` : ""}</header>
  <section class="panel">
    <div class="form-row" style="margin-bottom:14px"><label style="max-width:360px">Ara<input id="q" type="search" placeholder="Ad, e-posta veya telefon"></label>
      <label style="max-width:240px">Durum<select id="f"><option value="">Hepsi</option>${Object.entries(MEMBER_FILTERS).map(([k, f]) => `<option value="${k}" ${k === preset ? "selected" : ""}>${f.label}</option>`).join("")}</select></label></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Ad</th>${isAdmin ? "<th>PT</th>" : "<th>Hedef</th>"}<th>Durum</th><th class="r">Kalan gün</th><th class="r">Son kilo</th></tr></thead>
      <tbody id="rows"></tbody></table></div>
  </section>
  ${isAdmin ? `<section class="panel" style="margin-top:20px"><div class="panel-head"><h2>Personal trainer'lar (${trainers.length})</h2></div>
    ${trainers.length ? `<div class="table-wrap"><table><thead><tr><th>Ad</th><th class="r">Danışan</th></tr></thead><tbody id="trainer-rows">
      ${trainers.map((t) => `<tr class="link" data-id="${t.id}" tabindex="0"><td><strong>${esc(t.full_name)}</strong><div class="small muted">${esc(t.email)}</div></td>
        <td class="r num">${clientCount[t.id] || 0}</td></tr>`).join("")}</tbody></table></div>
      <p class="small muted" style="margin-top:10px">Bir üyeyi PT yapmak için üyenin sayfasındaki <b>Personal trainer yap</b> butonunu kullan. PT'yi tekrar üye yapmak için satırına tıkla.</p>`
    : `<p class="empty">Henüz personal trainer yok. Bir üyenin sayfasını açıp <b>Personal trainer yap</b> butonuna bas.</p>`}
  </section>` : ""}`;
  $$("#trainer-rows tr[data-id]").forEach((tr) => {
    const go = () => (location.hash = `#/uye/${tr.dataset.id}`);
    tr.addEventListener("click", go);
    tr.addEventListener("keydown", (e) => e.key === "Enter" && go());
  });

  const draw = () => {
    const q = $("#q").value.trim().toLocaleLowerCase("tr");
    const f = $("#f").value;
    const filter = MEMBER_FILTERS[f];
    const list = members.filter((m) => {
      const hay = `${m.full_name} ${m.email} ${m.phone || ""}`.toLocaleLowerCase("tr");
      if (q && !hay.includes(q)) return false;
      return filter ? filter.test(m) : true;
    });
    if (filter?.days) list.sort((a, b) => a.remaining_days - b.remaining_days);
    let empty = "Aramaya uyan kayıt yok.";
    if (!members.length) empty = isAdmin ? "Henüz üye yok. Yeni üye kaydet butonuyla başla." : "Size atanmış danışan yok. Yönetici üye detayından PT ataması yapabilir.";
    else if (filter?.days && !q) {
      const next = members.filter((m) => m.active).sort((a, b) => a.remaining_days - b.remaining_days)[0];
      empty = `Önümüzdeki ${filter.days} gün içinde üyeliği biten yok.` + (next
        ? ` En yakın bitiş: <strong>${esc(next.full_name)}</strong>, ${next.remaining_days} gün kaldı (${fmtDate(next.end_date, { day: "numeric", month: "long" })}).`
        + (filter.days < 30 ? ` <button type="button" class="linklike" data-filter="${filter.days < 15 ? "d15" : "d30"}">${filter.days < 15 ? 15 : 30} günü göster</button>` : "")
        : "");
    }
    $("#rows").innerHTML = list.length ? list.map((m) => `
      <tr class="link" data-id="${m.id}" tabindex="0">
        <td><div class="who-cell">${avatar(m, "xs")}<div><strong>${esc(m.full_name)}</strong><div class="small muted">${esc(m.email)}</div></div></div></td>
        <td>${isAdmin ? esc(m.trainer_name || "—") : LABELS.goal[m.goal]}</td>
        <td>${statusChip(m)}</td>
        <td class="r num">${m.active ? `${m.remaining_days}<div class="small muted">${fmtDate(m.end_date, { day: "numeric", month: "short" })}</div>` : "0"}</td>
        <td class="r num">${m.last_weight != null ? n1(m.last_weight) + " kg" : "—"}</td>
      </tr>`).join("") : `<tr><td colspan="5" class="empty">${empty}</td></tr>`;
    $$("#rows [data-filter]").forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      $("#f").value = b.dataset.filter;
      draw();
    }));
    $$("#rows tr[data-id]").forEach((tr) => {
      const go = () => (location.hash = `#/${base}/${tr.dataset.id}`);
      tr.addEventListener("click", go);
      tr.addEventListener("keydown", (e) => e.key === "Enter" && go());
    });
  };
  $("#q").addEventListener("input", draw);
  $("#f").addEventListener("change", draw);
  draw();

  if (isAdmin) $("#new-member").addEventListener("click", () => newMemberDialog());
}

async function newMemberDialog() {
  const trainers = await api("/users?role=trainer");
  openDialog(`
    <form>
      <h2>Yeni üye kaydet</h2>
      <label>Ad soyad<input name="full_name" required minlength="2"></label>
      <div class="form-grid"><label>E-posta<input name="email" type="email" required></label><label>Telefon<input name="phone" type="tel"></label></div>
      <div class="form-grid"><label>Geçici şifre<input name="password" required minlength="6" value="uye1234"></label>
        <label>PT<select name="trainer_id"><option value="">Atanmasın</option>${trainers.map((t) => `<option value="${t.id}">${esc(t.full_name)}</option>`).join("")}</select></label></div>
      <p class="err"></p>
      <div class="actions"><button type="button" class="btn ghost" data-close>Vazgeç</button><button class="btn" type="submit">Kaydet</button></div>
    </form>`, (dlg) => {
    onSubmit($("form", dlg), async (f) => {
      const u = await api("/users", { method: "POST", body: { ...f, phone: f.phone || null, trainer_id: num(f.trainer_id), role: "member" } });
      dlg.close();
      toast(`${u.full_name} kaydedildi. Şimdi paket satabilirsin.`);
      location.hash = `#/uye/${u.id}`;
    });
  });
}

async function viewPackages(v) {
  const pkgs = await api("/packages?include_inactive=true");
  v.innerHTML = `
  <header class="page-head"><div><h1>Paketler</h1><p class="sub">Üyeler aktif paketleri mobil uygulamada görür.</p></div>
    <button class="btn" id="new-pkg">Paket ekle</button></header>
  <section class="panel"><div class="table-wrap"><table>
    <thead><tr><th>Paket</th><th class="r">Süre</th><th class="r">Fiyat</th><th class="r">Günlük</th><th>Durum</th><th></th></tr></thead>
    <tbody>${pkgs.length ? pkgs.map((p) => `
      <tr><td><strong>${esc(p.name)}</strong><div class="small muted">${esc(p.description || "")}</div></td>
      <td class="r num">${p.duration_days} gün</td><td class="r num">${tl(p.price)}</td>
      <td class="r num muted">${tl(p.price / p.duration_days)}</td>
      <td>${p.is_active ? `<span class="chip green">Satışta</span>` : `<span class="chip red">Satışta değil</span>`}</td>
      <td class="r"><button class="btn ghost sm" data-edit="${p.id}">Düzenle</button></td></tr>`).join("")
      : `<tr><td colspan="6" class="empty">Henüz paket yok. Paket ekle butonuyla ilk paketi oluştur.</td></tr>`}
    </tbody></table></div></section>`;

  const dialog = (p) => openDialog(`
    <form>
      <h2>${p ? "Paketi düzenle" : "Paket ekle"}</h2>
      <label>Paket adı<input name="name" required value="${esc(p?.name || "")}" placeholder="Örn. 3 Aylık"></label>
      <div class="form-grid"><label>Süre (gün)<input name="duration_days" type="number" min="1" required value="${p?.duration_days ?? 30}"></label>
        <label>Fiyat (₺)<input name="price" type="number" min="0" step="1" required value="${p?.price ?? ""}"></label></div>
      <label>Açıklama<input name="description" value="${esc(p?.description || "")}"></label>
      <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="is_active" style="width:auto" ${!p || p.is_active ? "checked" : ""}> Satışta</label>
      <p class="err"></p>
      <div class="actions"><button type="button" class="btn ghost" data-close>Vazgeç</button><button class="btn" type="submit">${p ? "Değişiklikleri kaydet" : "Paketi ekle"}</button></div>
    </form>`, (dlg) => {
    onSubmit($("form", dlg), async (f) => {
      const body = { name: f.name, duration_days: Number(f.duration_days), price: Number(f.price), description: f.description || null, is_active: !!f.is_active };
      await api(p ? `/packages/${p.id}` : "/packages", { method: p ? "PATCH" : "POST", body });
      dlg.close();
      toast(p ? "Paket güncellendi" : "Paket eklendi");
      viewPackages(v);
    });
  });
  $("#new-pkg").addEventListener("click", () => dialog(null));
  $$("[data-edit]", v).forEach((b) => b.addEventListener("click", () => dialog(pkgs.find((p) => p.id === Number(b.dataset.edit)))));
}

async function viewGate(v) {
  v.innerHTML = `
  <header class="page-head"><div><h1>Turnike</h1><p class="sub">Üyenin uygulamadaki QR kodunu okut. USB QR okuyucu da bu alana yazar.</p></div></header>
  <div class="grid2 gate-layout">
    <section class="gate" id="gate" aria-live="assertive">
      <div><div class="state" id="gate-state">QR bekleniyor</div><div class="detail muted" id="gate-detail">Kod okutulduğunda sonuç burada görünür.</div></div>
      <div>
        <form id="gate-form"><input name="token" id="gate-input" placeholder="QR içeriği" autocomplete="off" aria-label="QR içeriği">
          <button class="btn" type="submit">Doğrula</button><button class="btn ghost" type="button" id="cam">Kamerayla okut</button></form>
        <div id="reader"></div>
      </div>
    </section>
    <section class="panel"><div class="panel-head"><h2>Geçiş kayıtları</h2><button class="btn ghost sm" id="refresh">Yenile</button></div><div id="logs"></div></section>
  </div>
  <p class="small muted" style="margin-top:16px">Denemek için: başka bir tarayıcı penceresinde (veya gizli pencerede) bir üye hesabıyla giriş yap, Ana sayfa'daki <b>Kodu kopyala</b> butonuna bas ve buraya yapıştır.</p>`;

  const loadLogs = async () => {
    const logs = await api("/checkin/logs?limit=25");
    $("#logs").innerHTML = logs.length ? `<div class="table-wrap"><table><thead><tr><th>Saat</th><th>Kişi</th><th>Yöntem</th><th class="r">Sonuç</th></tr></thead><tbody>
      ${logs.map((l) => `<tr><td class="num">${fmtTime(l.created_at)}<div class="small muted">${fmtDate(l.created_at?.slice(0, 10), { day: "numeric", month: "short" })}</div></td>
        <td>${esc(l.full_name || "Tanınmayan")}<div class="small muted">${esc(l.reason || "")}</div></td><td>${LABELS.method[l.method]}</td>
        <td class="r"><span class="chip ${l.granted ? "green" : "red"}">${l.granted ? "Girdi" : "Reddedildi"}</span></td></tr>`).join("")}
      </tbody></table></div>` : `<p class="empty">Henüz geçiş kaydı yok.</p>`;
  };

  let resetTimer = null;
  const gate = $("#gate");
  const check = async (tokenText) => {
    const r = await api("/checkin/qr", { method: "POST", body: { token: tokenText.trim() } });
    gate.className = "gate " + (r.granted ? "granted" : "denied");
    $("#gate-state").textContent = r.granted ? "Geçiş onaylandı" : "Giriş reddedildi";
    $("#gate-detail").innerHTML = `${r.full_name ? `<strong>${esc(r.full_name)}</strong> · ` : ""}${esc(r.reason)}${r.granted && r.remaining_days != null && r.user_id ? ` · ${r.remaining_days} gün kaldı` : ""}`;
    clearTimeout(resetTimer);
    resetTimer = setTimeout(() => {
      gate.className = "gate";
      $("#gate-state").textContent = "QR bekleniyor";
      $("#gate-detail").textContent = "Kod okutulduğunda sonuç burada görünür.";
    }, 5000);
    loadLogs();
  };

  onSubmit($("#gate-form"), async (f, form) => {
    if (!f.token.trim()) throw new Error("Önce bir QR kodu okut.");
    await check(f.token);
    form.reset();
    $("#gate-input").focus();
  });
  $("#refresh").addEventListener("click", loadLogs);
  $("#cam").addEventListener("click", () => startCamera(check));
  $("#gate-input").focus();
  await loadLogs();
}

function loadScript(src) {
  return new Promise((ok, fail) => {
    if ($(`script[src="${src}"]`)) return ok();
    const s = document.createElement("script");
    s.src = src; s.onload = ok; s.onerror = () => fail(new Error("Kamera kütüphanesi yüklenemedi (internet bağlantısı gerekiyor)."));
    document.head.append(s);
  });
}

async function startCamera(onCode) {
  try {
    if (qrScanner) { await qrScanner.stop(); qrScanner = null; $("#cam").textContent = "Kamerayla okut"; return; }
    await loadScript("https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js");
    qrScanner = new Html5Qrcode("reader");
    let busy = false;
    await qrScanner.start({ facingMode: "user" }, { fps: 8, qrbox: 220 }, async (text) => {
      if (busy) return;
      busy = true;
      try { await onCode(text); } catch (e) { toast(e.message, true); }
      setTimeout(() => (busy = false), 3000);
    });
    $("#cam").textContent = "Kamerayı kapat";
  } catch (e) {
    qrScanner = null;
    toast(typeof e === "string" ? "Kamera açılamadı: " + e : e.message, true);
  }
}

async function viewPerson(v, id) {
  const isAdmin = me.role === "admin";
  const q = `user_id=${id}`;
  const [user, status, weights, metab, summary, meals, workouts, sessions, history, pkgs, trainers] = await Promise.all([
    api(`/users/${id}`),
    api(`/memberships/status?${q}`),
    api(`/weights?${q}&days=60`),
    optional(api(`/users/me/metabolism?${q}`)),
    api(`/meals/summary?${q}`),
    api(`/meals?${q}&days=3`),
    api(`/workouts?${q}&days=14`),
    api(`/form-sessions?${q}&days=30`),
    isAdmin ? api(`/memberships?${q}`) : null,
    isAdmin ? api("/packages") : null,
    isAdmin ? api("/users?role=trainer") : null,
  ]);
  const reload = () => viewPerson(v, id);

  v.innerHTML = `
  <a class="back" href="#/${isAdmin ? "uyeler" : "danisanlar"}">← ${isAdmin ? "Üyeler" : "Danışanlarım"}</a>
  <div class="person-head">
    ${plate(status)}
    <div class="person-photo">${avatar(user, "lg")}
      ${isAdmin ? `<button type="button" class="linklike small" id="person-photo">${user.photo_path ? "Fotoğrafı değiştir" : "Fotoğraf ekle"}</button>` : ""}</div>
    <div class="info">
      <h1>${esc(user.full_name)}</h1>
      <p class="muted">${esc(user.email)}${user.phone ? " · " + esc(user.phone) : ""}</p>
      <div class="form-row">${user.role === "trainer" ? `<span class="chip green">Personal trainer</span>` : ""}${statusChip(status)}<span class="chip blue">${LABELS.goal[user.goal]}</span>
        ${status.end_date ? `<span class="small muted">Bitiş: ${fmtDate(status.end_date, { day: "numeric", month: "long", year: "numeric" })}</span>` : ""}</div>
      <div class="form-row"><button class="btn sm" id="pdf">PDF gelişim karnesi</button>
        ${isAdmin && user.role !== "admin" ? `<button class="btn ghost sm" id="role" data-role="${user.role === "trainer" ? "member" : "trainer"}">${user.role === "trainer" ? "Üye yap" : "Personal trainer yap"}</button>` : ""}</div>
    </div>
  </div>

  ${isAdmin ? `
  <div class="grid2" style="margin-bottom:20px">
    <section class="panel"><h2>Paket sat veya üyeliği uzat</h2>
      ${pkgs.length ? `<form id="sell" class="form-row">
        <label style="flex:2 1 240px">Paket<select name="package_id">${pkgs.map((p) => `<option value="${p.id}" data-price="${p.price}">${esc(p.name)} · ${p.duration_days} gün · ${tl(p.price)}</option>`).join("")}</select></label>
        <label style="max-width:150px">Alınan ücret (₺)<input name="price_paid" type="number" min="0" placeholder="${pkgs[0].price}"></label>
        <button class="btn" type="submit">Satışı kaydet</button><p class="err" style="width:100%"></p></form>
        <p class="small muted">Üyelik devam ediyorsa yeni süre mevcut bitişin ertesi günü başlar.</p>`
      : `<p class="empty">Satışta paket yok. <a href="#/paketler">Paket ekle</a></p>`}
    </section>
    <section class="panel"><h2>PT ataması</h2>
      <form id="assign" class="form-row"><label>PT<select name="trainer_id"><option value="">Atanmasın</option>
        ${trainers.map((t) => `<option value="${t.id}" ${t.id === user.trainer_id ? "selected" : ""}>${esc(t.full_name)}</option>`).join("")}</select></label>
        <button class="btn ghost" type="submit">Kaydet</button><p class="err" style="width:100%"></p></form>
      ${history.length ? `<h3 style="margin:18px 0 6px">Satış geçmişi</h3><div class="table-wrap"><table><tbody>${history.map((m) => `
        <tr><td>${fmtDate(m.start_date, { day: "numeric", month: "short", year: "numeric" })} – ${fmtDate(m.end_date, { day: "numeric", month: "short", year: "numeric" })}</td><td class="r num">${tl(m.price_paid)}</td></tr>`).join("")}</tbody></table></div>` : ""}
    </section>
  </div>` : ""}

  <div class="grid2">
    <section class="panel"><div class="panel-head"><h2>Kilo değişimi</h2><span class="small muted">Son 60 gün</span></div>${weightChart(weights)}</section>
    <section class="panel"><h2>Metabolizma</h2>
      ${metab ? metabolismFigures(metab) : `<p class="empty">Profil eksik: cinsiyet, doğum tarihi, boy ve en az bir kilo kaydı gerekiyor. Üye bunları mobil uygulamadan girer.</p>`}</section>
    <section class="panel"><div class="panel-head"><h2>Bugünkü beslenme</h2><span class="small muted">${summary.meal_count} öğün</span></div>${macroBars(summary)}</section>
    <section class="panel"><div class="panel-head"><h2>Son 3 günün öğünleri</h2></div>${mealList(meals)}</section>
    <section class="panel span2"><div class="panel-head"><h2>Form analizi</h2><span class="small muted">Son 30 gün</span></div>
      ${formTable(sessions)}</section>
    <section class="panel span2"><div class="panel-head"><h2>Antrenman programı</h2><span class="small muted">Bugünden itibaren 14 gün</span></div>
      ${workouts.length ? workouts.map((w) => workoutBlock(w, { canDelete: true })).join("") : `<p class="empty">Planlanmış antrenman yok.</p>`}
      <h3 style="margin:24px 0 12px">Yeni antrenman tanımla</h3>
      <form id="wform" class="stack" style="gap:14px">
        <div class="form-grid"><label>Tarih<input type="date" name="workout_date" value="${todayISO()}" required></label>
          <label>Başlık<input name="title" required placeholder="Örn. Alt vücut + core"></label></div>
        <label>Not (isteğe bağlı)<input name="notes" placeholder="Örn. Squat'ta dizler ayak uçlarını geçmesin"></label>
        <div><div class="small muted" style="margin-bottom:6px">Hareketler: ad, set, tekrar, ağırlık (kg)</div><div id="ex-list"></div>
          <button type="button" class="btn ghost sm" id="add-ex">Hareket ekle</button></div>
        <p class="err"></p>
        <div><button class="btn" type="submit">Antrenmanı kaydet</button></div>
      </form>
    </section>
  </div>`;

  bindWorkoutActions(v, reload);
  $("#pdf").addEventListener("click", () => openReport(id));
  $("#person-photo")?.addEventListener("click", () => photoDialog(user, id, reload));
  $("#role")?.addEventListener("click", async (e) => {
    const role = e.currentTarget.dataset.role;
    const toTrainer = role === "trainer";
    const question = toTrainer
      ? `${user.full_name} personal trainer yapılsın mı?\n\nPanele PT olarak girebilecek ve ona danışan atayabileceksin.`
      : `${user.full_name} tekrar üye yapılsın mı?\n\nVarsa danışanlarının PT ataması kaldırılır.`;
    if (!confirm(question)) return;
    try {
      await api(`/users/${id}/role`, { method: "PATCH", body: { role } });
      toast(`${user.full_name} artık ${toTrainer ? "personal trainer" : "üye"}.`);
      reload();
    } catch (err) { toast(err.message, true); }
  });

  const exList = $("#ex-list");
  const addEx = (name = "") => {
    const row = document.createElement("div");
    row.className = "ex-row";
    row.innerHTML = `<input placeholder="Hareket" aria-label="Hareket adı" value="${esc(name)}"><input type="number" min="1" value="3" aria-label="Set">
      <input type="number" min="1" value="10" aria-label="Tekrar"><input type="number" min="0" step="0.5" placeholder="kg" aria-label="Ağırlık">
      <button type="button" class="btn ghost sm" aria-label="Hareketi kaldır">Kaldır</button>`;
    $("button", row).addEventListener("click", () => row.remove());
    exList.append(row);
  };
  addEx("Squat");
  $("#add-ex").addEventListener("click", () => addEx());

  onSubmit($("#wform"), async (f) => {
    const exercises = $$(".ex-row", exList).map((r) => {
      const [n, s, rep, kg] = $$("input", r).map((i) => i.value);
      return { name: n.trim(), sets: Number(s) || 3, reps: Number(rep) || 10, weight_kg: num(kg) };
    }).filter((e) => e.name);
    await api("/workouts", { method: "POST", body: { client_id: id, workout_date: f.workout_date, title: f.title, notes: f.notes || null, exercises } });
    toast("Antrenman kaydedildi");
    reload();
  });

  if (isAdmin && $("#sell")) {
    onSubmit($("#sell"), async (f) => {
      const m = await api("/memberships", { method: "POST", body: { user_id: id, package_id: Number(f.package_id), price_paid: num(f.price_paid) } });
      toast(`Satış kaydedildi. Yeni bitiş: ${fmtDate(m.end_date, { day: "numeric", month: "long", year: "numeric" })}`);
      reload();
    });
    const sel = $("#sell select");
    sel.addEventListener("change", () => ($("#sell input").placeholder = sel.selectedOptions[0].dataset.price));
  }
  if (isAdmin) {
    onSubmit($("#assign"), async (f) => {
      await api(`/users/${id}/trainer`, { method: "PATCH", body: { trainer_id: num(f.trainer_id) } });
      toast("PT ataması kaydedildi");
    });
  }
}

async function viewHome(v) {
  const [status, metab, water, workouts, pkgs, supplements] = await Promise.all([
    api("/memberships/status"),
    optional(api("/users/me/metabolism")),
    api("/water"),
    api("/workouts"),
    api("/packages"),
    api("/supplements"),
  ]);
  const firstName = me.full_name.split(" ")[0];

  v.innerHTML = `
  <header class="page-head"><div><h1>Merhaba ${esc(firstName)}</h1><p class="sub">${new Date().toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" })}</p></div></header>
  <div class="grid2">
    <section class="panel"><h2>Salon girişi</h2>
      <div class="qr-card" style="margin-top:14px">
        ${plate(status)}
        ${status.active ? `<div><div class="qr-box" id="qr"></div><div class="qr-timer"><div id="qr-bar" style="width:100%"></div></div>
          <p class="small muted" style="margin-top:8px">Kod her dakika yenilenir.</p>
          <button class="btn ghost sm" id="copy-qr" style="margin-top:8px">Kodu kopyala</button></div>`
        : `<div style="max-width:30ch"><p><strong>Üyeliğin sona erdi.</strong></p><p class="muted" style="margin-top:6px">Turnikeden geçebilmek için resepsiyondan paketini yenile.</p></div>`}
      </div>
    </section>
    <section class="panel"><div class="panel-head"><h2>Bugün içtiğin su</h2></div>
      <div class="water-level"><span class="num">${(water.total_ml / 1000).toLocaleString("tr-TR")}</span><span class="muted">${water.target_ml ? "/ " + (water.target_ml / 1000).toLocaleString("tr-TR") + " L" : "L"}</span></div>
      <div class="bar-track" style="height:14px"><div class="bar-fill" style="width:${water.target_ml ? Math.min((water.total_ml / water.target_ml) * 100, 100) : 0}%"></div></div>
      <div class="form-row" style="margin-top:16px">${[200, 330, 500].map((ml) => `<button class="btn ghost" data-water="${ml}">+${ml} ml</button>`).join("")}</div>
    </section>
    <section class="panel span2"><div class="panel-head"><h2>Metabolizman</h2><a href="#/profil" class="small">Profili düzenle</a></div>
      ${metab ? metabolismFigures(metab) + `<p class="small muted" style="margin-top:14px">BMR Mifflin-St Jeor formülüyle, günlük harcama aktivite seviyene göre hesaplandı.</p>`
      : `<p class="empty">Hesaplama için profilinde cinsiyet, doğum tarihi ve boy, ayrıca en az bir kilo kaydı gerekiyor.</p>
         <div class="form-row"><a class="btn" href="#/profil">Profilini tamamla</a><a class="btn ghost" href="#/takip">Kilo gir</a></div>`}
    </section>
    <section class="panel"><div class="panel-head"><h2>Bugünkü antrenman</h2><a href="#/antrenman" class="small">Tüm program</a></div>
      ${workouts.length ? workouts.map((w) => workoutBlock(w, { canComplete: true })).join("") : `<p class="empty">Bugün için antrenman planlanmamış.</p>`}
    </section>
    <section class="panel"><div class="panel-head"><h2>Takviyelerim</h2><button class="btn ghost sm" id="my-pdf">Aylık karnem (PDF)</button></div>
      ${supplements.length ? `<div class="table-wrap"><table><tbody>${supplements.map((s) => `
        <tr><td><strong>${esc(s.name)}</strong> <span class="muted small">${esc(s.dose || "")}</span>
          <div class="small muted">${s.reminder_times.join(", ") || "hatırlatma yok"} · bugün ${s.taken_today} kez</div></td>
        <td><span class="chip ${s.low_stock ? "yellow" : "green"}">${s.servings_left} servis</span></td>
        <td class="r"><button class="btn sm" data-take="${s.id}">Aldım</button></td></tr>`).join("")}</tbody></table></div>`
      : `<p class="empty">Takviye eklemek ve hatırlatma almak için mobil uygulamayı kullan.</p>`}
    </section>
    <section class="panel"><h2>Salon paketleri</h2>
      <div class="table-wrap"><table><tbody>${pkgs.map((p) => `<tr><td>${esc(p.name)}<div class="small muted">${esc(p.description || "")}</div></td><td class="r num">${tl(p.price)}</td></tr>`).join("")}</tbody></table></div>
    </section>
  </div>`;

  $$("[data-water]", v).forEach((b) => b.addEventListener("click", async () => {
    try { await api("/water", { method: "POST", body: { amount_ml: Number(b.dataset.water) } }); viewHome(v); }
    catch (e) { toast(e.message, true); }
  }));
  bindWorkoutActions(v, () => viewHome(v));
  $("#my-pdf").addEventListener("click", () => openReport());
  $$("[data-take]", v).forEach((b) => b.addEventListener("click", async () => {
    try { const s = await api(`/supplements/${b.dataset.take}/take`, { method: "POST" }); toast(`${s.name} alındı · kutuda ${s.servings_left} servis`); viewHome(v); }
    catch (e) { toast(e.message, true); }
  }));
  if (status.active) startQr();
}

async function startQr() {
  let current = "";
  let expiresAt = 0;
  let lifetime = 60;
  const refresh = async () => {
    const box = $("#qr");
    if (!box) return;
    const t = await api("/checkin/qr-token");
    current = t.token;
    lifetime = t.expires_in;
    expiresAt = Date.now() + t.expires_in * 1000;
    box.innerHTML = "";
    if (window.QRCode) new QRCode(box, { text: t.token, width: 176, height: 176, correctLevel: QRCode.CorrectLevel.M });
    else box.innerHTML = `<p class="small" style="line-height:1.4;width:176px;color:#1d2025">QR kütüphanesi yüklenemedi (internet gerekiyor). Kodu kopyala butonunu kullan.</p>`;
  };
  $("#copy-qr").addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(current); toast("Kod kopyalandı. Turnike ekranına yapıştırabilirsin."); }
    catch { prompt("Kodu kopyala:", current); }
  });
  try { await refresh(); } catch (e) { toast(e.message, true); return; }
  timers.push(setInterval(async () => {
    const left = (expiresAt - Date.now()) / 1000;
    const bar = $("#qr-bar");
    if (bar) bar.style.width = Math.max((left / lifetime) * 100, 0) + "%";
    if (left < 8) { try { await refresh(); } catch { } }
  }, 1000));
}

async function viewTracking(v) {
  const [weights, summary, meals] = await Promise.all([api("/weights?days=30"), api("/meals/summary"), api("/meals")]);
  const lastW = weights.at(-1);

  v.innerHTML = `
  <header class="page-head"><div><h1>Kilo ve beslenme</h1><p class="sub">Günlük tartını ve öğünlerini kaydet; PT'in bunları görür.</p></div>
    <a class="btn" href="/panel/diyet/">Diyet defterini aç</a></header>
  <div class="grid2">
    <section class="panel"><h2>Bugünkü tartı</h2>
      <form id="wf" class="form-row" style="margin-top:4px"><label>Kilo (kg)<input name="weight_kg" type="number" step="0.1" min="20" max="400" required value="${lastW?.log_date === todayISO() ? lastW.weight_kg : ""}" placeholder="${lastW ? lastW.weight_kg : "72.5"}"></label>
        <button class="btn" type="submit">Kaydet</button><p class="err" style="width:100%"></p></form>
      <div style="margin-top:8px">${weightChart(weights)}</div>
    </section>
    <section class="panel"><div class="panel-head"><h2>Bugünkü makrolar</h2><span class="small muted">${summary.meal_count} öğün</span></div>${macroBars(summary)}</section>
    <section class="panel"><h2>Öğün ekle</h2>
      <form id="mf" class="stack" style="gap:14px;margin-top:4px">
        <label style="max-width:240px">Öğün<select name="meal_type">${options(LABELS.meal, mealGuess())}</select></label>
        <label>Ne yedin?<textarea name="description" rows="2" maxlength="500" placeholder="Örn. 2 yumurta, 1 dilim ekmek, 30 g beyaz peynir, 1 bardak çay"></textarea></label>
        <div class="form-row" style="align-items:center"><button type="button" class="btn ghost sm" id="calc">Kaloriyi hesapla</button>
          <span class="small muted" id="calc-status">Yazdıkça kalori ve makrolar kendiliğinden hesaplanır. Miktar yazarsan (2 yumurta, 150 g tavuk) sonuç daha doğru olur.</span></div>
        <div id="calc-result" aria-live="polite"></div>
        <div class="form-grid"><label>Kalori<input name="calories" type="number" min="0" placeholder="otomatik"></label><label>Protein (g)<input name="protein_g" type="number" min="0" step="0.1" value="0"></label>
          <label>Karb. (g)<input name="carbs_g" type="number" min="0" step="0.1" value="0"></label><label>Yağ (g)<input name="fat_g" type="number" min="0" step="0.1" value="0"></label></div>
        <p class="err"></p>
        <div class="form-row"><button class="btn" type="submit">Öğünü kaydet</button>
          <label class="btn ghost" style="display:inline-flex;color:var(--ink)">Fotoğraf yükle<input type="file" id="photo" accept="image/jpeg,image/png,image/webp" hidden></label></div>
        <p class="small muted">Tabağın fotoğrafını yükle: yapay zeka yiyecekleri tanır ve kalori ile makroları doldurur.</p>
      </form>
    </section>
    <section class="panel"><h2>Bugün yediklerin</h2>${mealList(meals, true)}</section>
  </div>`;

  onSubmit($("#wf"), async (f) => {
    await api("/weights", { method: "POST", body: { weight_kg: Number(f.weight_kg) } });
    toast("Kilo kaydedildi");
    viewTracking(v);
  });
  const calc = bindMealCalculator($("#mf"));
  onSubmit($("#mf"), async (f) => {
    const description = (f.description || "").trim() || null;
    if (f.calories === "" && !description) throw new Error("Ne yediğini yaz ya da kaloriyi gir.");
    const body = { meal_type: f.meal_type, description, calories: num(f.calories), protein_g: Number(f.protein_g) || 0, carbs_g: Number(f.carbs_g) || 0, fat_g: Number(f.fat_g) || 0 };
    if (body.calories != null && calc.analysis()) body.analysis = calc.analysis();
    const m = await api("/meals", { method: "POST", body });
    toast(`Öğün kaydedildi: ${Math.round(m.calories)} kcal`);
    viewTracking(v);
  });
  $("#photo").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const fd = new FormData();
    fd.append("photo", file);
    fd.append("meal_type", $("#mf").meal_type.value);
    if ($("#mf").description.value) fd.append("description", $("#mf").description.value);
    toast("Fotoğraf analiz ediliyor…");
    try {
      const m = await api("/meals/photo", { method: "POST", body: fd });
      toast(m.source === "ai" ? `${m.description}: ${Math.round(m.calories)} kcal` : (m.ai_detail?.error || "Fotoğraf yüklendi"), !!m.ai_detail?.error);
      viewTracking(v);
    }
    catch (ex) { toast(ex.message, true); }
  });
  $$("[data-del-meal]", v).forEach((b) => b.addEventListener("click", async () => {
    try { await api(`/meals/${b.dataset.delMeal}`, { method: "DELETE" }); toast("Öğün silindi"); viewTracking(v); }
    catch (e) { toast(e.message, true); }
  }));
}

const PROVIDER_LABEL = { yerel: "FitAI besin tablosu", gemini: "Yapay zeka (Gemini)", claude: "Yapay zeka (Claude)" };

function bindMealCalculator(form) {
  const desc = form.description;
  const fields = ["calories", "protein_g", "carbs_g", "fat_g"].map((n) => form[n]);
  const status = $("#calc-status", form);
  const out = $("#calc-result", form);
  let analysis = null;
  let seq = 0;
  let timer = null;

  const show = (r) => {
    analysis = r;
    const t = r.totals;
    form.calories.value = Math.round(t.calories);
    form.protein_g.value = t.protein_g;
    form.carbs_g.value = t.carbs_g;
    form.fat_g.value = t.fat_g;
    out.innerHTML = r.items.length || r.unmatched?.length ? `
      <div class="calc-box">
        ${r.items.length ? `<ul class="calc-list">${r.items.map((i) => `<li><span>${esc(i.name)}</span><span class="num">${Math.round(i.calories)} kcal</span></li>`).join("")}
          <li class="total"><span>Toplam</span><span class="num">${Math.round(t.calories)} kcal · P ${n1(t.protein_g)} · K ${n1(t.carbs_g)} · Y ${n1(t.fat_g)} g</span></li></ul>` : ""}
        ${r.unmatched?.length ? `<p class="small warn">Tanınmayan: ${esc(r.unmatched.join(", "))}. Bunların değerini elle ekleyebilirsin.</p>` : ""}
        ${r.note && !r.unmatched?.length ? `<p class="small muted">${esc(r.note)}</p>` : ""}
        <p class="small muted">Kaynak: ${esc(PROVIDER_LABEL[r.provider] || r.provider)}${r.confidence ? " · güven " + esc(r.confidence) : ""}</p>
      </div>` : "";
    status.textContent = r.items.length ? "Değerler dolduruldu; istersen düzeltip kaydet." : "Yazdığını tanıyamadım. Miktarla birlikte yaz ya da değerleri elle gir.";
  };
  const clear = () => {
    analysis = null;
    out.innerHTML = "";
    fields.forEach((el) => (el.value = el.name === "calories" ? "" : 0));
  };
  const run = async (quick) => {
    const text = desc.value.trim();
    const mine = ++seq;
    if (text.length < 2) { if (analysis) clear(); return; }
    status.textContent = "Hesaplanıyor…";
    try {
      const r = await api("/ai/food-text", { method: "POST", body: { text, quick } });
      if (mine === seq && document.body.contains(form)) show(r);
    } catch (e) {
      if (mine === seq) status.textContent = e.message;
    }
  };
  desc.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => run(true), 450); });
  $("#calc", form).addEventListener("click", () => { clearTimeout(timer); run(false); });
  fields.forEach((el) => el.addEventListener("input", () => {
    if (!analysis) return;
    analysis = null;
    status.textContent = "Değerleri elle düzenledin; kaydedince bu değerler kullanılır.";
  }));
  return { analysis: () => analysis };
}

function mealGuess() {
  const h = new Date().getHours();
  if (h < 11) return "breakfast";
  if (h < 15) return "lunch";
  if (h >= 18 && h < 22) return "dinner";
  return "snack";
}

async function viewMyWorkouts(v) {
  const workouts = await api("/workouts?days=14");
  v.innerHTML = `
  <header class="page-head"><div><h1>Antrenmanım</h1><p class="sub">PT'inin önümüzdeki 14 gün için hazırladığı program.</p></div></header>
  <section class="panel">${workouts.length ? workouts.map((w) => workoutBlock(w, { canComplete: true })).join("") : `<p class="empty">Henüz programın yok. PT'in antrenman tanımladığında burada görünecek.</p>`}</section>`;
  bindWorkoutActions(v, () => viewMyWorkouts(v));
}

async function viewProfile(v) {
  me = await api("/users/me");
  v.innerHTML = `
  <header class="page-head"><div><h1>Profilim</h1><p class="sub">Metabolizma hesabı bu bilgilerle yapılır.</p></div></header>
  <section class="panel" style="max-width:720px">
    <div class="profile-photo">${avatar(me, "lg")}
      <div><strong>Profil fotoğrafı</strong><p class="small muted">Turnikede ve PT'nin ekranında seni tanımaya yardımcı olur.</p>
        <button type="button" class="btn ghost sm" id="change-photo">${me.photo_path ? "Fotoğrafı değiştir" : "Fotoğraf ekle"}</button></div></div>
    <form id="pf" class="stack" style="gap:16px">
      <div class="form-grid"><label>Ad soyad<input name="full_name" required value="${esc(me.full_name)}"></label><label>Telefon<input name="phone" value="${esc(me.phone || "")}"></label></div>
      <div class="form-grid"><label>Cinsiyet<select name="gender"><option value="">Seç</option>${options(LABELS.gender, me.gender)}</select></label>
        <label>Doğum tarihi<input type="date" name="birth_date" value="${me.birth_date || ""}"></label>
        <label>Boy (cm)<input type="number" name="height_cm" min="100" max="250" value="${me.height_cm ?? ""}"></label></div>
      <div class="form-grid"><label>Haftalık aktivite<select name="activity_level">${options(LABELS.activity, me.activity_level)}</select></label>
        <label>Hedefin<select name="goal">${options(LABELS.goal, me.goal)}</select></label></div>
      <p class="err"></p>
      <div><button class="btn" type="submit">Profili kaydet</button></div>
    </form>
  </section>`;
  $("#change-photo").addEventListener("click", () => photoDialog(me, "me", (u) => { me = u; refreshMe(); viewProfile(v); }));
  onSubmit($("#pf"), async (f) => {
    const body = { full_name: f.full_name, phone: f.phone || null, activity_level: f.activity_level, goal: f.goal };
    if (f.gender) body.gender = f.gender;
    if (f.birth_date) body.birth_date = f.birth_date;
    if (f.height_cm) body.height_cm = Number(f.height_cm);
    me = await api("/users/me", { method: "PATCH", body });
    refreshMe();
    toast("Profil kaydedildi");
    location.hash = "#/ana";
  });
}
