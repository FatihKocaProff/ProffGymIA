"""Token imza anahtarı (FITAI_SECRET_KEY) üretimi.

Kurulumda bir kez çalışır:  python -m app.anahtar   (baslat.bat / baslat.sh bunu kendisi yapar)

Neden sunucu açılırken değil de burada? Sunucu birden fazla süreçle çalıştırılırsa
(uvicorn --workers 4) her süreç kendi anahtarını üretirdi; bir süreçten alınan token
diğerinde geçersiz olur, kullanıcılar rastgele oturumdan düşerdi. Anahtar artık yalnızca
burada üretilir; sunucu zayıf veya eksik anahtarla hiç açılmaz (bkz. config.py).
"""
import secrets
from pathlib import Path

MIN_LENGTH = 32
_WEAK = {"gelistirme-anahtari-degistir", "uzun-rastgele-bir-anahtar"}
_KEY = "FITAI_SECRET_KEY"
ENV_PATH = Path(__file__).resolve().parent.parent / ".env"


def guclu_mu(value: str | None) -> bool:
    value = (value or "").strip()
    return len(value) >= MIN_LENGTH and value not in _WEAK


def _clean(value: str) -> str:
    return value.strip().strip('"').strip("'")


def env_anahtari_hazirla(env_path: Path = ENV_PATH) -> bool:
    """.env içindeki anahtar eksik veya zayıfsa güçlü bir anahtar yazar. Yeni yazdıysa True döner."""
    lines = env_path.read_text(encoding="utf-8-sig").splitlines() if env_path.exists() else []
    index = next((i for i, ln in enumerate(lines) if ln.strip().startswith(f"{_KEY}=")), None)
    if index is not None and guclu_mu(_clean(lines[index].split("=", 1)[1])):
        return False
    new_line = f"{_KEY}={secrets.token_urlsafe(48)}"
    if index is None:
        lines.append(new_line)
    else:
        lines[index] = new_line
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return True


if __name__ == "__main__":
    if env_anahtari_hazirla():
        print("Yeni FITAI_SECRET_KEY üretildi ve .env dosyasına yazıldı.")
    else:
        print("FITAI_SECRET_KEY hazır.")
