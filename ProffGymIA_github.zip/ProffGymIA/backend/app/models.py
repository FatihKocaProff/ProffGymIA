"""Veritabanı tabloları.

Tablolar: users, packages, memberships, weight_logs, water_logs, meals,
workouts, workout_exercises, check_ins, form_sessions, supplements, supplement_intakes, diet_diaries
"""
import enum
from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


class Role(str, enum.Enum):
    member = "member"
    trainer = "trainer"
    admin = "admin"


class Gender(str, enum.Enum):
    male = "male"
    female = "female"


class ActivityLevel(str, enum.Enum):
    sedentary = "sedentary"
    light = "light"
    moderate = "moderate"
    active = "active"
    very_active = "very_active"


class Goal(str, enum.Enum):
    lose = "lose"
    maintain = "maintain"
    gain = "gain"


class MealType(str, enum.Enum):
    breakfast = "breakfast"
    lunch = "lunch"
    dinner = "dinner"
    snack = "snack"


class CheckInMethod(str, enum.Enum):
    qr = "qr"
    face = "face"
    manual = "manual"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    full_name: Mapped[str] = mapped_column(String(120))
    phone: Mapped[str | None] = mapped_column(String(30))
    role: Mapped[Role] = mapped_column(Enum(Role), default=Role.member)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    gender: Mapped[Gender | None] = mapped_column(Enum(Gender))
    birth_date: Mapped[date | None] = mapped_column(Date)
    height_cm: Mapped[float | None] = mapped_column(Float)
    activity_level: Mapped[ActivityLevel] = mapped_column(
        Enum(ActivityLevel), default=ActivityLevel.sedentary
    )
    goal: Mapped[Goal] = mapped_column(Enum(Goal), default=Goal.maintain)

    trainer_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))

    face_encoding: Mapped[str | None] = mapped_column(Text)

    photo_path: Mapped[str | None] = mapped_column(String(500))

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)

    trainer: Mapped["User | None"] = relationship(remote_side="User.id", back_populates="clients")
    clients: Mapped[list["User"]] = relationship(back_populates="trainer")
    memberships: Mapped[list["Membership"]] = relationship(
        back_populates="user",
        cascade="all, delete-orphan",
        order_by="Membership.end_date",
        foreign_keys="Membership.user_id",
    )


class Package(Base):
    """Salonun sattığı üyelik paketleri (Aylık, 3 Aylık, Yıllık vb.)."""

    __tablename__ = "packages"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    duration_days: Mapped[int] = mapped_column(Integer)
    price: Mapped[float] = mapped_column(Float)
    description: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class Membership(Base):
    """Bir üyeye yapılmış üyelik satışı. Uzatmalar yeni kayıt olarak eklenir (satış geçmişi korunur)."""

    __tablename__ = "memberships"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    package_id: Mapped[int | None] = mapped_column(ForeignKey("packages.id"))
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    price_paid: Mapped[float] = mapped_column(Float, default=0)
    sold_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)

    user: Mapped[User] = relationship(back_populates="memberships", foreign_keys=[user_id])
    package: Mapped[Package | None] = relationship()


class WeightLog(Base):
    __tablename__ = "weight_logs"
    __table_args__ = (UniqueConstraint("user_id", "log_date", name="uq_weight_user_date"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    log_date: Mapped[date] = mapped_column(Date)
    weight_kg: Mapped[float] = mapped_column(Float)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class WaterLog(Base):
    """Her bardak/şişe ayrı kayıt; günlük toplam sorguyla hesaplanır."""

    __tablename__ = "water_logs"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    log_date: Mapped[date] = mapped_column(Date, index=True)
    amount_ml: Mapped[int] = mapped_column(Integer)
    diary_ref: Mapped[str | None] = mapped_column(String(40))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class Meal(Base):
    __tablename__ = "meals"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    meal_date: Mapped[date] = mapped_column(Date, index=True)
    meal_type: Mapped[MealType] = mapped_column(Enum(MealType), default=MealType.snack)
    description: Mapped[str | None] = mapped_column(Text)
    photo_path: Mapped[str | None] = mapped_column(String(500))
    calories: Mapped[float] = mapped_column(Float, default=0)
    protein_g: Mapped[float] = mapped_column(Float, default=0)
    carbs_g: Mapped[float] = mapped_column(Float, default=0)
    fat_g: Mapped[float] = mapped_column(Float, default=0)
    source: Mapped[str] = mapped_column(String(20), default="manual")
    ai_detail: Mapped[str | None] = mapped_column(Text)
    diary_ref: Mapped[str | None] = mapped_column(String(40))
    diary_data: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class DietDiary(Base):
    """Kepçe diyet defterinin öğün/su/kilo dışındaki verisi (JSON): profil, hedef geçmişi,
    favoriler, kullanıcının eklediği ürünler, görünüm ayarları, açık rıza kaydı."""

    __tablename__ = "diet_diaries"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True, index=True)
    data: Mapped[str] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now)


class Workout(Base):
    """PT'nin danışanına belirli bir gün için tanımladığı antrenman."""

    __tablename__ = "workouts"

    id: Mapped[int] = mapped_column(primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    trainer_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    workout_date: Mapped[date] = mapped_column(Date, index=True)
    title: Mapped[str] = mapped_column(String(120))
    notes: Mapped[str | None] = mapped_column(Text)
    completed: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)

    exercises: Mapped[list["WorkoutExercise"]] = relationship(
        back_populates="workout", cascade="all, delete-orphan", order_by="WorkoutExercise.position"
    )


class WorkoutExercise(Base):
    __tablename__ = "workout_exercises"

    id: Mapped[int] = mapped_column(primary_key=True)
    workout_id: Mapped[int] = mapped_column(ForeignKey("workouts.id"), index=True)
    position: Mapped[int] = mapped_column(Integer, default=0)
    name: Mapped[str] = mapped_column(String(120))
    sets: Mapped[int] = mapped_column(Integer, default=3)
    reps: Mapped[int] = mapped_column(Integer, default=10)
    weight_kg: Mapped[float | None] = mapped_column(Float)
    rest_seconds: Mapped[int | None] = mapped_column(Integer)

    workout: Mapped[Workout] = relationship(back_populates="exercises")


class CheckIn(Base):
    """Turnike geçiş kaydı (izin verilen ve reddedilen tüm denemeler)."""

    __tablename__ = "check_ins"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True)
    method: Mapped[CheckInMethod] = mapped_column(Enum(CheckInMethod))
    granted: Mapped[bool] = mapped_column(Boolean)
    reason: Mapped[str | None] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class FormSession(Base):
    """Kamera karşısında yapılan bir set: kaç tekrar, kaçı doğru formda, en sık hata."""

    __tablename__ = "form_sessions"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    recorded_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    exercise: Mapped[str] = mapped_column(String(40))
    reps: Mapped[int] = mapped_column(Integer, default=0)
    good_reps: Mapped[int] = mapped_column(Integer, default=0)
    score: Mapped[float] = mapped_column(Float, default=0)
    duration_seconds: Mapped[int] = mapped_column(Integer, default=0)
    issues: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(20), default="mobile")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class Supplement(Base):
    """Protein tozu, kreatin vb. Hatırlatma saatleri ve kutuda kalan servis."""

    __tablename__ = "supplements"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    name: Mapped[str] = mapped_column(String(80))
    dose: Mapped[str | None] = mapped_column(String(80))
    reminder_times: Mapped[str] = mapped_column(String(120), default="")
    servings_left: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class SupplementIntake(Base):
    __tablename__ = "supplement_intakes"

    id: Mapped[int] = mapped_column(primary_key=True)
    supplement_id: Mapped[int] = mapped_column(ForeignKey("supplements.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    taken_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
