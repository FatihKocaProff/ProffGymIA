"""Şifre hash'leme ve JWT token işlemleri."""
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from .config import ACCESS_TOKEN_EXPIRE_MINUTES, ALGORITHM, QR_TOKEN_SECONDS, SECRET_KEY


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except ValueError:
        return False


def _encode(payload: dict, lifetime: timedelta) -> str:
    now = datetime.now(timezone.utc)
    data = {**payload, "iat": now, "exp": now + lifetime}
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)


def create_access_token(user_id: int, role: str) -> str:
    return _encode(
        {"sub": str(user_id), "role": role, "type": "access"},
        timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
    )


def create_qr_token(user_id: int) -> str:
    """Turnike için kısa ömürlü, imzalı QR içeriği. Uygulama her ~50 sn'de yeniler."""
    return _encode({"sub": str(user_id), "type": "qr"}, timedelta(seconds=QR_TOKEN_SECONDS))


def decode_token(token: str, expected_type: str) -> int | None:
    """Geçerliyse kullanıcı id'sini, değilse None döner."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.PyJWTError:
        return None
    if payload.get("type") != expected_type:
        return None
    try:
        return int(payload["sub"])
    except (KeyError, ValueError):
        return None


UPLOAD_LINK_DAYS = 2


def _upload_sig(path: str, exp: int) -> str:
    import hashlib
    import hmac

    msg = f"upload:{path}:{exp}".encode("utf-8")
    return hmac.new(SECRET_KEY.encode("utf-8"), msg, hashlib.sha256).hexdigest()[:32]


def sign_upload_path(path: str | None) -> str | None:
    if not path or "?" in path:
        return path
    day = 86400
    exp = (int(datetime.now(timezone.utc).timestamp()) // day + UPLOAD_LINK_DAYS) * day
    return f"{path}?exp={exp}&sig={_upload_sig(path, exp)}"


def verify_upload_path(path: str, exp: int | None, sig: str | None) -> bool:
    import hmac

    if exp is None or not sig or exp < datetime.now(timezone.utc).timestamp():
        return False
    return hmac.compare_digest(_upload_sig(path, exp), sig)
