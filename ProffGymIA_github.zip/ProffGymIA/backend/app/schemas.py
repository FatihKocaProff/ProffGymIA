"""API istek ve yanıt şemaları (Pydantic). Swagger dokümantasyonu bunlardan üretilir."""
import json
import re
from datetime import date, datetime

from typing import Annotated

from pydantic import AfterValidator, BaseModel, ConfigDict, EmailStr, Field, field_validator

from .models import ActivityLevel, CheckInMethod, Gender, Goal, MealType, Role
from .security import sign_upload_path

SignedUploadPath = Annotated[str | None, AfterValidator(sign_upload_path)]


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6, max_length=72)
    full_name: str = Field(min_length=2, max_length=120)
    phone: str | None = None


class SetupStatusOut(BaseModel):
    """Kayıt ekranı için: veritabanında henüz salon yöneticisi yoksa ilk kayıt yönetici olur."""

    needs_admin: bool


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: Role
    user_id: int


class ProfileUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=2, max_length=120)
    phone: str | None = None
    gender: Gender | None = None
    birth_date: date | None = None
    height_cm: float | None = Field(default=None, gt=50, lt=260)
    activity_level: ActivityLevel | None = None
    goal: Goal | None = None


class UserOut(ORMModel):
    id: int
    email: EmailStr
    full_name: str
    phone: str | None
    role: Role
    is_active: bool
    gender: Gender | None
    birth_date: date | None
    height_cm: float | None
    activity_level: ActivityLevel
    goal: Goal
    trainer_id: int | None
    photo_path: SignedUploadPath = Field(default=None, description="Profil fotoğrafı: /uploads/<photo_path> (imzalı)")
    created_at: datetime | None = None


class StaffUserCreate(RegisterIn):
    """Admin'in masaüstü panelden üye veya PT kaydetmesi."""

    role: Role = Role.member
    trainer_id: int | None = None


class AssignTrainerIn(BaseModel):
    trainer_id: int | None


class RoleUpdate(BaseModel):
    """Yönetici bir üyeyi personal trainer yapar veya PT'yi tekrar üye yapar."""

    role: Role


class MetabolismOut(BaseModel):
    age: int
    weight_kg: float
    height_cm: float
    bmr: int = Field(description="Bazal metabolizma hızı (Mifflin-St Jeor), kcal/gün")
    tdee: int = Field(description="Aktivite dahil günlük enerji harcaması, kcal/gün")
    target_calories: int
    protein_g: int
    fat_g: int
    carbs_g: int
    water_ml: int
    bmi: float
    bmi_category: str


class PackageIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    duration_days: int = Field(gt=0, le=3660)
    price: float = Field(ge=0)
    description: str | None = None
    is_active: bool = True


class PackageUpdate(BaseModel):
    name: str | None = None
    duration_days: int | None = Field(default=None, gt=0, le=3660)
    price: float | None = Field(default=None, ge=0)
    description: str | None = None
    is_active: bool | None = None


class PackageOut(ORMModel):
    id: int
    name: str
    duration_days: int
    price: float
    description: str | None
    is_active: bool


class MembershipSellIn(BaseModel):
    user_id: int
    package_id: int
    price_paid: float | None = Field(default=None, ge=0, description="Boşsa paket fiyatı kullanılır (indirim için doldur)")


class MembershipOut(ORMModel):
    id: int
    user_id: int
    package_id: int | None
    start_date: date
    end_date: date
    price_paid: float
    created_at: datetime | None = None


class MembershipStatusOut(BaseModel):
    active: bool
    end_date: date | None
    remaining_days: int
    total_memberships: int


class WeightIn(BaseModel):
    weight_kg: float = Field(gt=20, lt=400)
    log_date: date | None = Field(default=None, description="Boşsa bugün")


class WeightOut(ORMModel):
    id: int
    log_date: date
    weight_kg: float


class WaterIn(BaseModel):
    amount_ml: int = Field(gt=0, le=5000)
    log_date: date | None = None


class WaterDayOut(BaseModel):
    log_date: date
    total_ml: int
    target_ml: int | None
    entries: int


class MealIn(BaseModel):
    meal_type: MealType = MealType.snack
    meal_date: date | None = None
    description: str | None = Field(default=None, max_length=500)
    calories: float | None = Field(
        default=None, ge=0, le=10000,
        description="Boş bırakılırsa 'description' metninden otomatik hesaplanır (ör. '2 yumurta, 1 dilim ekmek')",
    )
    protein_g: float = Field(default=0, ge=0, le=1000)
    carbs_g: float = Field(default=0, ge=0, le=1000)
    fat_g: float = Field(default=0, ge=0, le=1000)
    analysis: dict | None = Field(
        default=None, description="POST /ai/food-text sonucu; değerler oradan geldiyse dökümüyle birlikte saklanır"
    )


class MealOut(ORMModel):
    id: int
    user_id: int
    meal_date: date
    meal_type: MealType
    description: str | None
    photo_path: SignedUploadPath
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float
    source: str
    ai_detail: dict | None = Field(default=None, description="Yapay zeka analizi: yiyecekler, vitaminler, güven, not")
    created_at: datetime | None = None

    @field_validator("ai_detail", mode="before")
    @classmethod
    def _parse_ai(cls, v):
        if isinstance(v, str):
            try:
                return json.loads(v)
            except json.JSONDecodeError:
                return None
        return v


class NutritionSummaryOut(BaseModel):
    day: date
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float
    meal_count: int
    target_calories: int | None
    target_protein_g: int | None
    target_carbs_g: int | None
    target_fat_g: int | None


class ExerciseIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    sets: int = Field(default=3, gt=0, le=50)
    reps: int = Field(default=10, gt=0, le=500)
    weight_kg: float | None = Field(default=None, ge=0)
    rest_seconds: int | None = Field(default=None, ge=0)


class ExerciseOut(ORMModel):
    id: int
    position: int
    name: str
    sets: int
    reps: int
    weight_kg: float | None
    rest_seconds: int | None


class WorkoutIn(BaseModel):
    client_id: int
    workout_date: date
    title: str = Field(min_length=1, max_length=120)
    notes: str | None = None
    exercises: list[ExerciseIn] = []


class WorkoutOut(ORMModel):
    id: int
    client_id: int
    trainer_id: int | None
    workout_date: date
    title: str
    notes: str | None
    completed: bool
    exercises: list[ExerciseOut]


class QRTokenOut(BaseModel):
    token: str
    expires_in: int


class QRCheckIn(BaseModel):
    token: str


class CheckInResult(BaseModel):
    granted: bool
    reason: str
    user_id: int | None = None
    full_name: str | None = None
    remaining_days: int | None = None
    face_found: bool | None = None
    face_score: float | None = None
    face_box: list[int] | None = None


class CheckInOut(ORMModel):
    id: int
    user_id: int | None
    full_name: str | None = None
    method: CheckInMethod
    granted: bool
    reason: str | None
    created_at: datetime | None


class StatsOut(BaseModel):
    total_members: int
    active_members: int
    expiring_soon: int
    today_checkins: int
    denied_today: int
    month_revenue: float


class MemberOverviewOut(BaseModel):
    id: int
    full_name: str
    email: str
    phone: str | None
    is_active: bool
    goal: Goal
    trainer_id: int | None
    trainer_name: str | None
    active: bool
    remaining_days: int
    end_date: date | None
    last_weight: float | None
    photo_path: SignedUploadPath = None


class FoodItemOut(BaseModel):
    name: str
    portion_g: float
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float


class FoodAnalysisOut(BaseModel):
    items: list[FoodItemOut]
    totals: dict[str, float]
    fiber_g: float
    vitamins: list[str]
    confidence: str
    consistent: bool
    note: str
    provider: str
    model: str
    unmatched: list[str] = Field(default_factory=list, description="Yazılı öğünde tanınamayan kısımlar")


class FoodTextIn(BaseModel):
    text: str = Field(min_length=1, max_length=500, description="Ör. '2 yumurta, 1 dilim ekmek, 1 bardak çay'")
    quick: bool = Field(default=False, description="Yazarken anlık önizleme: her zaman yerel besin tablosu (hızlı)")


class AIStatusOut(BaseModel):
    food_provider: str
    food_model: str
    face_models_ready: bool


class FaceEnrollOut(BaseModel):
    user_id: int
    enrolled: bool
    detection_score: float | None = None


class FormSessionIn(BaseModel):
    user_id: int | None = Field(default=None, description="PT masaüstünden danışan adına kaydederken")
    exercise: str = Field(min_length=2, max_length=40)
    reps: int = Field(ge=0, le=1000)
    good_reps: int = Field(ge=0, le=1000)
    duration_seconds: int = Field(default=0, ge=0, le=86400)
    issues: dict[str, int] = Field(default_factory=dict, description='{"Sırtını dik tut": 3}')
    source: str = Field(default="mobile", max_length=20)


class FormSessionOut(ORMModel):
    id: int
    user_id: int
    exercise: str
    reps: int
    good_reps: int
    score: float
    duration_seconds: int
    issues: dict[str, int] | None
    source: str
    created_at: datetime | None

    @field_validator("issues", mode="before")
    @classmethod
    def _parse_issues(cls, v):
        if isinstance(v, str):
            try:
                return json.loads(v)
            except json.JSONDecodeError:
                return None
        return v


TIME_PATTERN = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def _validate_times(v: list[str] | None) -> list[str] | None:
    if v is None:
        return None
    clean = sorted({t.strip() for t in v if t and t.strip()})
    for t in clean:
        if not TIME_PATTERN.match(t):
            raise ValueError(f"Saat SS:DD biçiminde olmalı: {t}")
    return clean[:8]


class SupplementIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    dose: str | None = Field(default=None, max_length=80)
    reminder_times: list[str] = Field(default_factory=list, description='["08:00", "21:00"]')
    servings_left: int = Field(default=0, ge=0, le=10000)

    _check_times = field_validator("reminder_times")(classmethod(lambda cls, v: _validate_times(v)))


class SupplementUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=80)
    dose: str | None = None
    reminder_times: list[str] | None = None
    servings_left: int | None = Field(default=None, ge=0, le=10000)
    is_active: bool | None = None

    _check_times = field_validator("reminder_times")(classmethod(lambda cls, v: _validate_times(v)))


class SupplementOut(ORMModel):
    id: int
    name: str
    dose: str | None
    reminder_times: list[str]
    servings_left: int
    is_active: bool
    taken_today: int = 0
    low_stock: bool = False

    @field_validator("reminder_times", mode="before")
    @classmethod
    def _split(cls, v):
        if isinstance(v, str):
            return [t for t in v.split(",") if t]
        return v


class DiaryEntryIn(BaseModel):
    """Defterdeki bir kalem. Bilinmeyen alanlar (besin kimliği, porsiyon, miktar, vitaminler…) olduğu gibi saklanır."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str = Field(min_length=1, max_length=40)
    day: date = Field(alias="date")
    meal: MealType
    name: str = Field(default="", max_length=200)
    description: str | None = Field(default=None, max_length=500)
    kcal: float = Field(default=0, ge=0, le=10000)
    p: float = Field(default=0, ge=0, le=1000)
    c: float = Field(default=0, ge=0, le=1000)
    f: float = Field(default=0, ge=0, le=1000)
    deleted: bool = False


class DiaryWaterIn(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str = Field(min_length=1, max_length=40)
    day: date = Field(alias="date")
    ml: int = Field(gt=0, le=5000)
    deleted: bool = False


class DiaryWeightIn(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    day: date = Field(alias="date")
    kg: float = Field(ge=20, le=400)


class DiarySyncIn(BaseModel):
    """Defterde son gönderimden beri değişenler. meta: öğün/su/kilo dışındaki her şey."""

    meta: dict | None = None
    entries: list[DiaryEntryIn] = Field(default_factory=list, max_length=500)
    water: list[DiaryWaterIn] = Field(default_factory=list, max_length=500)
    weights: list[DiaryWeightIn] = Field(default_factory=list, max_length=500)
    apply_profile: bool = Field(default=False, description="Hedef yeniden hesaplandı: profil bilgilerini FitAI profiline de yaz")
