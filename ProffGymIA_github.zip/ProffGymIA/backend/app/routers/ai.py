"""Yapay zeka uçları: yemek fotoğrafı analizi ve yüz kaydı."""
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from .. import config
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import User
from ..schemas import AIStatusOut, FaceEnrollOut, FoodAnalysisOut, FoodTextIn
from ..services import face, food_ai
from .tracking import read_image

router = APIRouter(tags=["Yapay zeka"])


@router.get("/ai/status", response_model=AIStatusOut)
def ai_status(_: User = Depends(get_current_user)):
    """Hangi yapay zeka sağlayıcısının etkin olduğunu gösterir (panelde bilgi için)."""
    provider = food_ai.active_provider()
    model = {"gemini": config.GEMINI_MODEL, "claude": config.CLAUDE_MODEL}.get(provider, "demo")
    ready = all((config.MODELS_DIR / name).exists() for name in face.MODEL_URLS)
    return AIStatusOut(food_provider=provider, food_model=model, face_models_ready=ready)


@router.post("/ai/food", response_model=FoodAnalysisOut)
def analyze_food(photo: UploadFile = File(...), _: User = Depends(get_current_user)):
    """Fotoğrafı analiz eder ama öğün olarak KAYDETMEZ (önizleme için)."""
    data, mime, _ext = read_image(photo)
    try:
        return food_ai.analyze_food(data, mime)
    except food_ai.FoodAIError as exc:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(exc)) from exc


@router.post("/ai/food-text", response_model=FoodAnalysisOut)
def analyze_food_text(data: FoodTextIn, _: User = Depends(get_current_user)):
    """Yazılan öğünün kalori ve makrolarını hesaplar, KAYDETMEZ (öğün formundaki önizleme için).

    Ör. "2 yumurta, 1 dilim ekmek, 30 g beyaz peynir, 1 bardak çay". Yapay zeka anahtarı yoksa
    yerel besin tablosu kullanılır; tanınamayan kısımlar `unmatched` alanında döner.
    """
    return food_ai.analyze_text(data.text, quick=data.quick)


@router.post("/users/{user_id}/face", response_model=FaceEnrollOut, tags=["Kullanıcılar"])
def enroll_face(
    user_id: int,
    photo: UploadFile = File(...),
    _: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    """Üyenin yüzünü turnike için kaydeder. Fotoğrafta yalnızca bir yüz olmalı."""
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kullanıcı bulunamadı")
    data, _mime, _ext = read_image(photo)
    try:
        result = face.encode(data, require_single=True)
    except face.FaceError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc
    if result is None:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Fotoğrafta yüz bulunamadı. Kameraya önden ve aydınlık bir yerde bak.")
    user.face_encoding = face.to_json(result.vector)
    db.commit()
    return FaceEnrollOut(user_id=user.id, enrolled=True, detection_score=round(result.score, 3))


@router.delete("/users/{user_id}/face", response_model=FaceEnrollOut, tags=["Kullanıcılar"])
def delete_face(user_id: int, _: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kullanıcı bulunamadı")
    user.face_encoding = None
    db.commit()
    return FaceEnrollOut(user_id=user.id, enrolled=False)
