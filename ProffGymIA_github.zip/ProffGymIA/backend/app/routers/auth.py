import giris_siniri
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Role, User
from ..schemas import RegisterIn, SetupStatusOut, TokenOut, UserOut
from ..security import create_access_token, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["Giriş / Kayıt"])


def _has_admin(db: Session) -> bool:
    return db.scalar(select(User.id).where(User.role == Role.admin).limit(1)) is not None


def _create_user(db: Session, data: RegisterIn, role: Role) -> User:
    email = data.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status.HTTP_409_CONFLICT, "Bu e-posta zaten kayıtlı")
    user = User(
        email=email,
        password_hash=hash_password(data.password),
        full_name=data.full_name,
        phone=data.phone,
        role=role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(data: RegisterIn, db: Session = Depends(get_db)):
    """Mobil uygulama, masaüstü panel ve web panelinden kayıt. Rol her zaman 'member' olur.

    Salon yöneticisi dilediği üyeyi sonradan personal trainer yapar (PATCH /users/{id}/role).
    """
    return _create_user(db, data, Role.member)


@router.get("/setup", response_model=SetupStatusOut)
def setup_status(db: Session = Depends(get_db)):
    """Kayıt ekranı bunu sorar: hiç yönetici yoksa 'İlk kurulum' olarak yönetici hesabı açtırır."""
    return SetupStatusOut(needs_admin=not _has_admin(db))


@router.post("/setup-admin", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def setup_admin(data: RegisterIn, db: Session = Depends(get_db)):
    """İlk kurulum: veritabanında hiç salon yöneticisi yokken ilk yönetici hesabını açar. Sonrasında kapalıdır."""
    if _has_admin(db):
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Salon yöneticisi zaten var. Yeni hesaplar 'Kayıt ol' ile üye olarak açılır.",
        )
    return _create_user(db, data, Role.admin)


@router.post("/login", response_model=TokenOut)
def login(request: Request, form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Form alanları: username (= e-posta), password. Swagger'daki 'Authorize' butonu da bunu kullanır."""
    ip = request.client.host if request.client else None
    wait = giris_siniri.retry_after(ip, form.username)
    if wait:
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            f"Çok fazla hatalı deneme. {wait // 60 + 1} dakika sonra tekrar dene.",
            headers={"Retry-After": str(wait)},
        )
    user = db.scalar(select(User).where(User.email == form.username.lower()))
    if not user or not verify_password(form.password, user.password_hash):
        giris_siniri.record_failure(ip, form.username)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "E-posta veya şifre hatalı")
    giris_siniri.record_success(ip, form.username)
    if not user.is_active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Hesap pasif durumda")
    return TokenOut(
        access_token=create_access_token(user.id, user.role.value),
        role=user.role,
        user_id=user.id,
    )
