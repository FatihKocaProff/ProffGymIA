"""Takviye (supplement) takibi: hatırlatma saatleri ve kutuda kalan servis.

Hatırlatma bildirimlerini telefon kendisi planlar (internet olmasa da çalışsın diye);
sunucu listeyi, stoku ve 'aldım' kayıtlarını tutar.
"""
from datetime import date, datetime, time

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, resolve_target_user
from ..models import Supplement, SupplementIntake, User
from ..schemas import SupplementIn, SupplementOut, SupplementUpdate

router = APIRouter(prefix="/supplements", tags=["Takviyeler"])

LOW_STOCK = 5


def _out(db: Session, s: Supplement) -> SupplementOut:
    day_start = datetime.combine(date.today(), time.min)
    taken = db.scalar(
        select(func.count(SupplementIntake.id)).where(
            SupplementIntake.supplement_id == s.id, SupplementIntake.taken_at >= day_start
        )
    )
    out = SupplementOut.model_validate(s)
    out.taken_today = int(taken or 0)
    out.low_stock = s.servings_left <= LOW_STOCK
    return out


def _own(db: Session, supplement_id: int, user: User) -> Supplement:
    s = db.get(Supplement, supplement_id)
    if not s or s.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Takviye bulunamadı")
    return s


@router.get("", response_model=list[SupplementOut])
def list_supplements(
    user_id: int | None = None,
    include_inactive: bool = False,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    target = resolve_target_user(current, user_id, db)
    stmt = select(Supplement).where(Supplement.user_id == target.id).order_by(Supplement.name)
    if not include_inactive:
        stmt = stmt.where(Supplement.is_active.is_(True))
    return [_out(db, s) for s in db.scalars(stmt).all()]


@router.post("", response_model=SupplementOut, status_code=status.HTTP_201_CREATED)
def add_supplement(data: SupplementIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = Supplement(
        user_id=user.id,
        name=data.name,
        dose=data.dose,
        reminder_times=",".join(data.reminder_times),
        servings_left=data.servings_left,
    )
    db.add(s)
    db.commit()
    db.refresh(s)
    return _out(db, s)


@router.patch("/{supplement_id}", response_model=SupplementOut)
def update_supplement(
    supplement_id: int, data: SupplementUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    s = _own(db, supplement_id, user)
    changes = data.model_dump(exclude_unset=True)
    if "reminder_times" in changes:
        changes["reminder_times"] = ",".join(changes["reminder_times"] or [])
    for field, value in changes.items():
        if value is not None or field == "dose":
            setattr(s, field, value)
    db.commit()
    db.refresh(s)
    return _out(db, s)


@router.delete("/{supplement_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_supplement(supplement_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = _own(db, supplement_id, user)
    db.execute(SupplementIntake.__table__.delete().where(SupplementIntake.supplement_id == s.id))
    db.delete(s)
    db.commit()


@router.post("/{supplement_id}/take", response_model=SupplementOut)
def take_supplement(supplement_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """'Aldım' butonu: kutudan bir servis düşer, bugünkü alım sayısı artar."""
    s = _own(db, supplement_id, user)
    if s.servings_left <= 0:
        raise HTTPException(status.HTTP_409_CONFLICT, "Kutuda servis kalmadı. Yeni kutu aldıysan stoku güncelle.")
    s.servings_left -= 1
    db.add(SupplementIntake(supplement_id=s.id, user_id=user.id))
    db.commit()
    db.refresh(s)
    return _out(db, s)
