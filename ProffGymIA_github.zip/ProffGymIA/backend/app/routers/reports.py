from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import Response
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, resolve_target_user
from ..models import User
from ..services import report

router = APIRouter(prefix="/reports", tags=["PDF karne"])


@router.get("/monthly", response_class=Response, responses={200: {"content": {"application/pdf": {}}}})
def monthly_report(
    month: str | None = Query(default=None, pattern=r"^\d{4}-(0[1-9]|1[0-2])$", description="YYYY-AA, boşsa bu ay"),
    user_id: int | None = None,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Üyenin aylık gelişim karnesi (PDF): kilo grafiği, BMR değişimi, beslenme başarısı, form skoru."""
    target = resolve_target_user(current, user_id, db)
    today = date.today()
    year, mon = (int(month[:4]), int(month[5:])) if month else (today.year, today.month)
    if date(year, mon, 1) > today:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Gelecek bir ay için karne oluşturulamaz")
    data = report.collect(db, target, year, mon)
    pdf = report.render(data)
    safe_name = "".join(ch for ch in target.full_name if ch.isalnum() or ch in " -_").strip().replace(" ", "_") or "uye"
    filename = f"FitAI_Karne_{safe_name}_{year}-{mon:02d}.pdf"
    ascii_name = filename.encode("ascii", "ignore").decode() or "karne.pdf"
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f"inline; filename=\"{ascii_name}\"; filename*=UTF-8''{_quote(filename)}"},
    )


def _quote(text: str) -> str:
    from urllib.parse import quote

    return quote(text)
