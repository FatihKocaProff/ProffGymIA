from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_admin, require_staff, resolve_target_user
from ..models import Role, User
from ..schemas import AssignTrainerIn, MetabolismOut, ProfileUpdate, RoleUpdate, StaffUserCreate, UserOut
from ..security import hash_password
from ..services import photos
from ..services.profile import metabolism_for, missing_profile_fields

router = APIRouter(prefix="/users", tags=["Kullanıcılar"])


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user


@router.patch("/me", response_model=UserOut)
def update_me(data: ProfileUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(user, field, value)
    db.commit()
    db.refresh(user)
    return user


@router.get("/me/metabolism", response_model=MetabolismOut)
def my_metabolism(
    user_id: int | None = Query(default=None, description="PT/admin danışanın değerlerini görmek için"),
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """BMR, TDEE, hedef kalori, makrolar, su ihtiyacı ve BMI."""
    target = resolve_target_user(current, user_id, db)
    result = metabolism_for(db, target)
    if result is None:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            {"message": "Profil eksik", "missing": missing_profile_fields(db, target)},
        )
    return result.to_dict()


@router.post("/me/photo", response_model=UserOut)
def upload_my_photo(photo: UploadFile = File(...), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Kendi profil fotoğrafını yükler (JPEG/PNG/WEBP, en çok 10 MB). Kare kırpılıp 400x400 kaydedilir."""
    photos.save_profile_photo(user, photo)
    db.commit()
    db.refresh(user)
    return user


@router.delete("/me/photo", response_model=UserOut)
def delete_my_photo(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    photos.remove_profile_photo(user)
    db.commit()
    db.refresh(user)
    return user


@router.get("", response_model=list[UserOut])
def list_users(
    role: Role | None = None,
    search: str | None = Query(default=None, description="Ad veya e-postada arar"),
    current: User = Depends(require_staff),
    db: Session = Depends(get_db),
):
    """Admin herkesi, PT yalnızca kendi danışanlarını görür."""
    stmt = select(User).order_by(User.full_name)
    if current.role == Role.trainer:
        stmt = stmt.where(User.trainer_id == current.id)
    if role:
        stmt = stmt.where(User.role == role)
    if search:
        like = f"%{search}%"
        stmt = stmt.where(or_(User.full_name.ilike(like), User.email.ilike(like)))
    return db.scalars(stmt).all()


@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(data: StaffUserCreate, _: User = Depends(require_admin), db: Session = Depends(get_db)):
    email = data.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status.HTTP_409_CONFLICT, "Bu e-posta zaten kayıtlı")
    if data.trainer_id is not None:
        _ensure_trainer(db, data.trainer_id)
    user = User(
        email=email,
        password_hash=hash_password(data.password),
        full_name=data.full_name,
        phone=data.phone,
        role=data.role,
        trainer_id=data.trainer_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.get("/{user_id}", response_model=UserOut)
def get_user(user_id: int, current: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return resolve_target_user(current, user_id, db)


@router.post("/{user_id}/photo", response_model=UserOut)
def upload_user_photo(
    user_id: int, photo: UploadFile = File(...), _: User = Depends(require_admin), db: Session = Depends(get_db)
):
    """Yönetici üyenin profil fotoğrafını yükler (resepsiyonda kayıt sırasında)."""
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kullanıcı bulunamadı")
    photos.save_profile_photo(user, photo)
    db.commit()
    db.refresh(user)
    return user


@router.delete("/{user_id}/photo", response_model=UserOut)
def delete_user_photo(user_id: int, _: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kullanıcı bulunamadı")
    photos.remove_profile_photo(user)
    db.commit()
    db.refresh(user)
    return user


@router.patch("/{user_id}/trainer", response_model=UserOut)
def assign_trainer(
    user_id: int, data: AssignTrainerIn, _: User = Depends(require_admin), db: Session = Depends(get_db)
):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kullanıcı bulunamadı")
    if data.trainer_id is not None:
        _ensure_trainer(db, data.trainer_id)
    user.trainer_id = data.trainer_id
    db.commit()
    db.refresh(user)
    return user


@router.patch("/{user_id}/active", response_model=UserOut)
def set_active(user_id: int, active: bool, _: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kullanıcı bulunamadı")
    user.is_active = active
    db.commit()
    db.refresh(user)
    return user


@router.patch("/{user_id}/role", response_model=UserOut)
def set_role(user_id: int, data: RoleUpdate, current: User = Depends(require_admin), db: Session = Depends(get_db)):
    """Yönetici bir üyeyi personal trainer yapar ya da PT'yi tekrar üye yapar.

    Üye PT olunca kendi PT ataması kalkar; PT üye olunca danışanlarının PT ataması kalkar.
    """
    if data.role == Role.admin:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Buradan yalnızca üye veya personal trainer seçilebilir")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kullanıcı bulunamadı")
    if user.id == current.id or user.role == Role.admin:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Yönetici hesabının rolü buradan değiştirilemez")
    if user.role != data.role:
        if data.role == Role.trainer:
            user.trainer_id = None
        else:
            for client in user.clients:
                client.trainer_id = None
        user.role = data.role
        db.commit()
        db.refresh(user)
    return user


def _ensure_trainer(db: Session, trainer_id: int) -> None:
    trainer = db.get(User, trainer_id)
    if not trainer or trainer.role != Role.trainer:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Geçersiz PT id")
