"""Turnike geçişi.

- QR: mobil uygulama 60 sn geçerli imzalı kod üretir; turnike/masaüstü okutup doğrular.
- Yüz: masaüstü turnike kamerası kareleri gönderir; kayıtlı yüzlerle eşleştirilir.
İkisi de aynı `evaluate_access` kuralını kullanır.
"""
from datetime import datetime, timedelta
from functools import partial

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import QR_TOKEN_SECONDS
from ..database import get_db
from ..deps import get_current_user, require_admin, require_staff
from ..models import CheckIn, CheckInMethod, Role, User
from ..schemas import CheckInOut, CheckInResult, QRCheckIn, QRTokenOut
from ..security import create_qr_token, decode_token
from ..services import face
from ..services import membership as membership_service

router = APIRouter(prefix="/checkin", tags=["Turnike / Geçiş"])


@router.get("/qr-token", response_model=QRTokenOut)
def qr_token(user: User = Depends(get_current_user)):
    """Mobil uygulama bu token'ı QR koda çevirip gösterir ve süresi dolmadan yeniler."""
    return QRTokenOut(token=create_qr_token(user.id), expires_in=QR_TOKEN_SECONDS)


@router.post("/qr", response_model=CheckInResult)
def check_in_qr(data: QRCheckIn, _: User = Depends(require_staff), db: Session = Depends(get_db)):
    """Turnike cihazı / resepsiyon paneli okuttuğu QR'ı buraya gönderir."""
    user_id = decode_token(data.token, "qr")
    if user_id is None:
        return _log(db, None, CheckInMethod.qr, False, "QR kod geçersiz veya süresi dolmuş")
    return evaluate_access(db, db.get(User, user_id), CheckInMethod.qr)


@router.post("/face", response_model=CheckInResult)
def check_in_face(
    frame: UploadFile = File(..., description="Turnike kamerasından JPEG kare"),
    _: User = Depends(require_staff),
    db: Session = Depends(get_db),
):
    """Kameradaki yüzü kayıtlı üyelerle eşleştirir.

    Karede yüz yoksa kayıt tutulmaz (face_found=false). Aynı kişi kamerada beklerken
    her kare için yeni geçiş kaydı açılmaz: 30 sn içindeki tekrarlar tek kayıt sayılır.
    """
    data = frame.file.read(5 * 1024 * 1024 + 1)
    if not data or len(data) > 5 * 1024 * 1024:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Kare boş veya 5 MB'tan büyük")
    try:
        result = face.encode(data)
    except face.FaceError as exc:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, str(exc)) from exc
    if result is None:
        return CheckInResult(granted=False, reason="Yüz bulunamadı", face_found=False)

    candidates = {}
    for uid, enc in db.execute(select(User.id, User.face_encoding).where(User.face_encoding.is_not(None))).all():
        vec = face.from_json(enc)
        if vec:
            candidates[uid] = vec
    user_id, score = face.best_match(result.vector, candidates)
    extra = {"face_found": True, "face_score": score, "face_box": list(result.box)}

    if user_id is None:
        res = _log(db, None, CheckInMethod.face, False, "Tanınmayan yüz", dedupe_seconds=10)
    else:
        res = evaluate_access(db, db.get(User, user_id), CheckInMethod.face, dedupe_seconds=30)
    return res.model_copy(update=extra)


def evaluate_access(
    db: Session, user: User | None, method: CheckInMethod, dedupe_seconds: int = 0
) -> CheckInResult:
    """Kullanıcının içeri girip giremeyeceğine karar verir ve kaydı tutar."""
    log = partial(_log, db, dedupe_seconds=dedupe_seconds)
    if not user:
        return log(None, method, False, "Kullanıcı bulunamadı")
    if not user.is_active:
        return log(user, method, False, "Hesap pasif")
    if user.role in (Role.admin, Role.trainer):
        return log(user, method, True, "Personel girişi")
    membership = membership_service.get_status(db, user.id)
    if not membership["active"]:
        return log(user, method, False, "Üyelik süresi dolmuş", 0)
    return log(user, method, True, "Geçiş onaylandı", membership["remaining_days"])


def _log(
    db: Session,
    user: User | None,
    method: CheckInMethod,
    granted: bool,
    reason: str,
    remaining_days: int | None = None,
    dedupe_seconds: int = 0,
) -> CheckInResult:
    uid = user.id if user else None
    duplicate = False
    if dedupe_seconds:
        last = db.scalar(
            select(CheckIn)
            .where(CheckIn.user_id.is_(None) if uid is None else CheckIn.user_id == uid, CheckIn.method == method)
            .order_by(CheckIn.id.desc())
            .limit(1)
        )
        duplicate = bool(
            last and last.granted == granted and last.created_at
            and datetime.now() - last.created_at < timedelta(seconds=dedupe_seconds)
        )
    if not duplicate:
        db.add(CheckIn(user_id=uid, method=method, granted=granted, reason=reason))
        db.commit()
    return CheckInResult(
        granted=granted,
        reason=reason,
        user_id=user.id if user else None,
        full_name=user.full_name if user else None,
        remaining_days=remaining_days,
    )


@router.get("/logs", response_model=list[CheckInOut])
def check_in_logs(
    limit: int = Query(default=50, gt=0, le=500),
    _: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    rows = db.execute(
        select(CheckIn, User.full_name)
        .outerjoin(User, CheckIn.user_id == User.id)
        .order_by(CheckIn.id.desc())
        .limit(limit)
    ).all()
    return [
        CheckInOut(
            id=c.id, user_id=c.user_id, full_name=name, method=c.method,
            granted=c.granted, reason=c.reason, created_at=c.created_at,
        )
        for c, name in rows
    ]
