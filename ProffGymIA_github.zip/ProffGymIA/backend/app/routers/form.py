"""Form analizi oturumları. Analizin kendisi cihazda (telefon/masaüstü kamera) çalışır;
sunucu yalnızca set sonucunu saklar. Böylece görüntü ağda dolaşmaz, gecikme olmaz."""
import json
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, resolve_target_user
from ..models import FormSession, Role, User
from ..schemas import FormSessionIn, FormSessionOut

router = APIRouter(prefix="/form-sessions", tags=["Form analizi"])


@router.post("", response_model=FormSessionOut, status_code=status.HTTP_201_CREATED)
def save_session(data: FormSessionIn, current: User = Depends(get_current_user), db: Session = Depends(get_db)):
    target = resolve_target_user(current, data.user_id, db)
    if target.role != Role.member and target.id != current.id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Form oturumu yalnızca üyeye kaydedilebilir")
    good = min(data.good_reps, data.reps)
    session = FormSession(
        user_id=target.id,
        recorded_by_id=current.id,
        exercise=data.exercise,
        reps=data.reps,
        good_reps=good,
        score=round(good / data.reps * 100, 1) if data.reps else 0,
        duration_seconds=data.duration_seconds,
        issues=json.dumps({k[:60]: int(v) for k, v in list(data.issues.items())[:10]}, ensure_ascii=False),
        source=data.source,
    )
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


@router.get("", response_model=list[FormSessionOut])
def list_sessions(
    days: int = Query(default=30, gt=0, le=365),
    user_id: int | None = None,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    target = resolve_target_user(current, user_id, db)
    since = datetime.now() - timedelta(days=days)
    return db.scalars(
        select(FormSession)
        .where(FormSession.user_id == target.id, FormSession.created_at >= since)
        .order_by(FormSession.created_at.desc())
    ).all()
