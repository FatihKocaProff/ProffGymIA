"""Masaüstü / web paneli için özet uçları (tek istekte ekran verisi)."""
from datetime import date, datetime, time

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import require_admin, require_staff
from ..models import CheckIn, Membership, Role, User
from ..schemas import MemberOverviewOut, StatsOut
from ..services.membership import get_status
from ..services.profile import latest_weight

router = APIRouter(prefix="/overview", tags=["Panel özetleri"])


@router.get("/stats", response_model=StatsOut)
def stats(_: User = Depends(require_admin), db: Session = Depends(get_db)):
    """Salon sahibinin 'Bugün' ekranı."""
    today = date.today()
    member_ids = db.scalars(select(User.id).where(User.role == Role.member)).all()
    statuses = [get_status(db, uid, today) for uid in member_ids]

    day_start = datetime.combine(today, time.min)
    month_start = datetime.combine(today.replace(day=1), time.min)
    checkins = db.scalars(select(CheckIn).where(CheckIn.created_at >= day_start)).all()
    revenue = db.scalar(
        select(func.coalesce(func.sum(Membership.price_paid), 0)).where(Membership.created_at >= month_start)
    )

    return StatsOut(
        total_members=len(member_ids),
        active_members=sum(1 for s in statuses if s["active"]),
        expiring_soon=sum(1 for s in statuses if s["active"] and s["remaining_days"] <= 7),
        today_checkins=sum(1 for c in checkins if c.granted),
        denied_today=sum(1 for c in checkins if not c.granted),
        month_revenue=float(revenue or 0),
    )


@router.get("/members", response_model=list[MemberOverviewOut])
def members(current: User = Depends(require_staff), db: Session = Depends(get_db)):
    """Üye listesi + üyelik durumu + son kilo. PT yalnızca kendi danışanlarını görür."""
    stmt = select(User).where(User.role == Role.member).order_by(User.full_name)
    if current.role == Role.trainer:
        stmt = stmt.where(User.trainer_id == current.id)
    trainers = dict(db.execute(select(User.id, User.full_name).where(User.role == Role.trainer)).all())

    result = []
    for u in db.scalars(stmt).all():
        s = get_status(db, u.id)
        result.append(
            MemberOverviewOut(
                id=u.id,
                full_name=u.full_name,
                email=u.email,
                phone=u.phone,
                is_active=u.is_active,
                goal=u.goal,
                trainer_id=u.trainer_id,
                trainer_name=trainers.get(u.trainer_id),
                active=s["active"],
                remaining_days=s["remaining_days"],
                end_date=s["end_date"],
                last_weight=latest_weight(db, u.id),
                photo_path=u.photo_path,
            )
        )
    return result
