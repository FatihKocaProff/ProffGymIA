from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_admin, resolve_target_user
from ..models import Membership, Package, Role, User
from ..schemas import (
    MembershipOut,
    MembershipSellIn,
    MembershipStatusOut,
    PackageIn,
    PackageOut,
    PackageUpdate,
)
from ..services import membership as membership_service

packages_router = APIRouter(prefix="/packages", tags=["Paketler"])
router = APIRouter(prefix="/memberships", tags=["Üyelikler"])


@packages_router.get("", response_model=list[PackageOut])
def list_packages(include_inactive: bool = False, db: Session = Depends(get_db)):
    """Herkese açık: mobil uygulamada salon paketleri ve fiyatları listelenir."""
    stmt = select(Package).order_by(Package.duration_days)
    if not include_inactive:
        stmt = stmt.where(Package.is_active.is_(True))
    return db.scalars(stmt).all()


@packages_router.post("", response_model=PackageOut, status_code=status.HTTP_201_CREATED)
def create_package(data: PackageIn, _: User = Depends(require_admin), db: Session = Depends(get_db)):
    package = Package(**data.model_dump())
    db.add(package)
    db.commit()
    db.refresh(package)
    return package


@packages_router.patch("/{package_id}", response_model=PackageOut)
def update_package(
    package_id: int, data: PackageUpdate, _: User = Depends(require_admin), db: Session = Depends(get_db)
):
    package = db.get(Package, package_id)
    if not package:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Paket bulunamadı")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(package, field, value)
    db.commit()
    db.refresh(package)
    return package


@router.get("/status", response_model=MembershipStatusOut)
def membership_status(
    user_id: int | None = Query(default=None, description="Personel başka üyeyi sorgulamak için"),
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Kalan üyelik günü. Mobil ana ekran bunu gösterir."""
    target = resolve_target_user(current, user_id, db)
    return membership_service.get_status(db, target.id)


@router.get("", response_model=list[MembershipOut])
def membership_history(
    user_id: int | None = None,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    target = resolve_target_user(current, user_id, db)
    return db.scalars(
        select(Membership).where(Membership.user_id == target.id).order_by(Membership.start_date.desc())
    ).all()


@router.post("", response_model=MembershipOut, status_code=status.HTTP_201_CREATED)
def sell_membership(data: MembershipSellIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    """Paket satışı / üyelik uzatma. Üyelik devam ediyorsa yeni dönem mevcut bitişin ertesi günü başlar."""
    user = db.get(User, data.user_id)
    if not user or user.role != Role.member:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Üye bulunamadı")
    package = db.get(Package, data.package_id)
    if not package or not package.is_active:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Paket bulunamadı veya satışta değil")

    start, end = membership_service.next_period(db, user.id, package.duration_days)
    membership = Membership(
        user_id=user.id,
        package_id=package.id,
        start_date=start,
        end_date=end,
        price_paid=data.price_paid if data.price_paid is not None else package.price,
        sold_by_id=admin.id,
    )
    db.add(membership)
    db.commit()
    db.refresh(membership)
    return membership
