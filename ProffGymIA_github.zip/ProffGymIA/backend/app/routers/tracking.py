"""Kilo, su ve yemek takibi. Tüm GET uçları ?user_id= ile PT/admin tarafından danışan için de kullanılabilir."""
import json
import uuid
from datetime import date, timedelta

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import UPLOAD_DIR
from ..database import get_db
from ..deps import get_current_user, resolve_target_user
from ..models import Meal, MealType, User, WaterLog, WeightLog
from ..schemas import (
    MealIn,
    MealOut,
    NutritionSummaryOut,
    WaterDayOut,
    WaterIn,
    WeightIn,
    WeightOut,
)
from ..services import food_ai
from ..services.profile import metabolism_for

router = APIRouter(tags=["Takip (Kilo / Su / Yemek)"])

ALLOWED_IMAGE_TYPES = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}


@router.post("/weights", response_model=WeightOut, status_code=status.HTTP_201_CREATED)
def log_weight(data: WeightIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Günlük tartı. Aynı gün ikinci kez girilirse günceller."""
    day = data.log_date or date.today()
    entry = db.scalar(select(WeightLog).where(WeightLog.user_id == user.id, WeightLog.log_date == day))
    if entry:
        entry.weight_kg = data.weight_kg
    else:
        entry = WeightLog(user_id=user.id, log_date=day, weight_kg=data.weight_kg)
        db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


@router.get("/weights", response_model=list[WeightOut])
def weight_history(
    days: int = Query(default=30, gt=0, le=3650),
    user_id: int | None = None,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Kilo grafiği için eskiden yeniye sıralı liste."""
    target = resolve_target_user(current, user_id, db)
    since = date.today() - timedelta(days=days - 1)
    return db.scalars(
        select(WeightLog)
        .where(WeightLog.user_id == target.id, WeightLog.log_date >= since)
        .order_by(WeightLog.log_date)
    ).all()


@router.delete("/weights/{weight_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_weight(weight_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    entry = db.get(WeightLog, weight_id)
    if not entry or entry.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kayıt bulunamadı")
    db.delete(entry)
    db.commit()


@router.post("/water", response_model=WaterDayOut, status_code=status.HTTP_201_CREATED)
def log_water(data: WaterIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Bir bardak/şişe ekler ve günün güncel toplamını döner."""
    day = data.log_date or date.today()
    db.add(WaterLog(user_id=user.id, log_date=day, amount_ml=data.amount_ml))
    db.commit()
    return _water_day(db, user, day)


@router.get("/water", response_model=WaterDayOut)
def water_for_day(
    day: date | None = None,
    user_id: int | None = None,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    target = resolve_target_user(current, user_id, db)
    return _water_day(db, target, day or date.today())


def _water_day(db: Session, user: User, day: date) -> WaterDayOut:
    total, count = db.execute(
        select(func.coalesce(func.sum(WaterLog.amount_ml), 0), func.count(WaterLog.id)).where(
            WaterLog.user_id == user.id, WaterLog.log_date == day
        )
    ).one()
    metabolism = metabolism_for(db, user)
    return WaterDayOut(
        log_date=day,
        total_ml=int(total),
        target_ml=metabolism.water_ml if metabolism else None,
        entries=int(count),
    )


AI_PROVIDERS = {"gemini", "claude"}


def _detail_from_analysis(analysis: dict) -> tuple[str, str]:
    """İstemcinin gönderdiği /ai/food-text sonucunu güvenli biçimde saklanacak hale getirir: (source, ai_detail_json)."""
    clean = food_ai.normalize(analysis)
    provider = analysis.get("provider") if analysis.get("provider") in AI_PROVIDERS else food_ai.LOCAL_PROVIDER
    clean.update(
        provider=provider,
        model=str(analysis.get("model") or "")[:60],
        unmatched=[str(u)[:40] for u in (analysis.get("unmatched") or [])][:10],
    )
    return ("ai" if provider in AI_PROVIDERS else "auto"), json.dumps(clean, ensure_ascii=False)


@router.post("/meals", response_model=MealOut, status_code=status.HTTP_201_CREATED)
def add_meal(data: MealIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Öğün ekler.

    - Kalori yazılırsa elle giriş olarak kaydedilir.
    - Kalori boş bırakılıp yalnızca "ne yedin" yazılırsa (ör. "2 yumurta, 1 dilim ekmek")
      kalori ve makrolar otomatik hesaplanır (yapay zeka varsa onunla, yoksa yerel besin tablosuyla).
    """
    payload = data.model_dump(exclude={"analysis"})
    payload["meal_date"] = payload["meal_date"] or date.today()
    source, detail = "manual", None
    if payload["calories"] is None:
        macros = (payload["protein_g"], payload["carbs_g"], payload["fat_g"])
        if any(macros):
            payload["calories"] = round(macros[0] * 4 + macros[1] * 4 + macros[2] * 9)
        elif (payload["description"] or "").strip():
            result = food_ai.analyze_text(payload["description"])
            if not result["items"]:
                raise HTTPException(
                    status.HTTP_422_UNPROCESSABLE_ENTITY,
                    "Yazdığın öğünü tanıyamadım. Miktarla birlikte yaz (ör. 2 yumurta, 1 dilim ekmek) ya da kaloriyi elle gir.",
                )
            totals = result["totals"]
            payload.update(calories=totals["calories"], protein_g=totals["protein_g"],
                           carbs_g=totals["carbs_g"], fat_g=totals["fat_g"])
            source, detail = _detail_from_analysis(result)
        else:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Kaloriyi gir ya da ne yediğini yaz; kalori otomatik hesaplansın.")
    elif data.analysis:
        source, detail = _detail_from_analysis(data.analysis)
    meal = Meal(user_id=user.id, source=source, ai_detail=detail, **payload)
    db.add(meal)
    db.commit()
    db.refresh(meal)
    return meal


MAX_PHOTO_BYTES = 10 * 1024 * 1024


def read_image(photo: UploadFile) -> tuple[bytes, str, str]:
    """Yüklenen görseli doğrular; (içerik, mime türü, uzantı) döner."""
    mime = (photo.content_type or "").lower()
    if mime == "image/jpg":
        mime = "image/jpeg"
    ext = ALLOWED_IMAGE_TYPES.get(mime)
    if not ext:
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "Sadece JPEG, PNG veya WEBP yüklenebilir")
    data = photo.file.read(MAX_PHOTO_BYTES + 1)
    if len(data) > MAX_PHOTO_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "Fotoğraf 10 MB'tan büyük olamaz")
    if not data:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Fotoğraf boş")
    return data, mime, ext


@router.post("/meals/photo", response_model=MealOut, status_code=status.HTTP_201_CREATED)
def add_meal_photo(
    photo: UploadFile = File(...),
    meal_type: MealType = Form(MealType.snack),
    description: str | None = Form(None),
    analyze: bool = Form(True, description="Yapay zeka ile makroları otomatik çıkar"),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Yemek fotoğrafını kaydeder ve yapay zekayla besin değerlerini çıkarır.

    Analiz başarısız olursa öğün yine kaydedilir (makrolar 0), hata `ai_detail.error`
    alanında döner; kullanıcı değerleri PATCH /meals/{id} ile elle düzeltebilir.
    """
    data, mime, ext = read_image(photo)

    folder = UPLOAD_DIR / "meals" / str(user.id)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{uuid.uuid4().hex}{ext}"
    path.write_bytes(data)

    meal = Meal(
        user_id=user.id,
        meal_date=date.today(),
        meal_type=meal_type,
        description=description,
        photo_path=path.relative_to(UPLOAD_DIR).as_posix(),
        source="manual",
    )
    if analyze:
        try:
            result = food_ai.analyze_food(data, mime)
        except food_ai.FoodAIError as exc:
            meal.ai_detail = json.dumps({"error": str(exc)}, ensure_ascii=False)
        else:
            totals = result["totals"]
            meal.calories = totals["calories"]
            meal.protein_g = totals["protein_g"]
            meal.carbs_g = totals["carbs_g"]
            meal.fat_g = totals["fat_g"]
            meal.description = description or food_ai.describe(result)
            meal.source = "ai"
            meal.ai_detail = json.dumps(result, ensure_ascii=False)
    db.add(meal)
    db.commit()
    db.refresh(meal)
    return meal


@router.patch("/meals/{meal_id}", response_model=MealOut)
def update_meal(meal_id: int, data: MealIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    meal = db.get(Meal, meal_id)
    if not meal or meal.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Öğün bulunamadı")
    for field, value in data.model_dump(exclude_unset=True, exclude={"analysis"}).items():
        if value is not None:
            setattr(meal, field, value)
    if data.analysis:
        meal.source, meal.ai_detail = _detail_from_analysis(data.analysis)
    db.commit()
    db.refresh(meal)
    return meal


@router.delete("/meals/{meal_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_meal(meal_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    meal = db.get(Meal, meal_id)
    if not meal or meal.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Öğün bulunamadı")
    db.delete(meal)
    db.commit()


@router.get("/meals", response_model=list[MealOut])
def list_meals(
    day: date | None = None,
    days: int = Query(default=1, gt=0, le=365, description="day'den geriye kaç gün"),
    user_id: int | None = None,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """PT danışan ekranı: ?user_id=5&days=7 ile son 7 günün öğünleri."""
    target = resolve_target_user(current, user_id, db)
    end = day or date.today()
    start = end - timedelta(days=days - 1)
    return db.scalars(
        select(Meal)
        .where(Meal.user_id == target.id, Meal.meal_date >= start, Meal.meal_date <= end)
        .order_by(Meal.meal_date.desc(), Meal.created_at.desc())
    ).all()


@router.get("/meals/summary", response_model=NutritionSummaryOut)
def nutrition_summary(
    day: date | None = None,
    user_id: int | None = None,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Günün toplam makroları ve hedeflerle karşılaştırma."""
    target = resolve_target_user(current, user_id, db)
    day = day or date.today()
    cal, pro, carb, fat, count = db.execute(
        select(
            func.coalesce(func.sum(Meal.calories), 0),
            func.coalesce(func.sum(Meal.protein_g), 0),
            func.coalesce(func.sum(Meal.carbs_g), 0),
            func.coalesce(func.sum(Meal.fat_g), 0),
            func.count(Meal.id),
        ).where(Meal.user_id == target.id, Meal.meal_date == day)
    ).one()
    m = metabolism_for(db, target)
    return NutritionSummaryOut(
        day=day,
        calories=round(cal, 1),
        protein_g=round(pro, 1),
        carbs_g=round(carb, 1),
        fat_g=round(fat, 1),
        meal_count=count,
        target_calories=m.target_calories if m else None,
        target_protein_g=m.protein_g if m else None,
        target_carbs_g=m.carbs_g if m else None,
        target_fat_g=m.fat_g if m else None,
    )
