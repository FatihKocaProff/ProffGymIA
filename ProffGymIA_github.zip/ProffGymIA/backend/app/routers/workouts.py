from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from ..database import get_db
from ..deps import get_current_user, require_staff, resolve_target_user
from ..models import Role, User, Workout, WorkoutExercise
from ..schemas import WorkoutIn, WorkoutOut

router = APIRouter(prefix="/workouts", tags=["PT Antrenman"])


@router.post("", response_model=WorkoutOut, status_code=status.HTTP_201_CREATED)
def create_workout(data: WorkoutIn, trainer: User = Depends(require_staff), db: Session = Depends(get_db)):
    """PT danışanına günlük antrenman tanımlar."""
    client = resolve_target_user(trainer, data.client_id, db)
    if client.role != Role.member:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Antrenman yalnızca üyelere tanımlanabilir")
    workout = Workout(
        client_id=client.id,
        trainer_id=trainer.id,
        workout_date=data.workout_date,
        title=data.title,
        notes=data.notes,
        exercises=[WorkoutExercise(position=i, **ex.model_dump()) for i, ex in enumerate(data.exercises)],
    )
    db.add(workout)
    db.commit()
    db.refresh(workout)
    return workout


@router.get("", response_model=list[WorkoutOut])
def list_workouts(
    day: date | None = Query(default=None, description="Boşsa bugün"),
    days: int = Query(default=1, gt=0, le=60, description="day'den itibaren kaç gün (ileri)"),
    user_id: int | None = None,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Mobil 'Bugünkü Antrenmanım' ekranı. PT için ?user_id= ile danışanın programı."""
    target = resolve_target_user(current, user_id, db)
    start = day or date.today()
    end = start + timedelta(days=days - 1)
    return db.scalars(
        select(Workout)
        .options(selectinload(Workout.exercises))
        .where(Workout.client_id == target.id, Workout.workout_date >= start, Workout.workout_date <= end)
        .order_by(Workout.workout_date)
    ).all()


@router.patch("/{workout_id}/complete", response_model=WorkoutOut)
def mark_complete(
    workout_id: int,
    completed: bool = True,
    current: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    workout = db.get(Workout, workout_id)
    if not workout:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Antrenman bulunamadı")
    resolve_target_user(current, workout.client_id, db)
    workout.completed = completed
    db.commit()
    db.refresh(workout)
    return workout


@router.delete("/{workout_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_workout(workout_id: int, current: User = Depends(require_staff), db: Session = Depends(get_db)):
    workout = db.get(Workout, workout_id)
    if not workout:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Antrenman bulunamadı")
    resolve_target_user(current, workout.client_id, db)
    db.delete(workout)
    db.commit()
