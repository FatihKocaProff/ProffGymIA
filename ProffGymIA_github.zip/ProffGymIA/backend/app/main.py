"""FitAI — Merkezi API.

Çalıştırma:  uvicorn app.main:app --reload
Dokümantasyon: http://127.0.0.1:8000/docs
"""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import models
from .config import CORS_ORIGINS, UPLOAD_DIR
from .database import convert_pending_registrations, ensure_schema
from .security import verify_upload_path
from .routers import (ai, auth, checkin, diary, form, memberships, overview, reports, supplements, tracking,
                      users, workouts)

STATIC_DIR = Path(__file__).resolve().parent / "static"


@asynccontextmanager
async def lifespan(_: FastAPI):
    added = ensure_schema()
    if added:
        print("Veritabanına eklenen sütunlar:", ", ".join(added))
    converted = convert_pending_registrations()
    if converted:
        print(f"Onay bekleyen {converted} kayıt üye hesabına çevrildi.")
    yield


app = FastAPI(
    title="FitAI API",
    description="Akıllı spor salonu ekosistemi: mobil uygulama, masaüstü panel ve turnike için merkezi API.",
    version="0.2.0",
    lifespan=lifespan,
)

if CORS_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=CORS_ORIGINS,
        allow_methods=["*"],
        allow_headers=["*"],
    )

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(memberships.packages_router)
app.include_router(memberships.router)
app.include_router(tracking.router)
app.include_router(workouts.router)
app.include_router(checkin.router)
app.include_router(overview.router)
app.include_router(ai.router)
app.include_router(form.router)
app.include_router(supplements.router)
app.include_router(reports.router)
app.include_router(diary.router)

app.mount("/panel", StaticFiles(directory=STATIC_DIR, html=True), name="panel")

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


@app.get("/uploads/{path:path}", include_in_schema=False)
def serve_upload(path: str, exp: int | None = None, sig: str | None = None):
    if not verify_upload_path(path, exp, sig):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Bağlantı geçersiz veya süresi dolmuş")
    root = UPLOAD_DIR.resolve()
    file = (root / path).resolve()
    if not file.is_relative_to(root) or not file.is_file():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Dosya bulunamadı")
    return FileResponse(file, headers={"Cache-Control": "private, max-age=86400"})


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse("/panel/")


@app.get("/health", tags=["Sistem"])
def health():
    return {"status": "ok"}
