"""Kullanıcı profilinden ve son kilo kaydından metabolizma değerlerini üretir."""
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import User, WeightLog
from .metabolism import MetabolismResult, calculate_age, calculate_metabolism


def latest_weight(db: Session, user_id: int) -> float | None:
    return db.scalar(
        select(WeightLog.weight_kg)
        .where(WeightLog.user_id == user_id)
        .order_by(WeightLog.log_date.desc())
        .limit(1)
    )


def missing_profile_fields(db: Session, user: User) -> list[str]:
    missing = []
    if not user.gender:
        missing.append("gender")
    if not user.birth_date:
        missing.append("birth_date")
    if not user.height_cm:
        missing.append("height_cm")
    if latest_weight(db, user.id) is None:
        missing.append("weight (POST /weights)")
    return missing


def metabolism_for(db: Session, user: User) -> MetabolismResult | None:
    """Profil eksikse None döner."""
    weight = latest_weight(db, user.id)
    if weight is None or not (user.gender and user.birth_date and user.height_cm):
        return None
    return calculate_metabolism(
        weight_kg=weight,
        height_cm=user.height_cm,
        age=calculate_age(user.birth_date),
        gender=user.gender.value,
        activity_level=user.activity_level.value,
        goal=user.goal.value,
    )
