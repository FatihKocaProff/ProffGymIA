"""Biyolojik hesaplar: BMR (Mifflin-St Jeor), TDEE, hedef kalori, makro ve su ihtiyacı.

Bu modül veritabanından bağımsızdır; saf fonksiyonlardan oluşur ve kolayca test edilir.

Kaynaklar:
- Mifflin MD, St Jeor ST, et al. "A new predictive equation for resting energy
  expenditure in healthy individuals." Am J Clin Nutr. 1990;51(2):241-247.
- Aktivite çarpanları: yaygın kullanılan Harris-Benedict / Katch-McArdle tablosu.
"""
from dataclasses import asdict, dataclass
from datetime import date

ACTIVITY_MULTIPLIERS = {
    "sedentary": 1.2,
    "light": 1.375,
    "moderate": 1.55,
    "active": 1.725,
    "very_active": 1.9,
}

GOAL_ADJUSTMENT = {
    "lose": -500,
    "maintain": 0,
    "gain": 300,
}

PROTEIN_PER_KG = {
    "lose": 2.0,
    "maintain": 1.6,
    "gain": 1.8,
}

FAT_CALORIE_RATIO = 0.25
MIN_CALORIES = {"male": 1500, "female": 1200}
WATER_ML_PER_KG = 35


def calculate_age(birth_date: date, today: date | None = None) -> int:
    today = today or date.today()
    had_birthday = (today.month, today.day) >= (birth_date.month, birth_date.day)
    return today.year - birth_date.year - (0 if had_birthday else 1)


def mifflin_st_jeor(weight_kg: float, height_cm: float, age: int, gender: str) -> float:
    """BMR (kcal/gün).

    Erkek:  10 × kilo + 6.25 × boy − 5 × yaş + 5
    Kadın:  10 × kilo + 6.25 × boy − 5 × yaş − 161
    """
    base = 10 * weight_kg + 6.25 * height_cm - 5 * age
    return base + (5 if gender == "male" else -161)


@dataclass
class MetabolismResult:
    age: int
    weight_kg: float
    height_cm: float
    bmr: int
    tdee: int
    target_calories: int
    protein_g: int
    fat_g: int
    carbs_g: int
    water_ml: int
    bmi: float
    bmi_category: str

    def to_dict(self) -> dict:
        return asdict(self)


def bmi_category(bmi: float) -> str:
    if bmi < 18.5:
        return "Zayıf"
    if bmi < 25:
        return "Normal"
    if bmi < 30:
        return "Fazla kilolu"
    return "Obez"


def calculate_metabolism(
    *,
    weight_kg: float,
    height_cm: float,
    age: int,
    gender: str,
    activity_level: str = "sedentary",
    goal: str = "maintain",
) -> MetabolismResult:
    bmr = mifflin_st_jeor(weight_kg, height_cm, age, gender)
    tdee = bmr * ACTIVITY_MULTIPLIERS[activity_level]
    target = max(tdee + GOAL_ADJUSTMENT[goal], MIN_CALORIES[gender])

    protein_g = weight_kg * PROTEIN_PER_KG[goal]
    fat_g = target * FAT_CALORIE_RATIO / 9
    carbs_g = max((target - protein_g * 4 - fat_g * 9) / 4, 0)

    height_m = height_cm / 100
    bmi = weight_kg / (height_m * height_m)

    return MetabolismResult(
        age=age,
        weight_kg=round(weight_kg, 1),
        height_cm=round(height_cm, 1),
        bmr=round(bmr),
        tdee=round(tdee),
        target_calories=round(target),
        protein_g=round(protein_g),
        fat_g=round(fat_g),
        carbs_g=round(carbs_g),
        water_ml=round(weight_kg * WATER_ML_PER_KG / 50) * 50,
        bmi=round(bmi, 1),
        bmi_category=bmi_category(bmi),
    )
