"""Yüz tanıma: OpenCV YuNet (yüz bulma) + SFace (128 boyutlu yüz vektörü).

Neden `face_recognition` (dlib) değil? dlib Windows'ta C++ derleyicisi ister ve
kurulumu sık sorun çıkarır. OpenCV'nin bu iki modeli `pip install opencv-python`
ile çalışır, CPU'da hızlıdır ve doğruluğu turnike için yeterlidir.

Akış:
  1. Kayıt: üyenin fotoğrafı -> yüz bul -> hizala -> 128 sayılık vektör -> users.face_encoding
  2. Turnike: kameradan kare -> vektör -> kayıtlı tüm vektörlerle kosinüs benzerliği
     -> en yüksek skor eşiği geçerse o üye
"""
from __future__ import annotations

import json
import threading
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from .. import config

DETECTOR_FILE = "face_detection_yunet_2023mar.onnx"
RECOGNIZER_FILE = "face_recognition_sface_2021dec.onnx"
MODEL_URLS = {
    DETECTOR_FILE: [
        "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx",
        "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx",
    ],
    RECOGNIZER_FILE: [
        "https://github.com/opencv/opencv_zoo/raw/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx",
        "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx",
    ],
}
MAX_SIDE = 960


class FaceError(Exception):
    """Kullanıcıya gösterilecek açıklamayla fırlatılır."""


@dataclass
class FaceResult:
    vector: list[float]
    box: tuple[int, int, int, int]
    score: float
    faces_found: int


_lock = threading.Lock()
_detector = None
_recognizer = None


def _cv():
    try:
        import cv2
        import numpy as np
    except ImportError as exc:
        raise FaceError("Yüz tanıma için 'opencv-python' paketi kurulu değil (pip install -r requirements.txt).") from exc
    return cv2, np


def ensure_models() -> Path:
    """Model dosyaları yoksa indirir (toplam ~37 MB, yalnızca ilk seferde)."""
    config.MODELS_DIR.mkdir(parents=True, exist_ok=True)
    for name, urls in MODEL_URLS.items():
        path = config.MODELS_DIR / name
        if path.exists() and path.stat().st_size > 100_000:
            continue
        last_error = None
        for url in urls:
            try:
                tmp = path.with_suffix(".part")
                urllib.request.urlretrieve(url, tmp)
                if tmp.stat().st_size < 100_000:
                    raise OSError("dosya eksik indi")
                tmp.replace(path)
                break
            except OSError as exc:
                last_error = exc
        else:
            raise FaceError(
                f"Yüz tanıma modeli indirilemedi ({name}): {last_error}. "
                f"İnternet bağlantısını kontrol et veya dosyayı elle '{config.MODELS_DIR}' klasörüne koy."
            )
    return config.MODELS_DIR


def _create_models(cv2, np, folder: Path):
    """Modelleri dosya yolu yerine bellekten yükler.

    OpenCV'nin C++ tarafı Windows'ta Türkçe/ASCII dışı karakter içeren yolları ("Tüm KODLAR",
    "Masaüstü", "Kullanıcılar\\Şule") açamaz. Dosyayı Python ile okuyup bayt olarak vermek bu sorunu
    tamamen ortadan kaldırır. Bellekten yükleme desteği olmayan eski OpenCV sürümlerinde yola geri döner.
    """
    detector_path, recognizer_path = folder / DETECTOR_FILE, folder / RECOGNIZER_FILE
    try:
        detector_buf = np.frombuffer(detector_path.read_bytes(), np.uint8)
        recognizer_buf = np.frombuffer(recognizer_path.read_bytes(), np.uint8)
        empty = np.empty(0, np.uint8)
        detector = cv2.FaceDetectorYN.create("onnx", detector_buf, empty, (320, 320), 0.8, 0.3, 5000)
        recognizer = cv2.FaceRecognizerSF.create("onnx", recognizer_buf, empty)
        return detector, recognizer
    except (TypeError, cv2.error):
        pass
    try:
        detector = cv2.FaceDetectorYN.create(str(detector_path), "", (320, 320), 0.8, 0.3, 5000)
        recognizer = cv2.FaceRecognizerSF.create(str(recognizer_path), "")
    except cv2.error as exc:
        raise FaceError(
            "Yüz tanıma modeli yüklenemedi. Proje klasörünün yolunda Türkçe karakter varsa "
            "OpenCV'yi güncelle (pip install -U opencv-python-headless) veya projeyi C:\\FitAI gibi bir klasöre taşı."
        ) from exc
    return detector, recognizer


def _models():
    global _detector, _recognizer
    with _lock:
        if _detector is None:
            cv2, np = _cv()
            _detector, _recognizer = _create_models(cv2, np, ensure_models())
    return _detector, _recognizer


def encode(image_bytes: bytes, require_single: bool = False) -> FaceResult | None:
    """Görüntüdeki en büyük yüzün vektörünü döner. Yüz yoksa None."""
    cv2, np = _cv()
    img = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise FaceError("Görüntü okunamadı. JPEG veya PNG gönder.")

    scale = 1.0
    h, w = img.shape[:2]
    if max(h, w) > MAX_SIDE:
        scale = MAX_SIDE / max(h, w)
        img = cv2.resize(img, (int(w * scale), int(h * scale)))
        h, w = img.shape[:2]

    detector, recognizer = _models()
    with _lock:
        detector.setInputSize((w, h))
        _, faces = detector.detect(img)
        if faces is None or len(faces) == 0:
            return None
        if require_single and len(faces) > 1:
            raise FaceError("Fotoğrafta birden fazla yüz var. Yalnızca üyenin olduğu bir fotoğraf çek.")
        face = max(faces, key=lambda f: f[2] * f[3])
        aligned = recognizer.alignCrop(img, face)
        feature = recognizer.feature(aligned).flatten().astype("float32")

    norm = float(np.linalg.norm(feature)) or 1.0
    vector = (feature / norm).round(6).tolist()
    x, y, fw, fh = (int(v / scale) for v in face[:4])
    return FaceResult(vector=vector, box=(x, y, fw, fh), score=float(face[14]), faces_found=len(faces))


def best_match(vector: list[float], candidates: dict[int, list[float]]) -> tuple[int | None, float]:
    """En benzer kayıtlı yüz. Eşik altındaysa (None, skor)."""
    if not candidates:
        return None, 0.0
    _, np = _cv()
    ids = list(candidates)
    matrix = np.asarray([candidates[i] for i in ids], dtype="float32")
    sims = matrix @ np.asarray(vector, dtype="float32")
    idx = int(sims.argmax())
    score = float(sims[idx])
    return (ids[idx] if score >= config.FACE_MATCH_THRESHOLD else None), round(score, 3)


def to_json(vector: list[float]) -> str:
    return json.dumps(vector, separators=(",", ":"))


def from_json(text: str | None) -> list[float] | None:
    if not text:
        return None
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, list) and len(data) == 128 else None
