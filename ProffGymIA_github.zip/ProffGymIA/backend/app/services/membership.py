"""Üyelik süresi hesapları."""
from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Membership


def get_status(db: Session, user_id: int, today: date | None = None) -> dict:
    today = today or date.today()
    memberships = db.scalars(select(Membership).where(Membership.user_id == user_id)).all()

    active = any(m.start_date <= today <= m.end_date for m in memberships)
    future_or_current = [m for m in memberships if m.end_date >= today]
    end_date = max((m.end_date for m in future_or_current), default=None)
    remaining_days = (end_date - today).days + 1 if end_date else 0

    return {
        "active": active,
        "end_date": end_date,
        "remaining_days": remaining_days,
        "total_memberships": len(memberships),
    }


def next_period(db: Session, user_id: int, duration_days: int, today: date | None = None) -> tuple[date, date]:
    """Yeni satılan paketin başlangıç ve bitişi.

    Üyeliği devam eden birine satılırsa, mevcut bitişin ertesi günü başlar (uzatma).
    Üyeliği bitmiş/hiç olmayan birine satılırsa bugünden başlar.
    """
    today = today or date.today()
    status = get_status(db, user_id, today)
    start = status["end_date"] + timedelta(days=1) if status["end_date"] else today
    end = start + timedelta(days=duration_days - 1)
    return start, end
