"""Profil fotoğrafı: ortadan kare kırpılır, 400x400 JPEG olarak uploads/profiles/<kullanıcı id>/ altına kaydedilir.

Dosya adı tahmin edilemez rastgele bir kimliktir; yeni fotoğraf yüklenince eskisi silinir.
"""
from __future__ import annotations

import io
import uuid

from fastapi import HTTPException, UploadFile, status

from ..config import UPLOAD_DIR
from ..models import User

SIZE = 400
FOLDER = "profiles"


def save_profile_photo(user: User, upload: UploadFile) -> str:
    from ..routers.tracking import read_image

    data, _mime, ext = read_image(upload)
    folder = UPLOAD_DIR / FOLDER / str(user.id)
    folder.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image, ImageOps
    except ImportError:
        path = folder / f"{uuid.uuid4().hex}{ext}"
        path.write_bytes(data)
    else:
        try:
            img = Image.open(io.BytesIO(data))
            img = ImageOps.exif_transpose(img).convert("RGB")
        except Exception as exc:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Geçerli bir resim dosyası değil") from exc
        img = ImageOps.fit(img, (SIZE, SIZE), Image.Resampling.LANCZOS, centering=(0.5, 0.4))
        path = folder / f"{uuid.uuid4().hex}.jpg"
        img.save(path, "JPEG", quality=85, optimize=True)

    old = user.photo_path
    user.photo_path = path.relative_to(UPLOAD_DIR).as_posix()
    _delete_file(old)
    return user.photo_path


def remove_profile_photo(user: User) -> None:
    _delete_file(user.photo_path)
    user.photo_path = None


def _delete_file(rel_path: str | None) -> None:
    if not rel_path or not rel_path.startswith(FOLDER + "/") or ".." in rel_path:
        return
    try:
        (UPLOAD_DIR / rel_path).unlink(missing_ok=True)
    except OSError:
        pass
