"""Aylık PDF gelişim karnesi.

İki adım:
  collect(...)  -> veritabanından ayın sayılarını toplar (dict)
  render(data)  -> o dict'ten PDF üretir (veritabanından bağımsız, test edilebilir)
"""
from __future__ import annotations

import calendar
import io
import json
from collections import Counter
from datetime import date, datetime, time, timedelta
from pathlib import Path

MONTHS_TR = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz",
             "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
GOAL_TR = {"lose": "Kilo vermek", "maintain": "Kiloyu korumak", "gain": "Kilo almak"}
EXERCISE_TR = {"squat": "Squat", "biceps_curl": "Biceps curl", "shoulder_press": "Omuz press"}
FONT_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def month_range(year: int, month: int, today: date | None = None) -> tuple[date, date]:
    today = today or date.today()
    start = date(year, month, 1)
    end = date(year, month, calendar.monthrange(year, month)[1])
    return start, min(end, today) if start <= today else end


def collect(db, user, year: int, month: int) -> dict:
    from sqlalchemy import func, select

    from ..models import (CheckIn, FormSession, Meal, User, WaterLog, WeightLog, Workout)
    from .membership import get_status
    from .metabolism import calculate_age, calculate_metabolism

    start, end = month_range(year, month)
    day0, day1 = datetime.combine(start, time.min), datetime.combine(end, time.max)

    weights = db.execute(
        select(WeightLog.log_date, WeightLog.weight_kg)
        .where(WeightLog.user_id == user.id, WeightLog.log_date.between(start, end))
        .order_by(WeightLog.log_date)
    ).all()

    metab = None
    if weights and user.gender and user.birth_date and user.height_cm:
        def calc(kg):
            return calculate_metabolism(
                weight_kg=kg, height_cm=user.height_cm, age=calculate_age(user.birth_date, end),
                gender=user.gender.value, activity_level=user.activity_level.value, goal=user.goal.value)
        first, last = calc(weights[0][1]), calc(weights[-1][1])
        metab = {"bmr_start": first.bmr, "bmr_end": last.bmr, "tdee": last.tdee,
                 "target_calories": last.target_calories, "target_protein": last.protein_g,
                 "water_ml": last.water_ml, "bmi": last.bmi, "bmi_category": last.bmi_category}

    daily = db.execute(
        select(Meal.meal_date, func.sum(Meal.calories), func.sum(Meal.protein_g), func.count(Meal.id))
        .where(Meal.user_id == user.id, Meal.meal_date.between(start, end))
        .group_by(Meal.meal_date)
    ).all()
    photo_meals = db.scalar(
        select(func.count(Meal.id)).where(Meal.user_id == user.id, Meal.meal_date.between(start, end), Meal.photo_path.is_not(None))
    )

    water = db.execute(
        select(WaterLog.log_date, func.sum(WaterLog.amount_ml))
        .where(WaterLog.user_id == user.id, WaterLog.log_date.between(start, end))
        .group_by(WaterLog.log_date)
    ).all()

    sessions = db.scalars(
        select(FormSession).where(FormSession.user_id == user.id, FormSession.created_at.between(day0, day1))
    ).all()
    issues = Counter()
    for s in sessions:
        try:
            issues.update(json.loads(s.issues or "{}"))
        except (json.JSONDecodeError, TypeError):
            pass
    by_exercise: dict[str, list] = {}
    for s in sessions:
        by_exercise.setdefault(s.exercise, []).append(s)

    workouts = db.execute(
        select(Workout.completed, func.count(Workout.id))
        .where(Workout.client_id == user.id, Workout.workout_date.between(start, end))
        .group_by(Workout.completed)
    ).all()
    wcount = {bool(c): n for c, n in workouts}

    visit_days = db.scalar(
        select(func.count(func.distinct(func.date(CheckIn.created_at))))
        .where(CheckIn.user_id == user.id, CheckIn.granted.is_(True), CheckIn.created_at.between(day0, day1))
    )
    trainer = db.get(User, user.trainer_id) if user.trainer_id else None
    membership = get_status(db, user.id)

    return build(
        user={"name": user.full_name, "email": user.email, "goal": GOAL_TR.get(user.goal.value, ""),
              "trainer": trainer.full_name if trainer else None,
              "age": calculate_age(user.birth_date, end) if user.birth_date else None,
              "height_cm": user.height_cm},
        start=start, end=end,
        membership={"active": membership["active"], "remaining_days": membership["remaining_days"],
                    "end_date": membership["end_date"]},
        weights=[(d, float(kg)) for d, kg in weights],
        metabolism=metab,
        daily_nutrition=[(d, float(c or 0), float(p or 0), int(n)) for d, c, p, n in daily],
        photo_meals=int(photo_meals or 0),
        water=[(d, int(ml or 0)) for d, ml in water],
        form={ex: {"sessions": len(ss), "reps": sum(s.reps for s in ss), "good_reps": sum(s.good_reps for s in ss)}
              for ex, ss in by_exercise.items()},
        form_issues=issues.most_common(3),
        workouts_planned=sum(wcount.values()),
        workouts_completed=wcount.get(True, 0),
        visit_days=int(visit_days or 0),
    )


def build(*, user, start, end, membership, weights, metabolism, daily_nutrition, photo_meals,
          water, form, form_issues, workouts_planned, workouts_completed, visit_days) -> dict:
    """Ham sayılardan karnedeki yüzdeleri ve yorumları üretir (saf fonksiyon)."""
    days_in_period = (end - start).days + 1
    target_cal = metabolism["target_calories"] if metabolism else None
    target_pro = metabolism["target_protein"] if metabolism else None

    n_days = len(daily_nutrition)
    avg_cal = sum(c for _, c, _, _ in daily_nutrition) / n_days if n_days else 0
    avg_pro = sum(p for _, _, p, _ in daily_nutrition) / n_days if n_days else 0
    on_target = sum(1 for _, c, _, _ in daily_nutrition if target_cal and abs(c - target_cal) <= target_cal * 0.10)
    protein_ok = sum(1 for _, _, p, _ in daily_nutrition if target_pro and p >= target_pro * 0.9)

    water_target = metabolism["water_ml"] if metabolism else None
    water_ok = sum(1 for _, ml in water if water_target and ml >= water_target)

    total_reps = sum(f["reps"] for f in form.values())
    good_reps = sum(f["good_reps"] for f in form.values())
    form_score = round(good_reps / total_reps * 100) if total_reps else None

    nutrition_score = round(on_target / n_days * 100) if (target_cal and n_days) else None
    workout_score = round(workouts_completed / workouts_planned * 100) if workouts_planned else None
    components = [s for s in (nutrition_score, workout_score, form_score) if s is not None]
    overall = round(sum(components) / len(components)) if components else None

    w_start = weights[0][1] if weights else None
    w_end = weights[-1][1] if weights else None
    change = round(w_end - w_start, 1) if weights else None

    notes = []
    goal = user.get("goal")
    if change is not None and len(weights) >= 2:
        if goal == GOAL_TR["lose"]:
            notes.append(f"Bu ay {_fmt(abs(change), 1)} kg verdin. Haftada 0,5 kg hedefi için devam." if change < 0
                         else "Kilo vermek hedefine rağmen kilon artmış; kalori takibini sıklaştır.")
        elif goal == GOAL_TR["gain"]:
            notes.append(f"Bu ay {_fmt(change, 1)} kg aldın." if change > 0
                         else "Kilo alma hedefi için günlük kaloriyi 200-300 kcal artır.")
    if not weights or len(weights) < 4:
        notes.append("Daha doğru bir grafik için haftada en az iki kez tartıl.")
    if target_pro and n_days and protein_ok < n_days * 0.6:
        notes.append(f"Protein hedefini {n_days} günün yalnızca {protein_ok} gününde tutturdun; her öğüne bir protein kaynağı ekle.")
    if n_days < days_in_period * 0.5:
        notes.append(f"{days_in_period} günün {n_days} gününde öğün girdin; düzenli kayıt PT'inin seni daha iyi yönlendirmesini sağlar.")
    if form_issues:
        notes.append(f"En sık form hatan: “{form_issues[0][0]}” ({form_issues[0][1]} kez). Bir sonraki antrenmanda buna odaklan.")
    if workouts_planned and workouts_completed < workouts_planned:
        notes.append(f"Planlanan {workouts_planned} antrenmanın {workouts_completed} tanesini tamamladın.")
    if not notes:
        notes.append("Harika bir ay! Aynı düzenle devam.")

    return {
        "user": user,
        "period": {"start": start, "end": end, "label": f"{MONTHS_TR[start.month - 1]} {start.year}", "days": days_in_period},
        "membership": membership,
        "weight": {"series": weights, "start": w_start, "end": w_end, "change": change,
                   "min": min((w for _, w in weights), default=None), "max": max((w for _, w in weights), default=None)},
        "metabolism": metabolism,
        "nutrition": {"days_logged": n_days, "avg_calories": round(avg_cal), "avg_protein": round(avg_pro),
                      "target_calories": target_cal, "target_protein": target_pro, "on_target_days": on_target,
                      "protein_ok_days": protein_ok, "photo_meals": photo_meals, "score": nutrition_score},
        "water": {"days_logged": len(water), "avg_ml": round(sum(ml for _, ml in water) / len(water)) if water else 0,
                  "target_ml": water_target, "days_hit": water_ok},
        "form": {"by_exercise": form, "total_reps": total_reps, "good_reps": good_reps, "score": form_score,
                 "issues": form_issues},
        "workouts": {"planned": workouts_planned, "completed": workouts_completed, "score": workout_score},
        "visit_days": visit_days,
        "overall": overall,
        "notes": notes[:5],
    }


def _fmt(n, digits=1, suffix=""):
    if n is None:
        return "—"
    s = f"{n:,.{digits}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    if digits and s.endswith("," + "0" * digits):
        s = s[: -(digits + 1)]
    return s + suffix


def _date(d):
    return f"{d.day} {MONTHS_TR[d.month - 1]} {d.year}" if d else "—"


def render(data: dict) -> bytes:
    from reportlab.graphics.charts.lineplots import LinePlot
    from reportlab.graphics.shapes import Drawing, String
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfgen import canvas

    for name, file in (("Sans", "DejaVuSans.ttf"), ("Sans-Bold", "DejaVuSans-Bold.ttf"),
                       ("Display", "DejaVuSansCondensed-Bold.ttf")):
        if name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(name, str(FONT_DIR / file)))

    INK = colors.HexColor("#1d2025")
    INK2 = colors.HexColor("#565b62")
    LINE = colors.HexColor("#c9cbc4")
    SOFT = colors.HexColor("#ecede7")
    BLUE = colors.HexColor("#1f5fae")
    RED = colors.HexColor("#c4303a")
    YELLOW = colors.HexColor("#d9a514")
    GREEN = colors.HexColor("#2a8551")

    buf = io.BytesIO()
    W, H = A4
    M = 16 * mm
    c = canvas.Canvas(buf, pagesize=A4)
    c.setTitle(f"FitAI Gelişim Karnesi - {data['user']['name']} - {data['period']['label']}")
    c.setAuthor("FitAI")

    band = 34 * mm
    c.setFillColor(INK)
    c.rect(0, H - band, W, band, stroke=0, fill=1)
    for i, col in enumerate((RED, BLUE, YELLOW, GREEN)):
        c.setFillColor(col)
        c.roundRect(M + i * 4.2 * mm, H - band + 8 * mm, 3 * mm, (18 - i * 2.5) * mm, 0.8 * mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Display", 24)
    c.drawString(M + 22 * mm, H - 17 * mm, "Gelişim Karnesi")
    c.setFont("Sans", 11)
    c.setFillColor(colors.HexColor("#c9ccc6"))
    c.drawString(M + 22 * mm, H - 24.5 * mm, f"{data['period']['label']}  ·  {_date(data['period']['start'])} – {_date(data['period']['end'])}")
    c.setFont("Display", 16)
    c.setFillColor(colors.white)
    c.drawRightString(W - M, H - 17 * mm, data["user"]["name"])
    c.setFont("Sans", 9.5)
    c.setFillColor(colors.HexColor("#c9ccc6"))
    sub = [f"Hedef: {data['user']['goal']}"]
    if data["user"].get("trainer"):
        sub.append(f"PT: {data['user']['trainer']}")
    c.drawRightString(W - M, H - 24.5 * mm, "   ".join(sub))

    y = H - band - 10 * mm

    tiles = [
        ("Genel skor", _fmt(data["overall"], 0, "") if data["overall"] is not None else "—", "/100", INK),
        ("Kilo değişimi", _fmt(data["weight"]["change"], 1) if data["weight"]["change"] is not None else "—", " kg", BLUE),
        ("Beslenme başarısı", f"%{data['nutrition']['score']}" if data["nutrition"]["score"] is not None else "—", "", GREEN),
        ("Form skoru", f"%{data['form']['score']}" if data["form"]["score"] is not None else "—", "", YELLOW),
        ("Salon ziyareti", str(data["visit_days"]), " gün", RED),
    ]
    tw = (W - 2 * M) / len(tiles)
    th = 22 * mm
    for i, (label, value, unit, col) in enumerate(tiles):
        x = M + i * tw
        c.setFillColor(SOFT)
        c.rect(x, y - th, tw - 2 * mm, th, stroke=0, fill=1)
        c.setFillColor(col)
        c.rect(x, y - 1.6 * mm, tw - 2 * mm, 1.6 * mm, stroke=0, fill=1)
        c.setFillColor(INK)
        c.setFont("Display", 20)
        c.drawString(x + 3.5 * mm, y - 12 * mm, value)
        vw = pdfmetrics.stringWidth(value, "Display", 20)
        c.setFont("Sans", 9)
        c.setFillColor(INK2)
        c.drawString(x + 3.5 * mm + vw + 0.8 * mm, y - 12 * mm, unit)
        c.drawString(x + 3.5 * mm, y - 18 * mm, label)
    y -= th + 9 * mm

    def heading(text, yy):
        c.setFillColor(INK)
        c.setFont("Display", 13)
        c.drawString(M, yy, text)
        c.setStrokeColor(LINE)
        c.setLineWidth(0.6)
        c.line(M, yy - 2.2 * mm, W - M, yy - 2.2 * mm)
        return yy - 8 * mm

    def rows(pairs, yy, x=M, width=(W - 2 * M), size=9.5):
        for label, value in pairs:
            c.setFont("Sans", size)
            c.setFillColor(INK2)
            c.drawString(x, yy, label)
            c.setFillColor(INK)
            c.setFont("Sans-Bold", size)
            c.drawRightString(x + width, yy, value)
            yy -= 5.6 * mm
        return yy

    y = heading("Kilo ve metabolizma", y)
    col_w = (W - 2 * M - 8 * mm) / 2
    series = data["weight"]["series"]
    chart_h = 52 * mm
    if len(series) >= 2:
        d = Drawing(col_w, chart_h)
        lp = LinePlot()
        lp.x, lp.y, lp.width, lp.height = 10 * mm, 8 * mm, col_w - 14 * mm, chart_h - 12 * mm
        base = series[0][0].toordinal()
        lp.data = [[(dd.toordinal() - base, kg) for dd, kg in series]]
        lo, hi = data["weight"]["min"], data["weight"]["max"]
        pad = max((hi - lo) * 0.15, 0.5)
        lp.yValueAxis.valueMin, lp.yValueAxis.valueMax = round(lo - pad, 1), round(hi + pad, 1)
        lp.yValueAxis.labels.fontName = "Sans"
        lp.yValueAxis.labels.fontSize = 7
        lp.yValueAxis.labels.fillColor = INK2
        lp.yValueAxis.strokeColor = LINE
        lp.yValueAxis.gridStrokeColor = SOFT
        lp.yValueAxis.visibleGrid = True
        lp.yValueAxis.labelTextFormat = lambda v: _fmt(v, 1)
        span = series[-1][0].toordinal() - base or 1
        lp.xValueAxis.valueMin, lp.xValueAxis.valueMax = 0, span
        lp.xValueAxis.valueSteps = [0, span]
        lp.xValueAxis.labelTextFormat = lambda v: f"{(series[0][0] + timedelta(days=int(v))).day} {MONTHS_TR[(series[0][0] + timedelta(days=int(v))).month - 1][:3]}"
        lp.xValueAxis.labels.fontName = "Sans"
        lp.xValueAxis.labels.fontSize = 7
        lp.xValueAxis.labels.fillColor = INK2
        lp.xValueAxis.strokeColor = LINE
        lp.lines[0].strokeColor = BLUE
        lp.lines[0].strokeWidth = 1.8
        d.add(lp)
        d.add(String(10 * mm, chart_h - 3 * mm, "kg", fontName="Sans", fontSize=7, fillColor=INK2))
        d.drawOn(c, M, y - chart_h + 2 * mm)
    else:
        c.setFont("Sans", 9.5)
        c.setFillColor(INK2)
        c.drawString(M, y - 6 * mm, "Grafik için bu ay en az iki kilo kaydı gerekiyor.")

    w = data["weight"]
    m = data["metabolism"]
    pairs = [("Ay başı / sonu kilo", f"{_fmt(w['start'], 1, ' kg')} → {_fmt(w['end'], 1, ' kg')}"),
             ("En düşük / en yüksek", f"{_fmt(w['min'], 1)} / {_fmt(w['max'], 1, ' kg')}")]
    if m:
        pairs += [("BMR (ay başı → sonu)", f"{m['bmr_start']} → {m['bmr_end']} kcal"),
                  ("Günlük harcama (TDEE)", f"{m['tdee']} kcal"),
                  ("Hedef kalori / protein", f"{m['target_calories']} kcal / {m['target_protein']} g"),
                  ("Vücut kitle indeksi", f"{_fmt(m['bmi'], 1)} · {m['bmi_category']}")]
    else:
        pairs.append(("Metabolizma", "Profil eksik"))
    rows(pairs, y - 2 * mm, x=M + col_w + 8 * mm, width=col_w)
    y -= chart_h + 6 * mm

    y = heading("Beslenme, antrenman ve form", y)
    n = data["nutrition"]
    wa = data["water"]
    left = [
        ("Öğün girilen gün", f"{n['days_logged']} / {data['period']['days']}"),
        ("Ortalama kalori", f"{n['avg_calories']} kcal" + (f" (hedef {n['target_calories']})" if n["target_calories"] else "")),
        ("Ortalama protein", f"{n['avg_protein']} g" + (f" (hedef {n['target_protein']})" if n["target_protein"] else "")),
        ("Hedef kaloriye uyan gün (±%10)", f"{n['on_target_days']} / {n['days_logged']}"),
        ("Fotoğrafla girilen öğün", str(n["photo_meals"])),
        ("Ortalama su", _fmt(wa["avg_ml"] / 1000, 2, " L") + (f" (hedef {_fmt(wa['target_ml'] / 1000, 2)} L)" if wa["target_ml"] else "")),
    ]
    f = data["form"]
    wo = data["workouts"]
    right = [("Tamamlanan antrenman", f"{wo['completed']} / {wo['planned']}" if wo["planned"] else "Program yok")]
    for ex, st in f["by_exercise"].items():
        pct = round(st["good_reps"] / st["reps"] * 100) if st["reps"] else 0
        right.append((f"{EXERCISE_TR.get(ex, ex)} ({st['sessions']} set)", f"{st['good_reps']}/{st['reps']} doğru · %{pct}"))
    if not f["by_exercise"]:
        right.append(("Form analizi", "Bu ay kayıt yok"))
    for issue, count in f["issues"]:
        right.append((f"Uyarı: {issue}", f"{count} kez"))
    yl = rows(left, y, x=M, width=col_w)
    yr = rows(right[:8], y, x=M + col_w + 8 * mm, width=col_w)
    y = min(yl, yr) - 4 * mm

    y = heading("Öneriler", y)
    c.setFont("Sans", 10)
    from reportlab.lib.utils import simpleSplit
    for note in data["notes"]:
        lines = simpleSplit(note, "Sans", 10, W - 2 * M - 6 * mm)
        c.setFillColor(BLUE)
        c.circle(M + 1.2 * mm, y + 1.2 * mm, 1 * mm, stroke=0, fill=1)
        c.setFillColor(INK)
        for line in lines:
            c.drawString(M + 5 * mm, y, line)
            y -= 5 * mm
        y -= 1.5 * mm

    c.setStrokeColor(LINE)
    c.line(M, 18 * mm, W - M, 18 * mm)
    c.setFont("Sans", 8)
    c.setFillColor(INK2)
    ms = data["membership"]
    member_txt = (f"Üyelik aktif · {ms['remaining_days']} gün kaldı (bitiş {_date(ms['end_date'])})"
                  if ms["active"] else "Üyelik aktif değil")
    c.drawString(M, 13 * mm, member_txt)
    c.drawRightString(W - M, 13 * mm, f"FitAI · {datetime.now():%d.%m.%Y %H:%M} tarihinde oluşturuldu")
    c.drawString(M, 9 * mm, "BMR Mifflin-St Jeor formülüyle hesaplanır. Genel skor: beslenme, antrenman ve form yüzdelerinin ortalamasıdır.")

    c.showPage()
    c.save()
    return buf.getvalue()
