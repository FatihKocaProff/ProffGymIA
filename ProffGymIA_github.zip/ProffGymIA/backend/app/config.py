"""Uygulama ayarları. Ortam değişkenleriyle (veya .env dosyasıyla) değiştirilebilir."""
import os
from pathlib import Path

from .anahtar import guclu_mu


def _load_dotenv() -> None:
    """Ek paket gerektirmeyen basit .env okuyucu."""
    env_path = Path(__file__).resolve().parent.parent / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv()

DATABASE_URL = os.getenv("FITAI_DATABASE_URL", "sqlite:///./fitai.db")

SECRET_KEY = os.getenv("FITAI_SECRET_KEY", "").strip().strip('"').strip("'")
if not guclu_mu(SECRET_KEY):
    raise RuntimeError(
        "FITAI_SECRET_KEY eksik veya zayıf (en az 32 karakter olmalı). backend klasöründe "
        "'.venv\\Scripts\\python -m app.anahtar' çalıştır ya da baslat.bat ile başlat."
    )
CORS_ORIGINS = [o.strip().rstrip("/") for o in os.getenv("FITAI_CORS_ORIGINS", "").split(",") if o.strip()]

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("FITAI_TOKEN_MINUTES", "1440"))

QR_TOKEN_SECONDS = int(os.getenv("FITAI_QR_SECONDS", "60"))

UPLOAD_DIR = Path(os.getenv("FITAI_UPLOAD_DIR", "uploads"))

AI_PROVIDER = os.getenv("FITAI_AI_PROVIDER", "").strip().lower()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("FITAI_GEMINI_MODEL", "gemini-3.6-flash")
CLAUDE_MODEL = os.getenv("FITAI_CLAUDE_MODEL", "claude-haiku-5-5")
AI_TIMEOUT_SECONDS = float(os.getenv("FITAI_AI_TIMEOUT", "45"))

MODELS_DIR = Path(os.getenv("FITAI_MODELS_DIR", Path(__file__).resolve().parent.parent / "models"))
FACE_MATCH_THRESHOLD = float(os.getenv("FITAI_FACE_THRESHOLD", "0.40"))
