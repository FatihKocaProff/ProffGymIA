"""Örnek veri yükler (jüri sunumu ve geliştirme için).

Kullanım:  python seed.py
Mevcut veritabanını SİLMEZ; örnek kullanıcılar zaten varsa atlar.
"""
import random
from datetime import date, timedelta

from sqlalchemy import select

from app.database import SessionLocal, ensure_schema
from app.models import (
    ActivityLevel,
    CheckIn,
    CheckInMethod,
    FormSession,
    Supplement,
    Gender,
    Goal,
    Meal,
    MealType,
    Membership,
    Package,
    Role,
    User,
    WaterLog,
    WeightLog,
    Workout,
    WorkoutExercise,
)
from app.security import hash_password


def main() -> None:
    ensure_schema()
    db = SessionLocal()
    if db.scalar(select(User).where(User.email == "admin@fitai.com")):
        print("Örnek veri zaten yüklü.")
        return

    today = date.today()
    random.seed(42)

    admin = User(email="admin@fitai.com", password_hash=hash_password("admin123"),
                 full_name="Salon Yöneticisi", role=Role.admin)
    trainer = User(email="pt@fitai.com", password_hash=hash_password("pt1234"),
                   full_name="Mert Kaya", role=Role.trainer)
    db.add_all([admin, trainer])
    db.flush()

    packages = [
        Package(name="Aylık", duration_days=30, price=1500, description="Sınırsız salon kullanımı"),
        Package(name="3 Aylık", duration_days=90, price=4000, description="%11 indirimli"),
        Package(name="6 Aylık", duration_days=180, price=7200),
        Package(name="Yıllık", duration_days=365, price=12000, description="En avantajlı paket"),
    ]
    db.add_all(packages)
    db.flush()

    ayse = User(email="ayse@fitai.com", password_hash=hash_password("uye1234"), full_name="Ayşe Demir",
                role=Role.member, gender=Gender.female, birth_date=date(1999, 4, 12), height_cm=165,
                activity_level=ActivityLevel.moderate, goal=Goal.lose, trainer_id=trainer.id)
    can = User(email="can@fitai.com", password_hash=hash_password("uye1234"), full_name="Can Yılmaz",
               role=Role.member, gender=Gender.male, birth_date=date(2001, 9, 3), height_cm=180,
               activity_level=ActivityLevel.active, goal=Goal.gain, trainer_id=trainer.id)
    expired = User(email="eski@fitai.com", password_hash=hash_password("uye1234"), full_name="Süresi Biten Üye",
                   role=Role.member)
    db.add_all([ayse, can, expired])
    db.flush()

    db.add_all([
        Membership(user_id=ayse.id, package_id=packages[1].id, start_date=today - timedelta(days=40),
                   end_date=today + timedelta(days=49), price_paid=4000, sold_by_id=admin.id),
        Membership(user_id=can.id, package_id=packages[0].id, start_date=today - timedelta(days=25),
                   end_date=today + timedelta(days=4), price_paid=1500, sold_by_id=admin.id),
        Membership(user_id=expired.id, package_id=packages[0].id, start_date=today - timedelta(days=60),
                   end_date=today - timedelta(days=31), price_paid=1500, sold_by_id=admin.id),
    ])

    for i in range(30, -1, -1):
        day = today - timedelta(days=i)
        db.add(WeightLog(user_id=ayse.id, log_date=day, weight_kg=round(72 - (30 - i) * 0.08 + random.uniform(-0.3, 0.3), 1)))
        db.add(WeightLog(user_id=can.id, log_date=day, weight_kg=round(74 + (30 - i) * 0.05 + random.uniform(-0.3, 0.3), 1)))

    for user in (ayse, can):
        for ml in (500, 250, 500, 330):
            db.add(WaterLog(user_id=user.id, log_date=today, amount_ml=ml))

    sample_meals = [
        (MealType.breakfast, "Yulaf, muz, fıstık ezmesi", 420, 14, 60, 13),
        (MealType.lunch, "Izgara tavuk, bulgur pilavı, salata", 610, 48, 62, 16),
        (MealType.snack, "Yoğurt ve ceviz", 230, 12, 10, 15),
        (MealType.dinner, "Somon, fırın sebze", 520, 38, 22, 28),
    ]
    for user in (ayse, can):
        for days_ago in range(0, 3):
            for mt, desc, cal, p, c, f in sample_meals:
                db.add(Meal(user_id=user.id, meal_date=today - timedelta(days=days_ago), meal_type=mt,
                            description=desc, calories=cal, protein_g=p, carbs_g=c, fat_g=f))

    db.add(Workout(client_id=ayse.id, trainer_id=trainer.id, workout_date=today, title="Alt Vücut + Core",
                   notes="Squat'ta dizler ayak uçlarını geçmesin.",
                   exercises=[WorkoutExercise(position=0, name="Squat", sets=4, reps=12, weight_kg=30),
                              WorkoutExercise(position=1, name="Romanian Deadlift", sets=3, reps=10, weight_kg=25),
                              WorkoutExercise(position=2, name="Plank (sn)", sets=3, reps=45)]))
    db.add(Workout(client_id=can.id, trainer_id=trainer.id, workout_date=today, title="Üst Vücut - İtiş",
                   exercises=[WorkoutExercise(position=0, name="Bench Press", sets=4, reps=8, weight_kg=60),
                              WorkoutExercise(position=1, name="Biceps Curl", sets=3, reps=12, weight_kg=12)]))
    from datetime import datetime
    import json
    for days_ago, ex, reps, good, issues in [
        (9, "squat", 12, 8, {"Sırtını dik tut": 3, "Daha derine in": 1}),
        (6, "squat", 12, 10, {"Sırtını dik tut": 2}),
        (3, "squat", 12, 11, {"Dizlerini dışa it": 1}),
        (5, "biceps_curl", 12, 11, {"Dirseğini gövdene sabitle": 1}),
        (1, "biceps_curl", 12, 12, {}),
    ]:
        for user in (ayse, can):
            db.add(FormSession(user_id=user.id, recorded_by_id=trainer.id, exercise=ex, reps=reps, good_reps=good,
                               score=round(good / reps * 100, 1), duration_seconds=reps * 4,
                               issues=json.dumps(issues, ensure_ascii=False), source="desktop",
                               created_at=datetime.now() - timedelta(days=days_ago)))

    db.add_all([
        Supplement(user_id=ayse.id, name="Whey protein", dose="1 ölçek (30 g)", reminder_times="10:00", servings_left=22),
        Supplement(user_id=ayse.id, name="Kreatin", dose="5 g", reminder_times="09:00", servings_left=4),
        Supplement(user_id=can.id, name="Whey protein", dose="2 ölçek", reminder_times="08:30,20:30", servings_left=40),
    ])

    for days_ago in (0, 1, 3, 4, 6):
        db.add(CheckIn(user_id=ayse.id, method=CheckInMethod.qr, granted=True, reason="Geçiş onaylandı",
                       created_at=datetime.now() - timedelta(days=days_ago, hours=2)))
    db.add(CheckIn(user_id=expired.id, method=CheckInMethod.qr, granted=False, reason="Üyelik süresi dolmuş",
                   created_at=datetime.now() - timedelta(hours=1)))

    db.commit()
    db.close()

    print("Örnek veri yüklendi. Giriş bilgileri:")
    print("  Admin : admin@fitai.com / admin123")
    print("  PT    : pt@fitai.com    / pt1234")
    print("  Üye   : ayse@fitai.com  / uye1234  (aktif, kilo veriyor)")
    print("  Üye   : can@fitai.com   / uye1234  (aktif, kilo alıyor)")
    print("  Üye   : eski@fitai.com  / uye1234  (üyelik bitmiş → turnike reddeder)")


if __name__ == "__main__":
    main()
