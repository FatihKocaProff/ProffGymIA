@echo off
chcp 65001 >nul
cd /d "%~dp0"
title FitAI API

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Ilk kurulum yapiliyor, birkac dakika surebilir...
    python -m venv .venv || (echo Python bulunamadi. python.org'dan Python 3.11+ kur, "Add Python to PATH" kutusunu isaretle. & pause & exit /b 1)
)

fc /b requirements.txt ".venv\installed-requirements.txt" >nul 2>&1
if errorlevel 1 (
    echo [1/3] Paketler kuruluyor / guncelleniyor...
    ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt || (echo Paket kurulumu basarisiz. Internet baglantisini kontrol et. & pause & exit /b 1)
    copy /y requirements.txt ".venv\installed-requirements.txt" >nul
)

if not exist ".env" copy ".env.example" ".env" >nul

".venv\Scripts\python.exe" -m app.anahtar || (echo Gizli anahtar uretilemedi. & pause & exit /b 1)

if not exist "fitai.db" (
    echo [2/3] Ornek veri yukleniyor...
    ".venv\Scripts\python.exe" seed.py
)

echo.
echo [3/3] FitAI calisiyor
echo    Web paneli : http://127.0.0.1:8000/
echo    API dokumani: http://127.0.0.1:8000/docs
echo    Telefondan baglanmak icin asagidaki IP adreslerinden birini kullan (ayni Wi-Fi):
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do echo        http:%%a:8000
echo    Kapatmak icin bu pencereyi kapat veya Ctrl+C bas.
echo.
start "" cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8000/"
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
pause
