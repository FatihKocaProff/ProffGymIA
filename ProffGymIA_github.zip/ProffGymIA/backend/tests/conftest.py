import os
import secrets
import tempfile
from pathlib import Path

import pytest

_tmp = Path(tempfile.mkdtemp())
os.environ["FITAI_DATABASE_URL"] = f"sqlite:///{(_tmp / 'test.db').as_posix()}"
os.environ["FITAI_UPLOAD_DIR"] = str(_tmp / "uploads")
os.environ["FITAI_AI_PROVIDER"] = "demo"
os.environ["FITAI_SECRET_KEY"] = secrets.token_urlsafe(48)
os.environ["FITAI_CORS_ORIGINS"] = "https://izinli.example"

from fastapi.testclient import TestClient

from app.database import Base, SessionLocal, engine
from app.main import app
from app.models import Role, User
from app.security import hash_password


@pytest.fixture()
def client():
    import giris_siniri

    giris_siniri.reset()
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    db.add_all([
        User(email="admin@test.com", password_hash=hash_password("admin123"), full_name="Admin", role=Role.admin),
        User(email="pt@test.com", password_hash=hash_password("pt1234"), full_name="PT", role=Role.trainer),
    ])
    db.commit()
    db.close()
    with TestClient(app) as c:
        yield c


def login(client, email, password) -> dict:
    r = client.post("/auth/login", data={"username": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}
