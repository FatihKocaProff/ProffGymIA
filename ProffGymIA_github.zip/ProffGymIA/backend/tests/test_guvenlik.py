"""Güvenlik düzeltmeleri: giriş denemesi sınırı, imzalı dosya adresi, gizli anahtar."""
from app import config
from app.security import sign_upload_path, verify_upload_path


def test_login_locks_after_repeated_failures(client):
    for _ in range(5):
        r = client.post("/auth/login", data={"username": "admin@test.com", "password": "yanlis"})
        assert r.status_code == 401
    r = client.post("/auth/login", data={"username": "admin@test.com", "password": "admin123"})
    assert r.status_code == 429 and "Retry-After" in r.headers
    assert client.post("/auth/login", data={"username": "pt@test.com", "password": "yanlis"}).status_code == 401


def test_upload_signature_rejects_tampering(client):
    signed = sign_upload_path("meals/1/a.jpg")
    assert sign_upload_path(signed) == signed
    q = dict(part.split("=") for part in signed.split("?")[1].split("&"))
    assert verify_upload_path("meals/1/a.jpg", int(q["exp"]), q["sig"])
    assert not verify_upload_path("meals/2/a.jpg", int(q["exp"]), q["sig"])
    assert not verify_upload_path("meals/1/a.jpg", 1, q["sig"])
    assert client.get("/uploads/../.env").status_code in (403, 404)


def test_secret_key_is_strong():
    assert len(config.SECRET_KEY) >= 32 and config.SECRET_KEY != "gelistirme-anahtari-degistir"


def test_key_generator_writes_only_when_needed(tmp_path):
    from app.anahtar import env_anahtari_hazirla, guclu_mu

    env = tmp_path / ".env"
    env.write_text("# yorum\nFITAI_SECRET_KEY=\nGEMINI_API_KEY=abc\n", encoding="utf-8")
    assert env_anahtari_hazirla(env) is True
    lines = env.read_text(encoding="utf-8").splitlines()
    assert lines[0] == "# yorum" and lines[2] == "GEMINI_API_KEY=abc"
    key = lines[1].split("=", 1)[1]
    assert guclu_mu(key)
    assert env_anahtari_hazirla(env) is False
    assert env.read_text(encoding="utf-8").splitlines()[1] == f"FITAI_SECRET_KEY={key}"

    env.write_text("FITAI_SECRET_KEY=gelistirme-anahtari-degistir\n", encoding="utf-8")
    assert env_anahtari_hazirla(env) is True

    missing = tmp_path / "yok.env"
    assert env_anahtari_hazirla(missing) is True and guclu_mu(missing.read_text().split("=", 1)[1].strip())


def test_cors_only_allows_configured_origins(client):
    preflight = {"Access-Control-Request-Method": "GET"}
    ok = client.options("/health", headers={"Origin": "https://izinli.example", **preflight})
    assert ok.headers.get("access-control-allow-origin") == "https://izinli.example"
    bad = client.options("/health", headers={"Origin": "https://kotu.example", **preflight})
    assert "access-control-allow-origin" not in bad.headers
    assert client.get("/health", headers={"Origin": "https://kotu.example"}).headers.get("access-control-allow-origin") is None
