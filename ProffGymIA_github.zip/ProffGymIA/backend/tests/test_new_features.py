"""Profil fotoğrafı, yazılan öğünden otomatik kalori ve 'bitmek üzere' üyelikler."""
import io
from datetime import date, timedelta

from conftest import login
from PIL import Image

from app.services.food_text import analyze_text_local


def _register_member(client, email="uye@test.com"):
    r = client.post("/auth/register", json={"email": email, "password": "uye1234", "full_name": "Test Üye"})
    assert r.status_code == 201, r.text
    return r.json()["id"], login(client, email, "uye1234")


def _jpeg(w=800, h=600, color=(200, 40, 40)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (w, h), color).save(buf, "JPEG")
    return buf.getvalue()


def _by_name(result):
    return {i["name"].split(" (")[0]: i for i in result["items"]}


def test_local_food_text_quantities_and_units():
    r = analyze_text_local("2 yumurta, 1 dilim ekmek, 30 g beyaz peynir ve 1 bardak çay")
    items = _by_name(r)
    assert set(items) == {"Yumurta", "Ekmek", "Beyaz peynir", "Çay"}
    assert items["Yumurta"]["portion_g"] == 100 and items["Yumurta"]["calories"] == 143
    assert items["Ekmek"]["portion_g"] == 25
    assert items["Beyaz peynir"]["portion_g"] == 30
    assert r["confidence"] == "yüksek" and r["unmatched"] == []


def test_local_food_text_turkish_suffixes_and_trailing_amounts():
    assert _by_name(analyze_text_local("tavuk 200 gr"))["Tavuk göğsü"]["portion_g"] == 200
    assert _by_name(analyze_text_local("yumurta 3 adet"))["Yumurta"]["portion_g"] == 150
    assert set(_by_name(analyze_text_local("tavuğu pilavla yedim"))) == {"Tavuk göğsü", "Pirinç pilavı"}
    assert _by_name(analyze_text_local("1 kase mercimek çorbası"))["Mercimek çorbası"]["portion_g"] == 300
    assert _by_name(analyze_text_local("1,5 dilim ekmek"))["Ekmek"]["portion_g"] == 38
    assert _by_name(analyze_text_local("yarım ekmek"))["Ekmek"]["portion_g"] == 125


def test_local_food_text_edge_cases():
    assert set(_by_name(analyze_text_local("1 çay bardağı süt"))) == {"Süt"}
    assert set(_by_name(analyze_text_local("şekersiz çay"))) == {"Çay"}
    assert set(_by_name(analyze_text_local("şekerli çay"))) == {"Çay", "Şeker"}
    assert set(_by_name(analyze_text_local("1 yemek kaşığı zeytinyağı"))) == {"Zeytinyağı / sıvı yağ"}
    r = analyze_text_local("kinoa")
    assert r["items"] == [] and r["unmatched"] == ["kinoa"] and r["confidence"] == "düşük"
    r = analyze_text_local("İskender")
    assert r["items"] and r["confidence"] == "orta" and "porsiyon" in r["note"]


def test_food_text_endpoint_preview(client):
    _, h = _register_member(client)
    r = client.post("/ai/food-text", headers=h, json={"text": "2 yumurta, 1 dilim ekmek, kinoa"})
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["provider"] == "yerel" and data["totals"]["calories"] == 143 + 66
    assert data["unmatched"] == ["kinoa"]
    assert client.post("/ai/food-text", headers=h, json={"text": ""}).status_code == 422
    assert client.post("/ai/food-text", json={"text": "yumurta"}).status_code == 401


def test_meal_without_calories_is_calculated_from_text(client):
    _, h = _register_member(client)
    r = client.post("/meals", headers=h, json={"meal_type": "breakfast", "description": "2 yumurta, 1 dilim ekmek"})
    assert r.status_code == 201, r.text
    meal = r.json()
    assert meal["calories"] == 209 and meal["protein_g"] > 10
    assert meal["source"] == "auto" and len(meal["ai_detail"]["items"]) == 2
    assert client.get("/meals/summary", headers=h).json()["calories"] == 209

    r = client.post("/meals", headers=h, json={"meal_type": "lunch"})
    assert r.status_code == 422 and "yaz" in r.json()["detail"]
    r = client.post("/meals", headers=h, json={"description": "xyzzy"})
    assert r.status_code == 422
    meal = client.post("/meals", headers=h, json={"protein_g": 10, "carbs_g": 20, "fat_g": 5}).json()
    assert meal["calories"] == 10 * 4 + 20 * 4 + 5 * 9
    meal = client.post("/meals", headers=h, json={"description": "2 yumurta", "calories": 999}).json()
    assert meal["calories"] == 999 and meal["source"] == "manual"


def test_meal_saved_with_preview_analysis_keeps_breakdown(client):
    _, h = _register_member(client)
    preview = client.post("/ai/food-text", headers=h, json={"text": "1 muz", "quick": True}).json()
    t = preview["totals"]
    meal = client.post("/meals", headers=h, json={
        "description": "1 muz", "calories": t["calories"], "protein_g": t["protein_g"],
        "carbs_g": t["carbs_g"], "fat_g": t["fat_g"], "analysis": preview}).json()
    assert meal["source"] == "auto" and meal["ai_detail"]["items"][0]["name"].startswith("Muz")
    meal = client.post("/meals", headers=h, json={"description": "x", "calories": 1, "analysis": {**preview, "provider": "hack"}}).json()
    assert meal["source"] == "auto" and meal["ai_detail"]["provider"] == "yerel"


def test_profile_photo_upload_resize_and_delete(client):
    member_id, h = _register_member(client)
    assert client.get("/users/me", headers=h).json()["photo_path"] is None

    r = client.post("/users/me/photo", headers=h, files={"photo": ("ben.jpg", _jpeg(), "image/jpeg")})
    assert r.status_code == 200, r.text
    path = r.json()["photo_path"]
    bare = path.split("?")[0]
    assert bare.startswith(f"profiles/{member_id}/") and bare.endswith(".jpg") and "sig=" in path

    served = client.get(f"/uploads/{path}")
    assert served.status_code == 200
    assert client.get(f"/uploads/{bare}").status_code == 403
    assert client.get(f"/uploads/{path[:-1]}x").status_code == 403
    assert Image.open(io.BytesIO(served.content)).size == (400, 400)

    new_path = client.post("/users/me/photo", headers=h, files={"photo": ("b.png", _jpeg(300, 900), "image/jpeg")}).json()["photo_path"]
    assert new_path != path and client.get(f"/uploads/{path}").status_code == 404

    assert client.post("/users/me/photo", headers=h, files={"photo": ("x.txt", b"abc", "text/plain")}).status_code == 415
    assert client.post("/users/me/photo", headers=h, files={"photo": ("x.jpg", b"bozuk", "image/jpeg")}).status_code == 400

    r = client.delete("/users/me/photo", headers=h)
    assert r.status_code == 200 and r.json()["photo_path"] is None
    assert client.get(f"/uploads/{new_path}").status_code == 404


def test_admin_sets_member_photo_and_lists_show_it(client):
    member_id, h_member = _register_member(client)
    other_id, _ = _register_member(client, "baska@test.com")
    h_admin = login(client, "admin@test.com", "admin123")

    assert client.post(f"/users/{other_id}/photo", headers=h_member,
                       files={"photo": ("a.jpg", _jpeg(), "image/jpeg")}).status_code == 403
    r = client.post(f"/users/{member_id}/photo", headers=h_admin, files={"photo": ("a.jpg", _jpeg(), "image/jpeg")})
    assert r.status_code == 200
    path = r.json()["photo_path"]

    rows = {m["id"]: m for m in client.get("/overview/members", headers=h_admin).json()}
    assert rows[member_id]["photo_path"] == path and rows[other_id]["photo_path"] is None
    assert client.get(f"/users/{member_id}", headers=h_admin).json()["photo_path"] == path
    assert client.delete(f"/users/{member_id}/photo", headers=h_admin).json()["photo_path"] is None
    assert client.post("/users/999/photo", headers=h_admin, files={"photo": ("a.jpg", _jpeg(), "image/jpeg")}).status_code == 404


def test_expiring_soon_members_have_remaining_days(client):
    soon_id, _ = _register_member(client, "yakinda@test.com")
    later_id, _ = _register_member(client, "sonra@test.com")
    h_admin = login(client, "admin@test.com", "admin123")
    short = client.post("/packages", headers=h_admin, json={"name": "Haftalık", "duration_days": 5, "price": 300}).json()
    month = client.post("/packages", headers=h_admin, json={"name": "Aylık", "duration_days": 30, "price": 1500}).json()
    client.post("/memberships", headers=h_admin, json={"user_id": soon_id, "package_id": short["id"]})
    client.post("/memberships", headers=h_admin, json={"user_id": later_id, "package_id": month["id"]})

    stats = client.get("/overview/stats", headers=h_admin).json()
    assert stats["active_members"] == 2 and stats["expiring_soon"] == 1

    rows = {m["id"]: m for m in client.get("/overview/members", headers=h_admin).json()}
    assert rows[soon_id]["remaining_days"] == 5 and rows[soon_id]["active"] is True
    assert rows[soon_id]["end_date"] == (date.today() + timedelta(days=4)).isoformat()
    assert rows[later_id]["remaining_days"] == 30
