from datetime import date, timedelta

from conftest import login


def _register_member(client, email="uye@test.com"):
    r = client.post("/auth/register", json={"email": email, "password": "uye1234", "full_name": "Test Üye"})
    assert r.status_code == 201, r.text
    return r.json()["id"], login(client, email, "uye1234")


def test_register_login_and_duplicate(client):
    _register_member(client)
    r = client.post("/auth/register", json={"email": "UYE@test.com", "password": "uye1234", "full_name": "X Y"})
    assert r.status_code == 409
    r = client.post("/auth/login", data={"username": "uye@test.com", "password": "yanlis"})
    assert r.status_code == 401


def test_protected_endpoint_requires_token(client):
    assert client.get("/users/me").status_code == 401


def test_profile_weight_and_metabolism(client):
    _, h = _register_member(client)
    r = client.get("/users/me/metabolism", headers=h)
    assert r.status_code == 422

    client.patch("/users/me", headers=h, json={
        "gender": "male", "birth_date": "2000-01-01", "height_cm": 180,
        "activity_level": "moderate", "goal": "maintain"})
    r = client.post("/weights", headers=h, json={"weight_kg": 80})
    assert r.status_code == 201
    client.post("/weights", headers=h, json={"weight_kg": 79.5})
    weights = client.get("/weights", headers=h).json()
    assert len(weights) == 1 and weights[0]["weight_kg"] == 79.5

    m = client.get("/users/me/metabolism", headers=h).json()
    assert m["bmr"] > 1500 and m["tdee"] > m["bmr"] and m["water_ml"] > 0


def test_membership_sale_extension_and_status(client):
    member_id, h_member = _register_member(client)
    h_admin = login(client, "admin@test.com", "admin123")

    pkg = client.post("/packages", headers=h_admin, json={"name": "Aylık", "duration_days": 30, "price": 1500}).json()
    assert client.get("/packages").json()[0]["name"] == "Aylık"

    assert client.post("/memberships", headers=h_member, json={"user_id": member_id, "package_id": pkg["id"]}).status_code == 403

    status = client.get("/memberships/status", headers=h_member).json()
    assert status["active"] is False and status["remaining_days"] == 0

    m1 = client.post("/memberships", headers=h_admin, json={"user_id": member_id, "package_id": pkg["id"]}).json()
    assert m1["start_date"] == date.today().isoformat()
    m2 = client.post("/memberships", headers=h_admin, json={"user_id": member_id, "package_id": pkg["id"], "price_paid": 1200}).json()
    assert m2["start_date"] == (date.fromisoformat(m1["end_date"]) + timedelta(days=1)).isoformat()
    assert m2["price_paid"] == 1200

    status = client.get("/memberships/status", headers=h_member).json()
    assert status["active"] is True and status["remaining_days"] == 60


def test_qr_checkin_granted_and_denied(client):
    member_id, h_member = _register_member(client)
    h_admin = login(client, "admin@test.com", "admin123")

    token = client.get("/checkin/qr-token", headers=h_member).json()["token"]
    r = client.post("/checkin/qr", headers=h_admin, json={"token": token}).json()
    assert r["granted"] is False and "dolmuş" in r["reason"]

    pkg = client.post("/packages", headers=h_admin, json={"name": "Aylık", "duration_days": 30, "price": 1500}).json()
    client.post("/memberships", headers=h_admin, json={"user_id": member_id, "package_id": pkg["id"]})
    r = client.post("/checkin/qr", headers=h_admin, json={"token": token}).json()
    assert r["granted"] is True and r["remaining_days"] == 30

    r = client.post("/checkin/qr", headers=h_admin, json={"token": "sahte"}).json()
    assert r["granted"] is False

    assert client.post("/checkin/qr", headers=h_member, json={"token": token}).status_code == 403
    assert len(client.get("/checkin/logs", headers=h_admin).json()) == 3


def test_trainer_access_only_own_clients(client):
    member_id, h_member = _register_member(client)
    other_id, _ = _register_member(client, "baska@test.com")
    h_admin = login(client, "admin@test.com", "admin123")
    h_pt = login(client, "pt@test.com", "pt1234")
    pt_id = client.get("/users/me", headers=h_pt).json()["id"]

    client.post("/meals", headers=h_member, json={"calories": 500, "protein_g": 30, "carbs_g": 50, "fat_g": 15})

    assert client.get(f"/meals?user_id={member_id}", headers=h_pt).status_code == 403
    client.patch(f"/users/{member_id}/trainer", headers=h_admin, json={"trainer_id": pt_id})

    meals = client.get(f"/meals?user_id={member_id}", headers=h_pt).json()
    assert len(meals) == 1 and meals[0]["calories"] == 500
    assert client.get(f"/meals?user_id={other_id}", headers=h_pt).status_code == 403

    clients = client.get("/users", headers=h_pt).json()
    assert [u["id"] for u in clients] == [member_id]

    r = client.post("/workouts", headers=h_pt, json={
        "client_id": member_id, "workout_date": date.today().isoformat(), "title": "Bacak",
        "exercises": [{"name": "Squat", "sets": 4, "reps": 10, "weight_kg": 40}, {"name": "Lunge"}]})
    assert r.status_code == 201
    w = client.get("/workouts", headers=h_member).json()
    assert len(w) == 1 and [e["name"] for e in w[0]["exercises"]] == ["Squat", "Lunge"]
    assert client.post("/workouts", headers=h_pt, json={
        "client_id": other_id, "workout_date": date.today().isoformat(), "title": "X"}).status_code == 403


def test_water_and_nutrition_summary(client):
    _, h = _register_member(client)
    client.post("/water", headers=h, json={"amount_ml": 500})
    r = client.post("/water", headers=h, json={"amount_ml": 250}).json()
    assert r["total_ml"] == 750 and r["entries"] == 2

    client.post("/meals", headers=h, json={"meal_type": "breakfast", "calories": 400, "protein_g": 20, "carbs_g": 50, "fat_g": 10})
    client.post("/meals", headers=h, json={"meal_type": "lunch", "calories": 600, "protein_g": 40, "carbs_g": 60, "fat_g": 20})
    s = client.get("/meals/summary", headers=h).json()
    assert s["calories"] == 1000 and s["protein_g"] == 60 and s["meal_count"] == 2


def test_meal_photo_upload(client):
    _, h = _register_member(client)
    png = b"\x89PNG\r\n\x1a\n" + b"0" * 32
    r = client.post("/meals/photo", headers=h, files={"photo": ("tabak.png", png, "image/png")},
                    data={"meal_type": "lunch"})
    assert r.status_code == 201 and r.json()["photo_path"].split("?")[0].endswith(".png")
    r = client.post("/meals/photo", headers=h, files={"photo": ("x.txt", b"abc", "text/plain")})
    assert r.status_code == 415


def test_panel_overview_and_static(client):
    member_id, _ = _register_member(client)
    h_admin = login(client, "admin@test.com", "admin123")
    h_pt = login(client, "pt@test.com", "pt1234")

    stats = client.get("/overview/stats", headers=h_admin).json()
    assert stats["total_members"] == 1 and stats["active_members"] == 0
    assert client.get("/overview/stats", headers=h_pt).status_code == 403

    rows = client.get("/overview/members", headers=h_admin).json()
    assert rows[0]["id"] == member_id and rows[0]["active"] is False
    assert client.get("/overview/members", headers=h_pt).json() == []

    page = client.get("/panel/")
    assert page.status_code == 200 and "FitAI" in page.text
    assert client.get("/", follow_redirects=False).status_code in (302, 307)


def test_meal_photo_ai_demo_fills_macros(client):
    _, h = _register_member(client)
    png = b"\x89PNG\r\n\x1a\n" + b"1" * 64
    meal = client.post("/meals/photo", headers=h, files={"photo": ("t.png", png, "image/png")}).json()
    assert meal["source"] == "ai" and meal["calories"] > 0
    assert meal["ai_detail"]["provider"] == "demo" and meal["ai_detail"]["items"]
    meal2 = client.post("/meals/photo", headers=h, files={"photo": ("t.png", png, "image/png")}, data={"analyze": "false"}).json()
    assert meal2["calories"] == 0 and meal2["source"] == "manual"
    preview = client.post("/ai/food", headers=h, files={"photo": ("t.png", png, "image/png")}).json()
    assert preview["totals"]["calories"] == meal["calories"]
    assert client.get("/ai/status", headers=h).json()["food_provider"] == "demo"


def test_form_sessions_and_trainer_recording(client):
    member_id, h_member = _register_member(client)
    h_admin = login(client, "admin@test.com", "admin123")
    h_pt = login(client, "pt@test.com", "pt1234")
    pt_id = client.get("/users/me", headers=h_pt).json()["id"]

    r = client.post("/form-sessions", headers=h_member, json={"exercise": "squat", "reps": 10, "good_reps": 8, "issues": {"Sırtını dik tut": 2}})
    assert r.status_code == 201 and r.json()["score"] == 80
    body = {"user_id": member_id, "exercise": "biceps_curl", "reps": 12, "good_reps": 12, "source": "desktop"}
    assert client.post("/form-sessions", headers=h_pt, json=body).status_code == 403
    client.patch(f"/users/{member_id}/trainer", headers=h_admin, json={"trainer_id": pt_id})
    assert client.post("/form-sessions", headers=h_pt, json=body).status_code == 201
    sessions = client.get(f"/form-sessions?user_id={member_id}", headers=h_pt).json()
    assert len(sessions) == 2 and sessions[-1]["issues"] == {"Sırtını dik tut": 2}


def test_supplements_take_and_stock(client):
    _, h = _register_member(client)
    s = client.post("/supplements", headers=h, json={"name": "Kreatin", "dose": "5 g", "reminder_times": ["21:00", "09:00"], "servings_left": 6}).json()
    assert s["reminder_times"] == ["09:00", "21:00"] and s["low_stock"] is False
    s = client.post(f"/supplements/{s['id']}/take", headers=h).json()
    assert s["servings_left"] == 5 and s["taken_today"] == 1 and s["low_stock"] is True
    assert client.post("/supplements", headers=h, json={"name": "X", "reminder_times": ["25:00"]}).status_code == 422
    s = client.patch(f"/supplements/{s['id']}", headers=h, json={"servings_left": 0}).json()
    assert client.post(f"/supplements/{s['id']}/take", headers=h).status_code == 409
    assert client.delete(f"/supplements/{s['id']}", headers=h).status_code == 204
    assert client.get("/supplements", headers=h).json() == []


def test_monthly_pdf_report(client):
    member_id, h = _register_member(client)
    client.patch("/users/me", headers=h, json={"gender": "female", "birth_date": "1999-04-12", "height_cm": 165, "goal": "lose"})
    client.post("/weights", headers=h, json={"weight_kg": 70, "log_date": date.today().replace(day=1).isoformat()})
    client.post("/weights", headers=h, json={"weight_kg": 69.2})
    client.post("/meals", headers=h, json={"calories": 1600, "protein_g": 120, "carbs_g": 150, "fat_g": 50})
    r = client.get("/reports/monthly", headers=h)
    assert r.status_code == 200 and r.headers["content-type"] == "application/pdf" and r.content[:4] == b"%PDF"
    h_admin = login(client, "admin@test.com", "admin123")
    assert client.get(f"/reports/monthly?user_id={member_id}&month=2020-01", headers=h_admin).status_code == 200
    assert client.get("/reports/monthly?month=2999-01", headers=h).status_code == 400


def test_face_checkin_without_face_is_not_logged(client):
    import pytest
    from app.services import face

    if not all((face.config.MODELS_DIR / n).exists() for n in face.MODEL_URLS):
        pytest.skip("Yüz modelleri indirilmemiş (ilk turnike kullanımında otomatik iner)")
    import cv2
    import numpy as np

    h_admin = login(client, "admin@test.com", "admin123")
    blank = cv2.imencode(".jpg", np.full((240, 320, 3), 200, np.uint8))[1].tobytes()
    r = client.post("/checkin/face", headers=h_admin, files={"frame": ("f.jpg", blank, "image/jpeg")}).json()
    assert r["face_found"] is False
    assert client.get("/checkin/logs", headers=h_admin).json() == []



def test_admin_makes_member_trainer_and_back(client):
    member_id, h_member = _register_member(client)
    assert client.get("/users/me", headers=h_member).json()["role"] == "member"
    h_admin = login(client, "admin@test.com", "admin123")
    h_pt = login(client, "pt@test.com", "pt1234")
    admin_id = client.get("/users/me", headers=h_admin).json()["id"]

    assert client.patch(f"/users/{member_id}/role", headers=h_pt, json={"role": "trainer"}).status_code == 403
    assert client.patch(f"/users/{member_id}/role", headers=h_member, json={"role": "trainer"}).status_code == 403
    assert client.patch(f"/users/{member_id}/role", headers=h_admin, json={"role": "admin"}).status_code == 400
    assert client.patch(f"/users/{admin_id}/role", headers=h_admin, json={"role": "member"}).status_code == 400
    assert client.patch("/users/9999/role", headers=h_admin, json={"role": "trainer"}).status_code == 404

    pt_id = client.get("/users/me", headers=h_pt).json()["id"]
    client.patch(f"/users/{member_id}/trainer", headers=h_admin, json={"trainer_id": pt_id})
    r = client.patch(f"/users/{member_id}/role", headers=h_admin, json={"role": "trainer"})
    assert r.status_code == 200 and r.json()["role"] == "trainer" and r.json()["trainer_id"] is None
    assert member_id in [t["id"] for t in client.get("/users?role=trainer", headers=h_admin).json()]
    assert member_id not in [m["id"] for m in client.get("/overview/members", headers=h_admin).json()]

    client_id, _ = _register_member(client, "danisan@test.com")
    assert client.patch(f"/users/{client_id}/trainer", headers=h_admin, json={"trainer_id": member_id}).status_code == 200
    h_new_pt = login(client, "uye@test.com", "uye1234")
    assert [u["id"] for u in client.get("/users", headers=h_new_pt).json()] == [client_id]

    r = client.patch(f"/users/{member_id}/role", headers=h_admin, json={"role": "member"})
    assert r.status_code == 200 and r.json()["role"] == "member"
    assert client.get(f"/users/{client_id}", headers=h_admin).json()["trainer_id"] is None
    assert client.get("/users", headers=h_new_pt).status_code == 403


def test_first_setup_creates_admin_only_once(client):
    from app.database import SessionLocal
    from app.models import Role, User

    owner = {"email": "sahip@test.com", "password": "sahip123", "full_name": "Salon Sahibi"}
    assert client.get("/auth/setup").json() == {"needs_admin": False}
    assert client.post("/auth/setup-admin", json=owner).status_code == 403

    db = SessionLocal()
    db.query(User).filter(User.role == Role.admin).delete()
    db.commit()
    db.close()

    assert client.get("/auth/setup").json()["needs_admin"] is True
    r = client.post("/auth/setup-admin", json=owner)
    assert r.status_code == 201 and r.json()["role"] == "admin"
    h_owner = login(client, "sahip@test.com", "sahip123")
    assert client.get("/overview/stats", headers=h_owner).status_code == 200
    assert client.get("/auth/setup").json()["needs_admin"] is False
    assert client.post("/auth/setup-admin", json={**owner, "email": "ikinci@test.com"}).status_code == 403
    _register_member(client, "yeni@test.com")


def test_old_pending_registrations_become_members(client):
    """Ara sürümde 'onay bekleyen PT' olarak kalmış hesaplar açılışta üyeye çevrilir."""
    from sqlalchemy import text

    from app.database import convert_pending_registrations, engine

    assert convert_pending_registrations() == 0
    _register_member(client, "bekleyen@test.com")
    with engine.begin() as conn:
        conn.execute(text("ALTER TABLE users ADD COLUMN approval_pending BOOLEAN DEFAULT FALSE"))
        conn.execute(text("UPDATE users SET role = 'trainer', is_active = 0, approval_pending = 1 WHERE email = 'bekleyen@test.com'"))
    assert client.post("/auth/login", data={"username": "bekleyen@test.com", "password": "uye1234"}).status_code == 403
    assert convert_pending_registrations() == 1
    h = login(client, "bekleyen@test.com", "uye1234")
    assert client.get("/users/me", headers=h).json()["role"] == "member"
    assert client.get("/users/me", headers=login(client, "pt@test.com", "pt1234")).json()["role"] == "trainer"
