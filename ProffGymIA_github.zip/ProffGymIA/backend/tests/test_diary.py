"""Kepçe diyet defteri: kalemlerin FitAI tablolarına yazılması, dış kayıtlar, profil aktarımı, sıfırlama."""
from datetime import date

from conftest import login

TODAY = date.today().isoformat()
META = {
    "version": 1, "createdAt": 1, "favorites": ["ayran"], "userFoods": [], "settings": {"showCalories": True},
    "consents": [], "goals": [{"start": TODAY, "calories": 1800}],
    "profile": {"sex": "female", "birth": "1990-03-14", "height": 165, "weight": 72, "activity": "light", "goal": "lose"},
}


def _member(client, email="defter@test.com"):
    r = client.post("/auth/register", json={"email": email, "password": "uye1234", "full_name": "Defter Üye"})
    assert r.status_code == 201, r.text
    return r.json()["id"], login(client, email, "uye1234")


def _entry(**kw):
    e = {"id": "e1", "date": TODAY, "meal": "lunch", "name": "Mercimek çorbası", "description": "Mercimek çorbası · 1 kase",
         "kcal": 140, "p": 8.5, "c": 21.3, "f": 3, "foodId": "mercimek", "unit": 0, "qty": 1, "grams": 250,
         "unitLabel": "1 kase", "source": "search", "planned": False, "deleted": False, "createdAt": 5}
    e.update(kw)
    return e


def test_diary_writes_to_fitai_tables_and_round_trips(client):
    _, h = _member(client)
    state = client.get("/diary/state", headers=h).json()
    assert state["meta"] is None and state["entries"] == []

    r = client.put("/diary/sync", headers=h, json={
        "meta": META, "apply_profile": True, "entries": [_entry()],
        "water": [{"id": "w1", "date": TODAY, "ml": 250, "at": 1, "deleted": False}],
        "weights": [{"date": TODAY, "kg": 72}],
    })
    assert r.status_code == 204, r.text

    meals = client.get("/meals", headers=h).json()
    assert len(meals) == 1 and meals[0]["source"] == "diary" and meals[0]["description"] == "Mercimek çorbası · 1 kase"
    assert client.get("/meals/summary", headers=h).json()["calories"] == 140
    assert client.get("/water", headers=h).json()["total_ml"] == 250
    me = client.get("/users/me", headers=h).json()
    assert me["gender"] == "female" and me["height_cm"] == 165 and me["goal"] == "lose" and me["activity_level"] == "light"

    state = client.get("/diary/state", headers=h).json()
    assert state["meta"]["favorites"] == ["ayran"]
    e = state["entries"][0]
    assert e["id"] == "e1" and e["foodId"] == "mercimek" and e["qty"] == 1 and e["kcal"] == 140
    assert state["water"][0]["id"] == "w1" and state["weights"] == [{"date": TODAY, "kg": 72.0}]

    client.put("/diary/sync", headers=h, json={"entries": [_entry(qty=2, kcal=280, meal="dinner")]})
    meal = client.get("/meals", headers=h).json()[0]
    assert meal["calories"] == 280 and meal["meal_type"] == "dinner"
    client.put("/diary/sync", headers=h, json={"entries": [_entry(deleted=True)],
                                               "water": [{"id": "w1", "date": TODAY, "ml": 250, "deleted": True}]})
    assert client.get("/meals", headers=h).json() == []
    assert client.get("/water", headers=h).json()["total_ml"] == 0


def test_meals_from_other_screens_show_in_diary_read_only(client):
    _, h = _member(client)
    mid = client.post("/meals", headers=h, json={"meal_type": "breakfast", "description": "Mobilden kahvaltı", "calories": 400}).json()["id"]
    e = client.get("/diary/state", headers=h).json()["entries"][0]
    assert e["id"] == f"meal-{mid}" and e["source"] == "fitai" and e["kcal"] == 400

    client.put("/diary/sync", headers=h, json={"entries": [{**e, "kcal": 1}]})
    assert client.get("/meals", headers=h).json()[0]["calories"] == 400
    client.put("/diary/sync", headers=h, json={"entries": [{**e, "deleted": True}]})
    assert client.get("/meals", headers=h).json() == []
    client.put("/diary/sync", headers=h, json={"entries": [e]})
    assert [x["id"] for x in client.get("/diary/state", headers=h).json()["entries"]] == [f"meal-{mid}"]
    assert client.get("/meals", headers=h).json()[0]["source"] == "manual"


def test_cannot_touch_other_users_meals(client):
    _, h_other = _member(client, "baska@test.com")
    mid = client.post("/meals", headers=h_other, json={"meal_type": "lunch", "calories": 500}).json()["id"]
    _, h = _member(client)
    r = client.put("/diary/sync", headers=h, json={"entries": [_entry(id=f"meal-{mid}", deleted=True)]})
    assert r.status_code == 204
    assert len(client.get("/meals", headers=h_other).json()) == 1


def test_reset_keeps_weights_and_outside_meals(client):
    _, h = _member(client)
    client.post("/meals", headers=h, json={"meal_type": "lunch", "calories": 500})
    client.put("/diary/sync", headers=h, json={"meta": META, "entries": [_entry()], "weights": [{"date": TODAY, "kg": 70}]})
    assert client.delete("/diary", headers=h).status_code == 204
    state = client.get("/diary/state", headers=h).json()
    assert state["meta"] is None
    assert [e["source"] for e in state["entries"]] == ["fitai"]
    assert state["weights"] == [{"date": TODAY, "kg": 70.0}]
    assert state["prefill"]["weight"] == 70.0


def test_diary_page_is_served(client):
    r = client.get("/panel/diyet/")
    assert r.status_code == 200 and "/diary/state" in r.text
