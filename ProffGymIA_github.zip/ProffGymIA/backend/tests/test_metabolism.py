from datetime import date

from app.services.metabolism import calculate_age, calculate_metabolism, mifflin_st_jeor


def test_mifflin_male():
    assert mifflin_st_jeor(80, 180, 25, "male") == 1805


def test_mifflin_female():
    assert mifflin_st_jeor(60, 165, 30, "female") == 1320.25


def test_age_before_and_after_birthday():
    assert calculate_age(date(2000, 6, 15), today=date(2026, 6, 14)) == 25
    assert calculate_age(date(2000, 6, 15), today=date(2026, 6, 15)) == 26


def test_full_metabolism_lose_goal():
    r = calculate_metabolism(weight_kg=80, height_cm=180, age=25, gender="male",
                             activity_level="moderate", goal="lose")
    assert r.bmr == 1805
    assert r.tdee == round(1805 * 1.55)
    assert r.target_calories == round(1805 * 1.55 - 500)
    assert r.protein_g == 160
    assert abs(r.protein_g * 4 + r.carbs_g * 4 + r.fat_g * 9 - r.target_calories) <= 10
    assert r.water_ml == 2800
    assert r.bmi == 24.7 and r.bmi_category == "Normal"


def test_minimum_calorie_floor():
    r = calculate_metabolism(weight_kg=45, height_cm=150, age=60, gender="female",
                             activity_level="sedentary", goal="lose")
    assert r.target_calories == 1200
