#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if [ ! -x ".venv/bin/python" ]; then
  echo "[1/3] Ilk kurulum yapiliyor..."
  python3 -m venv .venv
fi

if ! cmp -s requirements.txt .venv/installed-requirements.txt; then
  echo "[1/3] Paketler kuruluyor / guncelleniyor..."
  .venv/bin/python -m pip install --upgrade pip >/dev/null
  .venv/bin/python -m pip install -r requirements.txt
  cp requirements.txt .venv/installed-requirements.txt
fi

[ -f .env ] || cp .env.example .env

.venv/bin/python -m app.anahtar

if [ ! -f "fitai.db" ]; then
  echo "[2/3] Ornek veri yukleniyor..."
  .venv/bin/python seed.py
fi

echo "[3/3] Web paneli: http://127.0.0.1:8000/   API: http://127.0.0.1:8000/docs"
( sleep 3; (open http://127.0.0.1:8000/ 2>/dev/null || xdg-open http://127.0.0.1:8000/ 2>/dev/null) ) &
.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
