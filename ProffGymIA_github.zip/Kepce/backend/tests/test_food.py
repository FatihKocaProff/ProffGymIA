"""Yazılan öğünden kalori (yerel besin tablosu) ve yapay zeka uçları."""
from conftest import register

from app.services.food_text import analyze_text_local


def _by_name(result):
    return {i["name"].split(" (")[0]: i for i in result["items"]}


def test_local_food_text_quantities_and_units():
    r = analyze_text_local("2 yumurta, 1 dilim ekmek, 30 g beyaz peynir ve 1 bardak çay")
    items = _by_name(r)
    assert set(items) == {"Yumurta", "Ekmek", "Beyaz peynir", "Çay"}
    assert items["Yumurta"]["portion_g"] == 100 and items["Yumurta"]["calories"] == 143
    assert items["Ekmek"]["portion_g"] == 25
    assert items["Beyaz peynir"]["portion_g"] == 30
    assert r["confidence"] == "yüksek" and r["unmatched"] == []


def test_local_food_text_turkish_suffixes_and_trailing_amounts():
    assert _by_name(analyze_text_local("tavuk 200 gr"))["Tavuk göğsü"]["portion_g"] == 200
    assert _by_name(analyze_text_local("yumurta 3 adet"))["Yumurta"]["portion_g"] == 150
    assert set(_by_name(analyze_text_local("tavuğu pilavla yedim"))) == {"Tavuk göğsü", "Pirinç pilavı"}
    assert _by_name(analyze_text_local("1 kase mercimek çorbası"))["Mercimek çorbası"]["portion_g"] == 300
    assert _by_name(analyze_text_local("1,5 dilim ekmek"))["Ekmek"]["portion_g"] == 38
    assert _by_name(analyze_text_local("yarım ekmek"))["Ekmek"]["portion_g"] == 125


def test_food_text_endpoint(client):
    h = register(client)
    r = client.post("/ai/food-text", headers=h, json={"text": "2 yumurta, 1 dilim ekmek, kinoa"})
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["provider"] == "yerel" and data["totals"]["calories"] == 143 + 66
    assert data["unmatched"] == ["kinoa"]
    assert client.post("/ai/food-text", headers=h, json={"text": ""}).status_code == 422
    assert client.post("/ai/food-text", json={"text": "yumurta"}).status_code == 401


def test_ai_status_and_photo_demo(client):
    h = register(client)
    assert client.get("/ai/status", headers=h).json() == {"food_provider": "demo", "food_model": "demo"}
    r = client.post("/ai/food", headers=h, files={"photo": ("t.png", b"\x89PNG fake", "image/png")})
    assert r.status_code == 200 and r.json()["provider"] == "demo" and r.json()["items"]
    r = client.post("/ai/food", headers=h, files={"photo": ("t.gif", b"GIF89a", "image/gif")})
    assert r.status_code == 415
