"""Kayıt, giriş ve sayfaların sunulması."""
from conftest import login, register


def test_register_login_me(client):
    h = register(client)
    me = client.get("/auth/me", headers=h).json()
    assert me["email"] == "uye@test.com" and me["full_name"] == "Test Üye"
    assert client.post("/auth/register", json={"email": "UYE@test.com", "password": "baska12", "full_name": "X Y"}).status_code == 409
    assert client.post("/auth/login", data={"username": "uye@test.com", "password": "yanlis1"}).status_code == 401
    assert login(client, "UYE@test.com", "uye1234")


def test_protected_endpoints_need_token(client):
    assert client.get("/diary/state").status_code == 401
    assert client.get("/auth/me", headers={"Authorization": "Bearer bozuk"}).status_code == 401


def test_pages_are_served(client):
    r = client.get("/app/")
    assert r.status_code == 200 and "/diary/state" in r.text and "kepce_token" in r.text
    r = client.get("/app/giris.html")
    assert r.status_code == 200 and "/auth/login" in r.text
    assert client.get("/", follow_redirects=False).headers["location"] == "/app/"
