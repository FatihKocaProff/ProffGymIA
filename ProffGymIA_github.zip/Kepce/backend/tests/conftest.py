import os
import tempfile
from pathlib import Path

import pytest

_tmp = Path(tempfile.mkdtemp())
os.environ["KEPCE_DATABASE_URL"] = f"sqlite:///{(_tmp / 'test.db').as_posix()}"
os.environ["KEPCE_AI_PROVIDER"] = "demo"

from fastapi.testclient import TestClient

from app.database import Base, engine
from app.main import app


@pytest.fixture()
def client():
    import giris_siniri

    giris_siniri.reset()
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    with TestClient(app) as c:
        yield c


def login(client, email, password) -> dict:
    r = client.post("/auth/login", data={"username": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def register(client, email="uye@test.com", password="uye1234") -> dict:
    r = client.post("/auth/register", json={"email": email, "password": password, "full_name": "Test Üye"})
    assert r.status_code == 201, r.text
    return login(client, email, password)
