"""Diyet defteri: kalemlerin kaydedilmesi, düzenleme/silme, profil aktarımı, kullanıcı ayrımı, sıfırlama."""
from datetime import date

from conftest import register

TODAY = date.today().isoformat()
META = {
    "version": 1, "createdAt": 1, "favorites": ["ayran"], "userFoods": [], "settings": {"showCalories": True},
    "consents": [], "goals": [{"start": TODAY, "calories": 1800}],
    "profile": {"sex": "female", "birth": "1990-03-14", "height": 165, "weight": 72, "activity": "light", "goal": "lose"},
}


def _entry(**kw):
    e = {"id": "e1", "date": TODAY, "meal": "lunch", "name": "Mercimek çorbası", "description": "Mercimek çorbası · 1 kase",
         "kcal": 140, "p": 8.5, "c": 21.3, "f": 3, "foodId": "mercimek", "unit": 0, "qty": 1, "grams": 250,
         "unitLabel": "1 kase", "source": "search", "planned": False, "deleted": False, "createdAt": 5}
    e.update(kw)
    return e


def test_diary_round_trip_edit_delete(client):
    h = register(client)
    state = client.get("/diary/state", headers=h).json()
    assert state["meta"] is None and state["entries"] == []

    r = client.put("/diary/sync", headers=h, json={
        "meta": META, "apply_profile": True, "entries": [_entry()],
        "water": [{"id": "w1", "date": TODAY, "ml": 250, "at": 1, "deleted": False}],
        "weights": [{"date": TODAY, "kg": 72}],
    })
    assert r.status_code == 204, r.text

    state = client.get("/diary/state", headers=h).json()
    assert state["meta"]["favorites"] == ["ayran"]
    e = state["entries"][0]
    assert e["id"] == "e1" and e["foodId"] == "mercimek" and e["qty"] == 1 and e["kcal"] == 140
    assert state["water"][0]["id"] == "w1" and state["water"][0]["ml"] == 250
    assert state["weights"] == [{"date": TODAY, "kg": 72.0}]
    assert state["prefill"] == {"sex": "female", "birth": "1990-03-14", "height": 165.0, "weight": 72.0, "activity": "light"}

    client.put("/diary/sync", headers=h, json={"entries": [_entry(qty=2, kcal=280, meal="dinner")]})
    e = client.get("/diary/state", headers=h).json()["entries"][0]
    assert e["kcal"] == 280 and e["meal"] == "dinner" and e["qty"] == 2

    client.put("/diary/sync", headers=h, json={"entries": [_entry(deleted=True)],
                                               "water": [{"id": "w1", "date": TODAY, "ml": 250, "deleted": True}]})
    state = client.get("/diary/state", headers=h).json()
    assert state["entries"] == [] and state["water"] == []


def test_users_cannot_see_or_touch_each_other(client):
    h_other = register(client, "baska@test.com")
    client.put("/diary/sync", headers=h_other, json={"entries": [_entry()]})
    h = register(client)
    assert client.get("/diary/state", headers=h).json()["entries"] == []
    client.put("/diary/sync", headers=h, json={"entries": [_entry(deleted=True)]})
    assert len(client.get("/diary/state", headers=h_other).json()["entries"]) == 1


def test_reset_keeps_weights(client):
    h = register(client)
    client.put("/diary/sync", headers=h, json={"meta": META, "entries": [_entry()], "weights": [{"date": TODAY, "kg": 70}]})
    assert client.delete("/diary", headers=h).status_code == 204
    state = client.get("/diary/state", headers=h).json()
    assert state["meta"] is None and state["entries"] == []
    assert state["weights"] == [{"date": TODAY, "kg": 70.0}]


def test_meta_size_limit(client):
    h = register(client)
    r = client.put("/diary/sync", headers=h, json={"meta": {"blob": "x" * 1_100_000}})
    assert r.status_code == 413
