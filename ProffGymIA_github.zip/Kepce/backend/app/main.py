"""Kepçe — diyet defteri API'si.

Çalıştırma:  uvicorn app.main:app --reload
Dokümantasyon: http://127.0.0.1:8000/docs
"""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import models
from .database import ensure_schema
from .routers import ai, auth, diary

STATIC_DIR = Path(__file__).resolve().parent / "static"


@asynccontextmanager
async def lifespan(_: FastAPI):
    added = ensure_schema()
    if added:
        print("Veritabanına eklenen sütunlar:", ", ".join(added))
    yield


app = FastAPI(
    title="Kepçe API",
    description="Türk mutfağıyla beslenenler için kalori ve öğün defteri.",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(ai.router)
app.include_router(diary.router)

app.mount("/app", StaticFiles(directory=STATIC_DIR, html=True), name="app")


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse("/app/")


@app.get("/health", tags=["Sistem"])
def health():
    return {"status": "ok"}
