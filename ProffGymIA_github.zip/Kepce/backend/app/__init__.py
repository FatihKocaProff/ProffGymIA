import sys
from pathlib import Path

_ORTAK = Path(__file__).resolve().parents[3] / "ortak"
if str(_ORTAK) not in sys.path:
    sys.path.insert(0, str(_ORTAK))
