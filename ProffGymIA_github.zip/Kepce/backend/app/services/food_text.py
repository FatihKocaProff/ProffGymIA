"""Ortak koda yönlendirme: asıl kod `ortak/beslenme/food_text.py` içinde."""
import sys

from beslenme import food_text as _impl

sys.modules[__name__] = _impl
