"""Ortak koda yönlendirme: asıl kod `ortak/beslenme/food_ai.py` içinde.

Bu uygulamanın ayarları (config) ortak modüle burada bağlanır.
"""
import sys

from beslenme import food_ai as _impl

from .. import config

_impl.configure(config)
sys.modules[__name__] = _impl
