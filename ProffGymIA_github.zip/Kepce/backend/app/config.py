"""Uygulama ayarları. Ortam değişkenleriyle (veya .env dosyasıyla) değiştirilebilir."""
import os
from pathlib import Path


def _load_dotenv() -> None:
    """Ek paket gerektirmeyen basit .env okuyucu."""
    env_path = Path(__file__).resolve().parent.parent / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv()

DATABASE_URL = os.getenv("KEPCE_DATABASE_URL", "sqlite:///./kepce.db")

def _secret_key() -> str:
    """Token imza anahtarı. Varsayılan/kısa ise güçlü bir anahtar üretip .env'e yazar.

    Varsayılan anahtar herkesin görebildiği koddadır; onu bilen biri kendine yönetici token'ı üretebilir.
    """
    import secrets

    value = os.getenv("KEPCE_SECRET_KEY", "").strip()
    if len(value) >= 32 and value != "gelistirme-anahtari-degistir":
        return value
    value = secrets.token_urlsafe(48)
    env_path = Path(__file__).resolve().parent.parent / ".env"
    try:
        lines = env_path.read_text(encoding="utf-8").splitlines() if env_path.exists() else []
        lines = [ln for ln in lines if not ln.strip().startswith("KEPCE_SECRET_KEY=")]
        lines.append(f"KEPCE_SECRET_KEY={value}")
        env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print("Uyarı: KEPCE_SECRET_KEY zayıftı; yeni anahtar üretilip .env dosyasına yazıldı.")
    except OSError:
        print("Uyarı: KEPCE_SECRET_KEY zayıf ve .env yazılamadı; geçici anahtar kullanılıyor (yeniden başlatınca oturumlar kapanır).")
    os.environ["KEPCE_SECRET_KEY"] = value
    return value


SECRET_KEY = _secret_key()
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("KEPCE_TOKEN_MINUTES", str(60 * 24 * 30)))

AI_PROVIDER = os.getenv("KEPCE_AI_PROVIDER", "").strip().lower()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("KEPCE_GEMINI_MODEL", "gemini-3.6-flash")
CLAUDE_MODEL = os.getenv("KEPCE_CLAUDE_MODEL", "claude-haiku-5-5")
AI_TIMEOUT_SECONDS = float(os.getenv("KEPCE_AI_TIMEOUT", "45"))
