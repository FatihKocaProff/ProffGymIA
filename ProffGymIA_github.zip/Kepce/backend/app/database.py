from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from .config import DATABASE_URL

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    """Her istek için ayrı bir veritabanı oturumu açar ve sonunda kapatır."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def ensure_schema() -> list[str]:
    """Eksik tabloları oluşturur, mevcut tablolara sonradan eklenen sütunları ekler.

    Böylece kepce.db silinmeden yeni sürüme geçilir. Yalnızca boş bırakılabilen (nullable)
    veya varsayılanı olan sütun eklemeleri desteklenir; büyük şema değişiklikleri için Alembic kullanılmalıdır.
    """
    Base.metadata.create_all(bind=engine)
    added = []
    inspector = inspect(engine)
    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            existing = {c["name"] for c in inspector.get_columns(table.name)}
            for column in table.columns:
                if column.name in existing:
                    continue
                col_type = column.type.compile(dialect=engine.dialect)
                default = ""
                if column.default is not None and getattr(column.default, "is_scalar", False):
                    value = column.default.arg
                    if isinstance(value, bool):
                        default = " DEFAULT TRUE" if value else " DEFAULT FALSE"
                    elif isinstance(value, str):
                        default = " DEFAULT '" + value.replace("'", "''") + "'"
                    elif isinstance(value, (int, float)):
                        default = f" DEFAULT {value}"
                conn.execute(text(f'ALTER TABLE {table.name} ADD COLUMN "{column.name}" {col_type}{default}'))
                added.append(f"{table.name}.{column.name}")
    return added
