"""API istek ve yanıt şemaları (Pydantic). Swagger dokümantasyonu bunlardan üretilir."""
from datetime import date

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from .models import MealType


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6, max_length=72)
    full_name: str = Field(min_length=2, max_length=120)


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: int


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    email: str
    full_name: str


class FoodItemOut(BaseModel):
    name: str
    portion_g: float
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float


class FoodAnalysisOut(BaseModel):
    items: list[FoodItemOut]
    totals: dict[str, float]
    fiber_g: float
    vitamins: list[str]
    confidence: str
    consistent: bool
    note: str
    provider: str
    model: str
    unmatched: list[str] = Field(default_factory=list, description="Yazılı öğünde tanınamayan kısımlar")


class FoodTextIn(BaseModel):
    text: str = Field(min_length=1, max_length=1500, description="Ör. '2 yumurta, 1 dilim ekmek, 1 bardak çay'")
    quick: bool = Field(default=False, description="Yazarken anlık önizleme: her zaman yerel besin tablosu (hızlı)")


class AIStatusOut(BaseModel):
    food_provider: str
    food_model: str


class DiaryEntryIn(BaseModel):
    """Defterdeki bir kalem. Bilinmeyen alanlar (besin kimliği, porsiyon, miktar, vitaminler…) olduğu gibi saklanır."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str = Field(min_length=1, max_length=40)
    day: date = Field(alias="date")
    meal: MealType
    name: str = Field(default="", max_length=200)
    description: str | None = Field(default=None, max_length=500)
    kcal: float = Field(default=0, ge=0, le=10000)
    p: float = Field(default=0, ge=0, le=1000)
    c: float = Field(default=0, ge=0, le=1000)
    f: float = Field(default=0, ge=0, le=1000)
    deleted: bool = False


class DiaryWaterIn(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str = Field(min_length=1, max_length=40)
    day: date = Field(alias="date")
    ml: int = Field(gt=0, le=5000)
    deleted: bool = False


class DiaryWeightIn(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    day: date = Field(alias="date")
    kg: float = Field(ge=20, le=400)


class DiarySyncIn(BaseModel):
    """Defterde son gönderimden beri değişenler. meta: öğün/su/kilo dışındaki her şey."""

    meta: dict | None = None
    entries: list[DiaryEntryIn] = Field(default_factory=list, max_length=500)
    water: list[DiaryWaterIn] = Field(default_factory=list, max_length=500)
    weights: list[DiaryWeightIn] = Field(default_factory=list, max_length=500)
    apply_profile: bool = Field(default=False, description="Hedef yeniden hesaplandı: profil bilgilerini kullanıcı kaydına da yaz")
