"""Diyet defteri verisi.

Öğün kalemleri -> meals, su -> water_logs, tartı -> weight_logs. Hedef geçmişi, favoriler,
kullanıcının eklediği ürünler ve ayarlar diet_diaries'te JSON olarak durur.
"""
import json
from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from ..models import ActivityLevel, DietDiary, Gender, Goal, Meal, User, WaterLog, WeightLog
from ..schemas import DiaryEntryIn, DiarySyncIn, DiaryWaterIn

router = APIRouter(prefix="/diary", tags=["Diyet defteri"])

MAX_META_BYTES = 1_000_000
CORE_FIELDS = {"id", "date", "meal", "kcal", "p", "c", "f", "deleted"}


def _ms(dt: datetime | None) -> int:
    return int(dt.timestamp() * 1000) if dt else 0


def _entry(meal: Meal) -> dict:
    """Bir öğün satırını defter kalemine çevirir. Sayılar her zaman tablodan gelir."""
    data = json.loads(meal.diary_data) if meal.diary_data else {"name": meal.description or "Öğün", "createdAt": _ms(meal.created_at)}
    data.update(
        id=meal.diary_ref,
        date=meal.meal_date.isoformat(),
        meal=meal.meal_type.value,
        kcal=round(meal.calories, 1),
        p=round(meal.protein_g, 1),
        c=round(meal.carbs_g, 1),
        f=round(meal.fat_g, 1),
        deleted=False,
    )
    return data


def _water(w: WaterLog) -> dict:
    return {"id": w.diary_ref, "date": w.log_date.isoformat(), "ml": w.amount_ml, "at": _ms(w.created_at), "deleted": False}


@router.get("/state")
def get_state(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Defterin tamamı. meta boşsa kullanıcı defteri henüz kurmamıştır; prefill kayıtlı profilden gelir."""
    diary = db.scalar(select(DietDiary).where(DietDiary.user_id == user.id))
    meals = db.scalars(select(Meal).where(Meal.user_id == user.id).order_by(Meal.created_at)).all()
    water = db.scalars(select(WaterLog).where(WaterLog.user_id == user.id).order_by(WaterLog.created_at)).all()
    weights = db.scalars(select(WeightLog).where(WeightLog.user_id == user.id).order_by(WeightLog.log_date)).all()
    return {
        "meta": json.loads(diary.data) if diary else None,
        "entries": [_entry(m) for m in meals],
        "water": [_water(w) for w in water],
        "weights": [{"date": w.log_date.isoformat(), "kg": w.weight_kg} for w in weights],
        "prefill": {
            "sex": user.gender.value if user.gender else None,
            "birth": user.birth_date.isoformat() if user.birth_date else "",
            "height": user.height_cm,
            "weight": weights[-1].weight_kg if weights else None,
            "activity": user.activity_level.value if user.activity_level else None,
        },
    }


def _sync_entry(db: Session, user: User, e: DiaryEntryIn):
    meal = db.scalar(select(Meal).where(Meal.user_id == user.id, Meal.diary_ref == e.id))
    if e.deleted:
        if meal:
            db.delete(meal)
        return
    data = e.model_dump(by_alias=True, mode="json")
    if meal is None:
        meal = Meal(user_id=user.id, diary_ref=e.id)
        db.add(meal)
    meal.meal_date = e.day
    meal.meal_type = e.meal
    meal.description = (e.description or e.name or "Öğün")[:500]
    meal.calories, meal.protein_g, meal.carbs_g, meal.fat_g = e.kcal, e.p, e.c, e.f
    meal.diary_data = json.dumps({k: v for k, v in data.items() if k not in CORE_FIELDS}, ensure_ascii=False)


def _sync_water(db: Session, user: User, w: DiaryWaterIn):
    row = db.scalar(select(WaterLog).where(WaterLog.user_id == user.id, WaterLog.diary_ref == w.id))
    if w.deleted:
        if row:
            db.delete(row)
        return
    if row is None:
        db.add(WaterLog(user_id=user.id, log_date=w.day, amount_ml=w.ml, diary_ref=w.id))
    else:
        row.log_date, row.amount_ml = w.day, w.ml


GOALS = {"lose": Goal.lose, "maintain": Goal.maintain, "gain": Goal.gain, "healthy": Goal.maintain}


def _apply_profile(user: User, profile: dict):
    """Defterde hesaplanan hedefin girdilerini kullanıcı kaydına yazar (sonraki "yeniden hesapla" için ön doldurma)."""
    if profile.get("sex") in ("male", "female"):
        user.gender = Gender(profile["sex"])
    try:
        user.birth_date = date.fromisoformat(profile.get("birth") or "")
    except ValueError:
        pass
    height = profile.get("height")
    if isinstance(height, (int, float)) and 100 <= height <= 250:
        user.height_cm = float(height)
    if profile.get("activity") in ActivityLevel.__members__:
        user.activity_level = ActivityLevel(profile["activity"])
    if profile.get("goal") in GOALS:
        user.goal = GOALS[profile["goal"]]


@router.put("/sync", status_code=status.HTTP_204_NO_CONTENT)
def sync(data: DiarySyncIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Defterde değişen kalemleri kaydeder. Gönderilmeyen kayıtlara dokunulmaz."""
    if data.meta is not None:
        text = json.dumps(data.meta, ensure_ascii=False)
        if len(text.encode()) > MAX_META_BYTES:
            raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "Defter verisi çok büyük")
        diary = db.scalar(select(DietDiary).where(DietDiary.user_id == user.id))
        if diary:
            diary.data = text
        else:
            db.add(DietDiary(user_id=user.id, data=text))
        if data.apply_profile and isinstance(data.meta.get("profile"), dict):
            _apply_profile(user, data.meta["profile"])
    for e in data.entries:
        _sync_entry(db, user, e)
    for w in data.water:
        _sync_water(db, user, w)
    for w in data.weights:
        row = db.scalar(select(WeightLog).where(WeightLog.user_id == user.id, WeightLog.log_date == w.day))
        if row:
            row.weight_kg = w.kg
        else:
            db.add(WeightLog(user_id=user.id, log_date=w.day, weight_kg=w.kg))
    db.commit()


@router.delete("", status_code=status.HTTP_204_NO_CONTENT)
def reset(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Defteri sıfırlar: hedefler, favoriler, ürünler, öğün ve su kayıtları silinir. Tartılar kalır."""
    db.execute(delete(DietDiary).where(DietDiary.user_id == user.id))
    db.execute(delete(Meal).where(Meal.user_id == user.id))
    db.execute(delete(WaterLog).where(WaterLog.user_id == user.id))
    db.commit()
