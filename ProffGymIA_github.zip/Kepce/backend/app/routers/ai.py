"""Yapay zeka uçları: yazılan öğün ve yemek fotoğrafı analizi. İkisi de KAYDETMEZ (defterdeki önizleme için)."""
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status

from .. import config
from ..deps import get_current_user
from ..models import User
from ..schemas import AIStatusOut, FoodAnalysisOut, FoodTextIn
from ..services import food_ai

router = APIRouter(prefix="/ai", tags=["Yapay zeka"])

ALLOWED_IMAGE_TYPES = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
MAX_PHOTO_BYTES = 10 * 1024 * 1024


def read_image(photo: UploadFile) -> tuple[bytes, str]:
    """Yüklenen görseli doğrular; (içerik, mime türü) döner."""
    mime = (photo.content_type or "").lower()
    if mime == "image/jpg":
        mime = "image/jpeg"
    if mime not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "Sadece JPEG, PNG veya WEBP yüklenebilir")
    data = photo.file.read(MAX_PHOTO_BYTES + 1)
    if len(data) > MAX_PHOTO_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "Fotoğraf 10 MB'tan büyük olamaz")
    if not data:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Fotoğraf boş")
    return data, mime


@router.get("/status", response_model=AIStatusOut)
def ai_status(_: User = Depends(get_current_user)):
    """Hangi yapay zeka sağlayıcısının etkin olduğunu gösterir."""
    provider = food_ai.active_provider()
    model = {"gemini": config.GEMINI_MODEL, "claude": config.CLAUDE_MODEL}.get(provider, "demo")
    return AIStatusOut(food_provider=provider, food_model=model)


@router.post("/food", response_model=FoodAnalysisOut)
def analyze_food(photo: UploadFile = File(...), _: User = Depends(get_current_user)):
    data, mime = read_image(photo)
    try:
        return food_ai.analyze_food(data, mime)
    except food_ai.FoodAIError as exc:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(exc)) from exc


@router.post("/food-text", response_model=FoodAnalysisOut)
def analyze_food_text(data: FoodTextIn, _: User = Depends(get_current_user)):
    """Ör. "2 yumurta, 1 dilim ekmek, 30 g beyaz peynir, 1 bardak çay". Yapay zeka anahtarı yoksa
    yerel besin tablosu kullanılır; tanınamayan kısımlar `unmatched` alanında döner."""
    return food_ai.analyze_text(data.text, quick=data.quick)
