@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Kepce API

if not exist ".venv\Scripts\python.exe" (
    echo [1/2] Ilk kurulum yapiliyor, birkac dakika surebilir...
    python -m venv .venv || (echo Python bulunamadi. python.org'dan Python 3.11+ kur, "Add Python to PATH" kutusunu isaretle. & pause & exit /b 1)
)

fc /b requirements.txt ".venv\installed-requirements.txt" >nul 2>&1
if errorlevel 1 (
    echo [1/2] Paketler kuruluyor / guncelleniyor...
    ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt || (echo Paket kurulumu basarisiz. Internet baglantisini kontrol et. & pause & exit /b 1)
    copy /y requirements.txt ".venv\installed-requirements.txt" >nul
)

if not exist ".env" copy ".env.example" ".env" >nul

echo.
echo [2/2] Kepce calisiyor
echo    Uygulama    : http://127.0.0.1:8001/
echo    API dokumani: http://127.0.0.1:8001/docs
echo    Telefondan baglanmak icin asagidaki IP adreslerinden birini kullan (ayni Wi-Fi):
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do echo        http:%%a:8001
echo    Kapatmak icin bu pencereyi kapat veya Ctrl+C bas.
echo.
start "" cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8001/"
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 0.0.0.0 --port 8001 --reload
pause
