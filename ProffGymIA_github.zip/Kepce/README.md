# Kepçe — Diyet Defteri

Türk mutfağıyla beslenenler için kalori ve öğün defteri. ProffGymIA (spor salonu uygulaması)
içindeki diyet defterinden ayrılmış, tamamen bağımsız sürüm: kendi sunucusu, kendi veritabanı
(`kepce.db`) ve kendi giriş/kayıt ekranı vardır.

## Çalıştırma

`backend\baslat.bat` dosyasına çift tıkla. İlk açılışta sanal ortamı ve paketleri kurar.

- Uygulama: http://127.0.0.1:8001/  (giriş: `/app/giris.html`)
- API dokümanı: http://127.0.0.1:8001/docs

Port 8001'dir; spor salonu uygulaması (8000) ile aynı anda çalışabilir.

## Yapay zeka

`backend\.env` içindeki `GEMINI_API_KEY` (veya `ANTHROPIC_API_KEY` + `KEPCE_AI_PROVIDER=claude`)
ile yazılan öğün ve yemek fotoğrafı analiz edilir. Anahtar yoksa, kota dolduysa ya da internet
yoksa yazılan öğün yerel besin tablosuyla (`app/services/food_text.py`) hesaplanır.

## Yapı

```
backend/
  app/
    main.py            uygulama ve yönlendirmeler
    routers/auth.py    kayıt, giriş, /auth/me
    routers/diary.py   defter verisi: /diary/state, /diary/sync, /diary (sıfırla)
    routers/ai.py      /ai/food-text, /ai/food, /ai/status
    services/food_ai.py    Gemini / Claude ile analiz
    services/food_text.py  yerel besin tablosu ve miktar okuyucu
    static/index.html  defter arayüzü
    static/giris.html  giriş / kayıt
  tests/               pytest
```

Testler: `backend` klasöründe `.venv\Scripts\python -m pytest`
